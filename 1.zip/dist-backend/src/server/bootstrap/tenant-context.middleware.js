export const tenantContextMiddleware = (req, _res, next) => {
    const tenantHeader = req.headers['x-tenant-id'];
    if (tenantHeader) {
        req.requestedTenantId = tenantHeader;
    }
    const host = req.headers.host || '';
    const hostname = host.split(':')[0] || '';
    const subdomain = hostname.split('.')[0];
    if (subdomain && subdomain !== 'localhost' && subdomain !== 'www' && !hostname.includes('.run.app')) {
        req.subdomain = subdomain;
        req.requestedTenantId = req.requestedTenantId || subdomain;
    }
    next();
};
