export var UserRole;
(function (UserRole) {
    UserRole["SUPER_ADMIN"] = "super-admin";
    UserRole["TENANT_ADMIN"] = "tenant-admin";
    UserRole["GUARD"] = "guard";
    UserRole["SUPERVISOR"] = "supervisor";
    UserRole["TECHNICIAN"] = "technician";
    UserRole["VENDOR_COMMANDER"] = "vendor-commander";
    UserRole["VENDOR_REPRESENTATIVE"] = "vendor-representative";
})(UserRole || (UserRole = {}));
export var TenantPlan;
(function (TenantPlan) {
    TenantPlan["TRIAL"] = "TRIAL";
    TenantPlan["BASIC"] = "BASIC";
    TenantPlan["PRO"] = "PRO";
    TenantPlan["ENTERPRISE"] = "ENTERPRISE";
    TenantPlan["LITE"] = "LITE";
})(TenantPlan || (TenantPlan = {}));
export var TenantStatus;
(function (TenantStatus) {
    TenantStatus["ACTIVE"] = "active";
    TenantStatus["SUSPENDED"] = "suspended";
    TenantStatus["PENDING"] = "pending";
})(TenantStatus || (TenantStatus = {}));
