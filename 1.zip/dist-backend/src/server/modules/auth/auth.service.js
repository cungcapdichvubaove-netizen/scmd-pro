import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import { JWT_SECRET } from '../../core/auth/secrets.js';
const MAX_ACCESS_TOKEN_TTL_SECONDS = 15 * 60;
export class AuthService {
    static signToken(payload) {
        const configuredTtl = process.env.JWT_EXPIRES_IN || '15m';
        const expiresIn = this.resolveAccessTokenTtl(configuredTtl);
        return jwt.sign(payload, JWT_SECRET, { expiresIn: expiresIn });
    }
    static resolveAccessTokenTtl(configuredTtl) {
        const ttlSeconds = this.parseTtlSeconds(configuredTtl);
        if (ttlSeconds === null || ttlSeconds > MAX_ACCESS_TOKEN_TTL_SECONDS) {
            return '15m';
        }
        return configuredTtl;
    }
    static parseTtlSeconds(value) {
        const match = value.trim().match(/^(\d+)([smhd])$/i);
        if (!match)
            return null;
        const amount = Number(match[1]);
        const unit = (match[2] ?? '').toLowerCase();
        const multiplier = unit === 's'
            ? 1
            : unit === 'm'
                ? 60
                : unit === 'h'
                    ? 3600
                    : 86400;
        return amount * multiplier;
    }
    // NOTE [BUG #3 REMOVED]: signRefreshToken() đã bị xóa.
    // Lý do: Hệ thống dùng opaque UUID làm refresh token (lưu trong Redis), KHÔNG dùng JWT.
    // Nếu giữ lại hàm này, developer có thể nhầm dùng nó để issue JWT refresh token —
    // điều đó sẽ bypass hoàn toàn cơ chế rotation + revocation của Redis.
    // Xem: AuthController.generateAuthPayload() → crypto.randomUUID() làm refresh token.
    static verifyToken(token) {
        try {
            return jwt.verify(token, JWT_SECRET);
        }
        catch (e) {
            return null;
        }
    }
    /**
     * Single source of truth cho JWT payload.
     * Mọi nơi cần tạo token phải gọi hàm này để đảm bảo payload nhất quán.
     */
    static generateAuthPayload(user, permissions) {
        const payload = {
            id: user.id,
            username: user.username,
            role: user.role,
            tenantId: user.tenantId,
            tokenVersion: user.tokenVersion,
            name: user.fullName,
            permissions,
            assignedVendorId: user.assignedVendorId ?? null,
            assignedSiteId: user.assignedSiteId ?? null,
            assignedContractId: user.assignedContractId ?? null,
        };
        const token = this.signToken(payload);
        const refreshToken = crypto.randomUUID();
        return { token, refreshToken, payload };
    }
}
