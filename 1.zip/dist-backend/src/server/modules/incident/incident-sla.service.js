import { AcknowledgeIncidentUseCase } from './application/acknowledge-incident.usecase.js';
import { AddIncidentEvidenceUseCase } from './application/add-incident-evidence.usecase.js';
import { ApproveIncidentResolutionUseCase } from './application/approve-incident-resolution.usecase.js';
import { CloseIncidentUseCase } from './application/close-incident.usecase.js';
import { ProcessIncidentSlaBreachUseCase } from './application/process-incident-sla-breach.usecase.js';
import { RecordIncidentCreatedUseCase } from './application/record-incident-created.usecase.js';
import { RejectIncidentResolutionUseCase } from './application/reject-incident-resolution.usecase.js';
import { SubmitIncidentResolutionUseCase } from './application/submit-incident-resolution.usecase.js';
import { UpdateIncidentEvidenceStatusUseCase } from './application/update-incident-evidence-status.usecase.js';
import { IncidentSlaShared } from './incident-sla.shared.js';
export class IncidentSlaService {
    static getSlaMinutes(severity) {
        return IncidentSlaShared.getSlaMinutes(severity);
    }
    static buildSlaDeadline(severity, from = new Date()) {
        return IncidentSlaShared.buildSlaDeadline(severity, from);
    }
    static async recordCreated(ctx, incident) {
        const incidentId = typeof incident === 'string' ? incident : incident?.id;
        if (!incidentId)
            throw new Error('INCIDENT_ID_REQUIRED');
        return await new RecordIncidentCreatedUseCase().execute(ctx, incidentId);
    }
    static async acknowledgeIncident(ctx, incidentId, notes) {
        return await new AcknowledgeIncidentUseCase().execute(ctx, { incidentId, notes });
    }
    static async addEvidence(ctx, input) {
        return await new AddIncidentEvidenceUseCase().execute(ctx, {
            incidentId: input.incidentId,
            kind: input.kind,
            uri: input.uri ?? undefined,
            note: input.note ?? undefined,
            sourceType: input.sourceType ?? 'INCIDENT',
            sourceId: input.sourceId ?? undefined,
            fileType: input.fileType ?? undefined,
            fileUrl: input.fileUrl ?? undefined,
            thumbnailUrl: input.thumbnailUrl ?? undefined,
            capturedAt: input.capturedAt ? new Date(input.capturedAt) : undefined,
            gpsLat: input.gpsLat ?? undefined,
            gpsLng: input.gpsLng ?? undefined,
            checksum: input.checksum ?? undefined,
            metadata: input.metadata ?? undefined,
        });
    }
    static async updateEvidenceStatus(ctx, incidentId, evidenceId, status, note) {
        return await new UpdateIncidentEvidenceStatusUseCase().execute(ctx, { incidentId, evidenceId, status, note });
    }
    static async submitResolution(ctx, incidentId, notes, images = []) {
        return await new SubmitIncidentResolutionUseCase().execute(ctx, { incidentId, notes, images });
    }
    static async approveResolution(ctx, incidentId, notes) {
        return await new ApproveIncidentResolutionUseCase().execute(ctx, { incidentId, notes });
    }
    static async rejectResolution(ctx, incidentId, reopenReason, requiredNextAction) {
        return await new RejectIncidentResolutionUseCase().execute(ctx, { incidentId, reopenReason, requiredNextAction });
    }
    static async closeIncident(ctx, incidentId, notes) {
        return await new CloseIncidentUseCase().execute(ctx, { incidentId, notes });
    }
    static async processOverdueTenant(tenantId) {
        return await new ProcessIncidentSlaBreachUseCase().execute(tenantId);
    }
    static async addTimeline(tx, input) {
        return await IncidentSlaShared.addTimeline(tx, input);
    }
    static async scheduleEscalation(tenantId, incidentJobKey, deadline) {
        return await IncidentSlaShared.scheduleEscalation(tenantId, incidentJobKey, deadline);
    }
    static getMissingEvidenceTypes(requiredTypes, evidences) {
        return IncidentSlaShared.getMissingEvidenceTypes(requiredTypes, evidences);
    }
}
