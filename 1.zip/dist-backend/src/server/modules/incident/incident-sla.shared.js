import { IncidentSeverity, IncidentStatus } from '@prisma/client';
import { UserRole } from '../../core/architecture/types.js';
import { BadRequestError } from '../../core/errors/domain.error.js';
import { loggerContext } from '../../core/logger/index.js';
const LEGACY_RESOLUTION_MINUTES = {
    [IncidentSeverity.LOW]: 240,
    [IncidentSeverity.MEDIUM]: 120,
    [IncidentSeverity.HIGH]: 60,
    [IncidentSeverity.CRITICAL]: 30,
};
export const FINAL_INCIDENT_STATUSES = [IncidentStatus.CLOSED, IncidentStatus.CANCELLED];
const INCIDENT_APPROVAL_ROLE_MATRIX = {
    [IncidentSeverity.LOW]: [UserRole.SUPERVISOR, UserRole.TENANT_ADMIN, UserRole.SUPER_ADMIN],
    [IncidentSeverity.MEDIUM]: [UserRole.SUPERVISOR, UserRole.TENANT_ADMIN, UserRole.SUPER_ADMIN],
    [IncidentSeverity.HIGH]: [UserRole.TENANT_ADMIN, UserRole.SUPER_ADMIN],
    [IncidentSeverity.CRITICAL]: [UserRole.TENANT_ADMIN, UserRole.SUPER_ADMIN],
};
export class IncidentSlaShared {
    static getSlaMinutes(severity) {
        return LEGACY_RESOLUTION_MINUTES[severity] ?? LEGACY_RESOLUTION_MINUTES[IncidentSeverity.LOW];
    }
    static buildSlaDeadline(severity, from = new Date()) {
        return new Date(from.getTime() + this.getSlaMinutes(severity) * 60_000);
    }
    static allowedApprovalRoles(severity) {
        return INCIDENT_APPROVAL_ROLE_MATRIX[severity] ?? INCIDENT_APPROVAL_ROLE_MATRIX[IncidentSeverity.LOW];
    }
    static assertCanApproveOrClose(role, severity, action) {
        const allowedRoles = this.allowedApprovalRoles(severity);
        if (!allowedRoles.includes(role)) {
            throw new BadRequestError(`ROLE_NOT_ALLOWED_TO_${action.toUpperCase()}_${severity}`);
        }
    }
    static async addTimeline(tx, input) {
        return await tx.incidentTimeline.create({
            data: this.timelineData(null, input),
        });
    }
    static async scheduleEscalation(tenantId, incidentJobKey, deadline) {
        const delay = Math.max(0, deadline.getTime() - Date.now());
        const { QueueService } = await import('../../core/queue/index.js');
        await QueueService.addJob('INCIDENT_SLA_ESCALATION_CHECK_TENANT', { type: 'INCIDENT_SLA_ESCALATION_CHECK_TENANT', tenantId, incidentId: incidentJobKey }, `incident-sla:${incidentJobKey}`, { delay });
    }
    static getMissingEvidenceTypes(requiredTypes, evidences) {
        const activeTypes = new Set(evidences
            .filter((e) => e.status === 'ACTIVE')
            .flatMap((e) => [e.kind, e.fileType, e.sourceType])
            .filter(Boolean)
            .map((value) => String(value).toUpperCase()));
        return (requiredTypes ?? []).filter((type) => !activeTypes.has(String(type).toUpperCase()));
    }
    static assertEvidenceWritable(evidence) {
        if (evidence.isReportLocked || evidence.lockedByReportId || evidence.lockedAt) {
            throw new BadRequestError('INCIDENT_EVIDENCE_REPORT_LOCKED');
        }
    }
    static async invalidateIncident(tenantId, incidentId) {
        const { IncidentRepository } = await import('./incident.repository.js');
        await Promise.all([
            IncidentRepository.invalidateList(tenantId),
            IncidentRepository.invalidateDetail(incidentId),
        ]);
    }
    static timelineData(ctx, input) {
        return {
            tenantId: input.tenantId,
            incidentId: input.incidentId,
            actorId: input.actorId ?? null,
            actorRole: input.actorRole ?? ctx?.role ?? null,
            action: input.action,
            fromStatus: input.fromStatus ?? null,
            toStatus: input.toStatus ?? null,
            notes: input.notes ?? null,
            evidenceIds: input.evidenceIds ?? [],
            traceId: loggerContext.getStore()?.traceId ?? null,
            metadata: input.metadata ?? undefined,
        };
    }
}
