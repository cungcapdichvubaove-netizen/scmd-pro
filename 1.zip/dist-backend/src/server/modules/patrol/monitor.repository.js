import { PatrolRepository } from './repositories/patrol.repository.js';
export class MonitorRepository {
    static isAnomaly(log) {
        const metadata = (log?.metadata || {});
        return metadata.status === 'danger'
            || Boolean(metadata.anomaly)
            || log.validationStatus === 'INVALID'
            || log.validationStatus === 'SUSPICIOUS'
            || (Array.isArray(log.exceptionCodes) && log.exceptionCodes.length > 0)
            || Boolean(log.isSuspicious);
    }
    static async getTrustScoreByTenant(ctx) {
        // Logic: Calculate based on validated exception fields, not only metadata.
        const result = await PatrolRepository.getLogsByTenant(ctx, undefined, 100);
        const logs = Array.isArray(result?.data) ? result.data : [];
        const anomalies = logs.filter(MonitorRepository.isAnomaly).length;
        const score = logs.length > 0 ? Math.max(0, 100 - (anomalies / logs.length * 200)) : 100;
        return {
            tenantId: ctx.tenantId,
            averageScore: Math.round(score),
            status: score > 90 ? 'EXCELLENT' : (score > 70 ? 'GOOD' : 'WARNING'),
            trend: []
        };
    }
    static async getAnomaliesByTenant(ctx) {
        // Real data from Prisma logs. Repository returns a paginated envelope: { data, nextCursor }.
        const result = await PatrolRepository.getLogsByTenant(ctx, undefined, 50);
        const logs = Array.isArray(result?.data) ? result.data : [];
        const dangerLogs = logs.filter(MonitorRepository.isAnomaly);
        return {
            tenantId: ctx.tenantId,
            anomalies: dangerLogs,
            stats: {
                totalCount: dangerLogs.length,
                stationaryCount: dangerLogs.filter((l) => l.metadata?.anomaly === 'STATIONARY_ALERT').length,
                missedCount: dangerLogs.filter((l) => Array.isArray(l.exceptionCodes) && l.exceptionCodes.some((code) => code.includes('MISSED'))).length,
                criticalCount: dangerLogs.filter((l) => l.metadata?.status === 'danger' || l.validationStatus === 'INVALID').length
            }
        };
    }
}
