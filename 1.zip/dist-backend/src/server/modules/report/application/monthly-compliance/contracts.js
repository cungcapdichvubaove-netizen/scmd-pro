import { z } from 'zod';
export const monthlyComplianceInputSchema = z.object({
    tenantId: z.string().min(1),
    month: z.string().regex(/^\d{4}-(0[1-9]|1[0-2])$/),
    vendorId: z.string().min(1),
    contractId: z.string().min(1).optional().nullable(),
    siteId: z.string().min(1).optional().nullable(),
    actorId: z.string().min(1).optional().nullable(),
});
