import { Prisma } from '@prisma/client';
export function getMonthRange(month) {
    const [yearRaw, monthRaw] = month.split('-');
    const year = Number(yearRaw);
    const monthIndex = Number(monthRaw) - 1;
    const start = new Date(Date.UTC(year, monthIndex, 1, 0, 0, 0));
    const end = new Date(Date.UTC(year, monthIndex + 1, 1, 0, 0, 0));
    return { start, end };
}
export function buildScopeWhere(input) {
    const where = {
        vendorId: input.vendorId,
    };
    if (input.contractId) {
        where.contractId = input.contractId;
    }
    if (input.siteId) {
        where.siteId = input.siteId;
    }
    return where;
}
export function roundScore(value) {
    return Math.max(0, Math.min(100, Math.round(value * 100) / 100));
}
export function toDecimalAmount(value) {
    return new Prisma.Decimal(value.toFixed(2));
}
export function stableSerialize(value) {
    if (value === null || typeof value !== 'object') {
        return JSON.stringify(value);
    }
    if (Array.isArray(value)) {
        return `[${value.map((item) => stableSerialize(item)).join(',')}]`;
    }
    const entries = Object.entries(value)
        .sort(([left], [right]) => left.localeCompare(right))
        .map(([key, nested]) => `${JSON.stringify(key)}:${stableSerialize(nested)}`);
    return `{${entries.join(',')}}`;
}
export function toPlainJson(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) {
        return null;
    }
    return JSON.parse(JSON.stringify(value));
}
export function getReportCutoff(start, end) {
    return {
        periodStart: start,
        periodEndExclusive: end,
        asOf: new Date(end.getTime() - 1),
    };
}
