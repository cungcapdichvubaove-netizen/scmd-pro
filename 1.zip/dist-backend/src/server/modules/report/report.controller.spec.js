import { describe, expect, it, beforeEach, vi } from 'vitest';
import { ReportController } from './report.controller.js';
import { ConflictError } from '../../core/errors/domain.error.js';
const executeMock = vi.fn();
const resolveMock = vi.fn();
const parseMock = vi.fn();
const loggerErrorMock = vi.fn();
vi.mock('../../core/context/index.js', () => ({
    RequestContextResolver: {
        resolve: (...args) => resolveMock(...args),
    },
}));
vi.mock('../../core/logger/index.js', () => ({
    logger: {
        error: (...args) => loggerErrorMock(...args),
    },
}));
vi.mock('./application/queue-monthly-acceptance-export.usecase.js', () => ({
    QueueMonthlyAcceptanceExportUseCase: vi.fn().mockImplementation(() => ({
        execute: (...args) => executeMock(...args),
    })),
}));
vi.mock('./report.schema.js', async () => {
    const actual = await vi.importActual('./report.schema.js');
    return {
        ...actual,
        exportMonthlyAcceptanceReportSchema: {
            parse: (...args) => parseMock(...args),
        },
    };
});
describe('ReportController.queueMonthlyAcceptanceExport', () => {
    beforeEach(() => {
        vi.clearAllMocks();
        resolveMock.mockReturnValue({ tenantId: 'tenant-1', userId: 'user-1', role: 'tenant-admin' });
        parseMock.mockImplementation((payload) => payload);
    });
    it('forward domain error cho global error handler thay vi nuot thanh 500 tai controller', async () => {
        const req = {
            params: { id: 'report-1' },
            body: { format: 'pdf' },
        };
        const res = {
            status: vi.fn().mockReturnThis(),
            json: vi.fn(),
        };
        const next = vi.fn();
        const domainError = new ConflictError('REPORT_EXPORT_REQUIRES_FINALIZED_STATUS');
        executeMock.mockRejectedValue(domainError);
        await ReportController.queueMonthlyAcceptanceExport(req, res, next);
        expect(next).toHaveBeenCalledWith(domainError);
        expect(res.status).not.toHaveBeenCalled();
        expect(res.json).not.toHaveBeenCalled();
        expect(loggerErrorMock).toHaveBeenCalled();
    });
});
