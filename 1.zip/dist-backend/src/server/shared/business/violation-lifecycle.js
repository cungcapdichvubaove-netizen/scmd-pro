export const VIOLATION_EVENT_CANONICAL_STATUSES = [
    'PENDING_REVIEW',
    'CONFIRMED',
    'DISPUTED',
    'WAIVED',
    'PENALIZED',
    'CLOSED',
];
export const VIOLATION_EVENT_REVIEWABLE_STATUSES = [
    'PENDING_REVIEW',
];
export const VIOLATION_EVENT_SCORED_STATUSES = [
    'CONFIRMED',
    'PENALIZED',
    'CLOSED',
];
export const VIOLATION_EVENT_PENALTY_STATUSES = [
    'PENALIZED',
];
export const VIOLATION_EVENT_DISPUTED_STATUSES = [
    'DISPUTED',
];
export const VIOLATION_EVENT_WAIVED_STATUSES = [
    'WAIVED',
];
export const VIOLATION_EVENT_LEGACY_PENDING_STATUSES = [
    'OPEN',
    'PENDING',
];
export function normalizeViolationEventStatus(status) {
    const normalized = String(status || '').toUpperCase();
    if (VIOLATION_EVENT_LEGACY_PENDING_STATUSES.includes(normalized)) {
        return 'PENDING_REVIEW';
    }
    return normalized;
}
