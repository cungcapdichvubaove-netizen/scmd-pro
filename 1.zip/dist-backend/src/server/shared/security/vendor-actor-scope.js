import { UserRole } from '../../core/architecture/types.js';
const VENDOR_SCOPED_ROLES = new Set([
    UserRole.VENDOR_COMMANDER,
    UserRole.VENDOR_REPRESENTATIVE,
]);
export function isVendorScopedRole(role) {
    return VENDOR_SCOPED_ROLES.has(role);
}
export function requireVendorActorScope(context) {
    if (!isVendorScopedRole(context.role)) {
        return;
    }
    if (!context.assignedVendorId) {
        throw new Error('VENDOR_SCOPE_REQUIRED');
    }
}
export function applyVendorActorScope(context, where) {
    if (!isVendorScopedRole(context.role)) {
        return where;
    }
    requireVendorActorScope(context);
    return {
        ...where,
        vendorId: context.assignedVendorId,
        ...(context.assignedSiteId ? { siteId: context.assignedSiteId } : {}),
        ...(context.assignedContractId ? { contractId: context.assignedContractId } : {}),
    };
}
export function assertVendorActorValueInScope(context, input) {
    if (!isVendorScopedRole(context.role)) {
        return;
    }
    requireVendorActorScope(context);
    if (input.vendorId && input.vendorId !== context.assignedVendorId) {
        throw new Error('VENDOR_SCOPE_MISMATCH');
    }
    if (context.assignedSiteId && input.siteId !== context.assignedSiteId) {
        throw new Error('SITE_SCOPE_MISMATCH');
    }
    if (context.assignedContractId && input.contractId !== context.assignedContractId) {
        throw new Error('CONTRACT_SCOPE_MISMATCH');
    }
}
