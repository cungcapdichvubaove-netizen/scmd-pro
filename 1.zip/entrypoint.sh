#!/bin/sh
set -e
echo "[1/3] Running prisma migrate deploy..."
npx prisma migrate deploy
echo "[2/3] Running custom migrations..."
node run-migration.mjs

if [ "$AUTO_SEED" = "true" ]; then
  echo "[optional] Seeding data..."
  npm run db:seed
fi

echo "[3/3] Starting app..."
exec npm run start
