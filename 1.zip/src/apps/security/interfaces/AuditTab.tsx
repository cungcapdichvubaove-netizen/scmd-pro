import React from "react";
import { motion } from "motion/react";
import { ClipboardCheck, ShieldCheck, Siren } from "lucide-react";
import {
  DashboardMetricCard,
  DashboardMetricGrid,
  DashboardPageHeader,
} from "../../common/interfaces/components/DashboardUI";
import { SurpriseAudit } from "./components/SurpriseAudit";

interface AuditTabProps {
  embedded?: boolean;
}

export const AuditTab: React.FC<AuditTabProps> = ({ embedded = false }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-5"
    >
      {embedded ? (
        <DashboardMetricGrid className="md:grid-cols-3 xl:grid-cols-3">
          <DashboardMetricCard
            label="Mục tiêu"
            value="Kiểm tra đột xuất"
            tone="primary"
            icon={<ShieldCheck size={18} />}
            description="Audit hiện trường phải gắn checklist, bằng chứng và bối cảnh site/vendor"
          />
          <DashboardMetricCard
            label="Nguồn phát sinh"
            value="Theo rủi ro"
            tone="warning"
            icon={<Siren size={18} />}
            description="Ưu tiên audit từ điểm nóng tuần tra, attendance hoặc vi phạm hợp đồng"
          />
          <DashboardMetricCard
            label="Đầu ra"
            value="Có bằng chứng"
            tone="success"
            icon={<ClipboardCheck size={18} />}
            description="Biên bản, checklist và kết luận audit phải dùng được cho đối soát SLA"
          />
        </DashboardMetricGrid>
      ) : (
        <DashboardPageHeader
          title="Kiểm tra đột xuất"
          eyebrow="Audit control"
          description="Khởi tạo phiên kiểm tra hiện trường, ghi nhận checklist và theo dõi lịch sử đánh giá SLA nhà thầu."
        />
      )}
      <SurpriseAudit />
    </motion.div>
  );
};
