import React, { useEffect, useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { AlertCircle, Clock3, RefreshCcw, ShieldAlert, X } from "lucide-react";
import { IncidentLifecycleManager } from "./components/IncidentLifecycleManager";
import { IncidentReport } from "./IncidentReport";
import { SCMDButton } from "../../common/interfaces/components/SCMDButton";
import {
  DashboardFilterBar,
  DashboardFilterGroup,
  DashboardInfoPill,
  dashboardPanelClass,
} from "../../common/interfaces/components/DashboardUI";

export const IncidentsTab: React.FC = () => {
  const [showReportForm, setShowReportForm] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);
  const [lastRefresh, setLastRefresh] = useState(() => new Date());

  const handleCloseReportForm = () => setShowReportForm(false);

  const handleReportSuccess = () => {
    handleCloseReportForm();
    setRefreshKey((prev) => prev + 1);
    setLastRefresh(new Date());
  };

  const handleRefresh = () => {
    setRefreshKey((prev) => prev + 1);
    setLastRefresh(new Date());
  };

  useEffect(() => {
    if (!showReportForm) return undefined;
    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") handleCloseReportForm();
    };
    window.addEventListener("keydown", handleEscape);
    return () => window.removeEventListener("keydown", handleEscape);
  }, [showReportForm]);

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-5">
      <DashboardFilterBar>
        <DashboardFilterGroup>
          <DashboardInfoPill icon={<Clock3 size={14} />}>
            Cập nhật {lastRefresh.toLocaleTimeString("vi-VN", { hour: "2-digit", minute: "2-digit" })}
          </DashboardInfoPill>
          <DashboardInfoPill icon={<ShieldAlert size={14} />} tone="warning">
            Ưu tiên sự cố mở và nguy cơ quá SLA
          </DashboardInfoPill>
        </DashboardFilterGroup>

        <div className="flex w-full flex-wrap items-center gap-2 xl:w-auto xl:justify-end">
          <SCMDButton
            variant="ghost"
            onClick={handleRefresh}
            className="min-h-9 rounded-[10px] border-white/10 bg-white/[0.03] px-4 text-slate-300 hover:bg-white/[0.06] hover:text-white"
          >
            <RefreshCcw size={15} />
            Làm mới
          </SCMDButton>
          <SCMDButton onClick={() => setShowReportForm(true)} className="min-h-9 rounded-[10px] bg-blue-600 px-4 font-semibold text-white hover:bg-blue-500">
            <AlertCircle size={15} />
            Tạo sự cố
          </SCMDButton>
        </div>
      </DashboardFilterBar>

      <IncidentLifecycleManager key={refreshKey} />

      <AnimatePresence>
        {showReportForm && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={handleCloseReportForm}
              className="absolute inset-0 bg-slate-950/88"
            />

            <motion.div
              initial={{ opacity: 0, scale: 0.98, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.98, y: 10 }}
              className={`relative flex max-h-[90vh] w-full max-w-xl flex-col overflow-hidden ${dashboardPanelClass}`}
              role="dialog"
              aria-modal="true"
              aria-label="Tạo sự cố"
            >
              <div className="flex items-center justify-between border-b border-white/8 bg-slate-950/30 p-4">
                <div>
                  <h3 className="text-sm font-semibold text-white">Tạo sự cố</h3>
                  <p className="text-[12px] text-slate-500">Ghi nhận sự cố vận hành và bằng chứng liên quan.</p>
                </div>
                <button
                  type="button"
                  onClick={handleCloseReportForm}
                  className="flex h-9 w-9 items-center justify-center rounded-[10px] border border-white/8 bg-white/[0.035] text-slate-400 transition-colors hover:text-white"
                  aria-label="Đóng"
                >
                  <X size={18} />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto custom-scrollbar">
                <IncidentReport isModal onSuccess={handleReportSuccess} />
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};
