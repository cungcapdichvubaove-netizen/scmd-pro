import React, { useEffect, useMemo, useState } from "react";
import {
  BarChart3,
  Building2,
  Download,
  Eye,
  FileCheck2,
  Loader2,
  Printer,
  RefreshCcw,
  Shield,
} from "lucide-react";
import { apiFetch } from "../../../lib/api";
import { LEGACY_EXCEL_EXTENSION } from "./utils/reportExport";
import { SCMDCard } from "../../common/interfaces/components/SCMDCard";
import {
  DashboardFilterBar,
  DashboardFilterGroup,
  DashboardInfoPill,
  DashboardMetricCard,
  DashboardMetricGrid,
  dashboardInputClass,
  dashboardSelectClass,
} from "../../common/interfaces/components/DashboardUI";
import { SCMDButton } from "../../common/interfaces/components/SCMDButton";
import { FeatureLock } from "../../common/interfaces/components/FeatureLock";
import { PatrolLog } from "./types";
import { useDashboardStore } from "../store/useDashboardStore";

interface ReportsTabProps {
  isPro: boolean;
  patrolLogs: PatrolLog[];
  setShowUpgradeModal: (show: boolean) => void;
  onViewLog: (log: any) => void;
}

interface VendorOption {
  id: string;
  name: string;
  status?: string;
}

interface VendorScorecardRecord {
  id: string;
  vendorId: string;
  contractId?: string | null;
  siteId?: string | null;
  month: string;
  status: string;
  patrolRate: number;
  incidentRate: number;
  disciplineRate: number;
  totalScore: number;
  confirmedViolationsCount: number;
  pendingViolationsCount: number;
  violationsCount: number;
  totalPenaltySuggested: number | string;
  createdAt: string;
}

interface PenaltyItemRecord {
  id: string;
  type: string;
  status: string;
  amount: number | string;
  reason?: string | null;
}

interface ViolationDisputeRecord {
  id: string;
  status: string;
  resolution?: string | null;
  reason: string;
}

interface MonthlyAcceptanceReportRecord {
  id: string;
  vendorId: string;
  contractId?: string | null;
  siteId?: string | null;
  month: string;
  status: string;
  revisionNumber?: number;
  revisionRootId?: string | null;
  previousRevisionId?: string | null;
  supersededAt?: string | null;
  generatedDataHash?: string;
  totalPenaltyAmount: number | string;
  totalConfirmedViolations: number;
  totalPendingViolations: number;
  finalizedAt?: string | null;
  generatedAt: string;
  exportPdfAttachmentId?: string | null;
  exportExcelAttachmentId?: string | null;
  penaltyItems?: PenaltyItemRecord[];
  disputes?: ViolationDisputeRecord[];
}

const getCurrentMonth = () => {
  const now = new Date();
  const year = now.getFullYear();
  const month = `${now.getMonth() + 1}`.padStart(2, "0");
  return `${year}-${month}`;
};

const unwrapCollection = <T,>(payload: any): T[] => {
  if (Array.isArray(payload)) return payload as T[];
  if (Array.isArray(payload?.items)) return payload.items as T[];
  if (Array.isArray(payload?.data)) return payload.data as T[];
  return [];
};

const currencyFormatter = new Intl.NumberFormat("vi-VN", {
  style: "currency",
  currency: "VND",
  maximumFractionDigits: 0,
});

const scoreFormatter = new Intl.NumberFormat("vi-VN", {
  minimumFractionDigits: 1,
  maximumFractionDigits: 1,
});

const percentFormatter = new Intl.NumberFormat("vi-VN", {
  minimumFractionDigits: 0,
  maximumFractionDigits: 1,
});

const dateTimeFormatter = new Intl.DateTimeFormat("vi-VN", {
  dateStyle: "short",
  timeStyle: "short",
});

const formatCurrency = (value: number | string | null | undefined) => {
  const normalized = Number(value ?? 0);
  return currencyFormatter.format(Number.isFinite(normalized) ? normalized : 0);
};

const formatPercent = (value: number | string | null | undefined) => {
  const normalized = Number(value ?? 0);
  return `${percentFormatter.format(Number.isFinite(normalized) ? normalized : 0)}%`;
};

const formatScore = (value: number | string | null | undefined) => {
  const normalized = Number(value ?? 0);
  return scoreFormatter.format(Number.isFinite(normalized) ? normalized : 0);
};

const formatDateTime = (value: string | null | undefined) => {
  if (!value) return null;
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return null;
  return dateTimeFormatter.format(date);
};

const statusClassName = (status: string) => {
  const normalized = status.toUpperCase();
  if (normalized === "FINALIZED" || normalized === "COMPLETED") {
    return "border border-emerald-500/20 bg-emerald-500/10 text-emerald-300";
  }
  if (normalized === "SUPERSEDED") {
    return "border border-fuchsia-500/20 bg-fuchsia-500/10 text-fuchsia-300";
  }
  if (
    normalized === "QUEUED" ||
    normalized === "PENDING" ||
    normalized === "PENDING_REVIEW"
  ) {
    return "border border-amber-500/20 bg-amber-500/10 text-amber-300";
  }
  if (normalized === "DRAFT" || normalized === "OPEN") {
    return "border border-blue-500/20 bg-blue-500/10 text-blue-300";
  }
  return "border border-slate-700 bg-slate-800 text-slate-300";
};

export const ReportsTab: React.FC<ReportsTabProps> = React.memo(
  ({ isPro, patrolLogs, setShowUpgradeModal, onViewLog }) => {
    const tenantInfo = useDashboardStore((state) => state.tenantInfo);
    const scorecardEnabled =
      tenantInfo?.resolvedFeatures?.vendor_scorecard !== false;
    const monthlyAcceptanceEnabled =
      tenantInfo?.resolvedFeatures?.monthly_acceptance_report !== false;
    const vendorManagementEnabled =
      tenantInfo?.resolvedFeatures?.vendor_management !== false;
    const canLoadReports =
      isPro && scorecardEnabled && monthlyAcceptanceEnabled;
    const canLoadVendors = canLoadReports && vendorManagementEnabled;
    const [month, setMonth] = useState(getCurrentMonth);
    const [vendorId, setVendorId] = useState("");
    const [vendors, setVendors] = useState<VendorOption[]>([]);
    const [scorecards, setScorecards] = useState<VendorScorecardRecord[]>([]);
    const [reports, setReports] = useState<MonthlyAcceptanceReportRecord[]>([]);
    const [loadingVendors, setLoadingVendors] = useState(false);
    const [loadingReports, setLoadingReports] = useState(false);
    const [generating, setGenerating] = useState(false);
    const [actingReportId, setActingReportId] = useState<string | null>(null);
    const [featureDependencyMissing, setFeatureDependencyMissing] =
      useState(false);

    const isFeatureBlocked = !canLoadReports || featureDependencyMissing;

    const vendorMap = useMemo(() => {
      return new Map(vendors.map((vendor) => [vendor.id, vendor.name]));
    }, [vendors]);

    const loadVendors = async () => {
      if (!canLoadVendors) {
        setVendors([]);
        return;
      }

      setLoadingVendors(true);
      try {
        const payload = await apiFetch<any>("/api/admin/vendors?limit=100", {
          suppressErrorToast: true,
        });
        setFeatureDependencyMissing(false);
        setVendors(
          unwrapCollection<VendorOption>(payload).filter(
            (vendor) => vendor?.id && vendor?.name,
          ),
        );
      } catch (error: any) {
        if (
          error?.status === 403 &&
          error?.message === "FEATURE_DEPENDENCY_MISSING"
        ) {
          setFeatureDependencyMissing(true);
        }
        setVendors([]);
      } finally {
        setLoadingVendors(false);
      }
    };

    const loadComplianceData = async () => {
      if (!canLoadReports) {
        setScorecards([]);
        setReports([]);
        return;
      }

      setLoadingReports(true);
      try {
        const params = new URLSearchParams({ month, limit: "50" });
        if (vendorId) params.set("vendorId", vendorId);

        const [scorecardPayload, reportPayload] = await Promise.all([
          apiFetch<any>(`/api/tenant/vendor-scorecards?${params.toString()}`, {
            suppressErrorToast: true,
          }),
          apiFetch<any>(
            `/api/tenant/monthly-acceptance-reports?${params.toString()}`,
            { suppressErrorToast: true },
          ),
        ]);

        setFeatureDependencyMissing(false);
        setScorecards(
          unwrapCollection<VendorScorecardRecord>(scorecardPayload),
        );
        setReports(
          unwrapCollection<MonthlyAcceptanceReportRecord>(reportPayload),
        );
      } catch (error: any) {
        if (
          error?.status === 403 &&
          (error?.message === "FEATURE_DEPENDENCY_MISSING" ||
            error?.message === "FEATURE_DISABLED")
        ) {
          setFeatureDependencyMissing(
            error?.message === "FEATURE_DEPENDENCY_MISSING",
          );
          setScorecards([]);
          setReports([]);
          return;
        }
        throw error;
      } finally {
        setLoadingReports(false);
      }
    };

    useEffect(() => {
      void loadVendors();
    }, [canLoadVendors]);

    useEffect(() => {
      void loadComplianceData();
    }, [canLoadReports, month, vendorId]);

    const handleGenerateReport = async () => {
      if (!vendorId) return;
      setGenerating(true);
      try {
        await apiFetch("/api/tenant/monthly-acceptance-reports/generate", {
          method: "POST",
          body: JSON.stringify({ month, vendorId }),
        });
        await loadComplianceData();
      } finally {
        setGenerating(false);
      }
    };

    const handleFinalizeReport = async (reportId: string) => {
      setActingReportId(reportId);
      try {
        await apiFetch(
          `/api/tenant/monthly-acceptance-reports/${reportId}/finalize`,
          {
            method: "POST",
            body: JSON.stringify({
              notes: "Finalized from Command Center report workspace",
            }),
          },
        );
        await loadComplianceData();
      } finally {
        setActingReportId(null);
      }
    };

    const handleCreateRevision = async (reportId: string) => {
      setActingReportId(reportId);
      try {
        await apiFetch(
          `/api/tenant/monthly-acceptance-reports/${reportId}/revisions`,
          {
            method: "POST",
            body: JSON.stringify({
              notes: "Revision created from report workspace",
            }),
          },
        );
        await loadComplianceData();
      } finally {
        setActingReportId(null);
      }
    };

    const handleQueueExport = async (
      reportId: string,
      format: "pdf" | "excel",
    ) => {
      setActingReportId(reportId);
      try {
        await apiFetch(
          `/api/tenant/monthly-acceptance-reports/${reportId}/export`,
          {
            method: "POST",
            body: JSON.stringify({ format }),
          },
        );
        await loadComplianceData();
      } finally {
        setActingReportId(null);
      }
    };

    const handleDownloadArtifact = async (
      reportId: string,
      attachmentId: string,
      format: "pdf" | "excel",
    ) => {
      setActingReportId(reportId);
      try {
        const blob = await apiFetch<Blob>(
          `/api/tenant/monthly-acceptance-reports/${reportId}/artifacts/${attachmentId}/download`,
          { responseType: "blob" },
        );
        const objectUrl = window.URL.createObjectURL(blob);
        const anchor = document.createElement("a");
        anchor.href = objectUrl;
        anchor.download = `monthly-acceptance-${reportId}.${format === "pdf" ? "pdf" : LEGACY_EXCEL_EXTENSION}`;
        document.body.appendChild(anchor);
        anchor.click();
        anchor.remove();
        window.URL.revokeObjectURL(objectUrl);
      } finally {
        setActingReportId(null);
      }
    };

    const complianceSummary = useMemo(() => {
      const finalizedReports = reports.filter(
        (report) => report.status === "FINALIZED",
      ).length;
      const draftReports = reports.filter(
        (report) =>
          report.status !== "FINALIZED" && report.status !== "SUPERSEDED",
      ).length;
      return {
        scorecards: scorecards.length,
        reports: reports.length,
        finalizedReports,
        draftReports,
        totalPenalty: reports.reduce(
          (sum, report) => sum + Number(report.totalPenaltyAmount ?? 0),
          0,
        ),
        pendingViolations: reports.reduce(
          (sum, report) => sum + Number(report.totalPendingViolations ?? 0),
          0,
        ),
      };
    }, [reports, scorecards]);

    const topScorecard = useMemo(() => {
      return (
        [...scorecards].sort(
          (left, right) =>
            Number(right.totalScore ?? 0) - Number(left.totalScore ?? 0),
        )[0] ?? null
      );
    }, [scorecards]);

    const displayedPatrolLogs = Array.isArray(patrolLogs)
      ? patrolLogs.slice(0, 8)
      : [];
    const selectedVendorLabel = vendorId
      ? vendorMap.get(vendorId) || vendorId
      : "Tất cả nhà thầu";

    if (isFeatureBlocked) {
      return (
        <FeatureLock
          title="Báo cáo nghiệm thu và scorecard vendor"
          description={
            featureDependencyMissing
              ? "Tenant đang thiếu feature phụ thuộc trong Feature Flag Matrix nên backend chặn truy cập để giữ nhất quán."
              : "Tenant chưa bật Vendor Scorecard hoặc Monthly Acceptance Report."
          }
          onUpgrade={() => setShowUpgradeModal(true)}
        />
      );
    }

    return (
      <div className="space-y-5">
        <DashboardFilterBar className="items-end">
          <DashboardFilterGroup>
            <label className="min-w-[170px] flex-1">
              <span className="mb-1 block text-[11px] font-semibold text-slate-500">
                Kỳ đối soát
              </span>
              <input
                type="month"
                value={month}
                onChange={(event) => setMonth(event.target.value)}
                className={dashboardInputClass}
              />
            </label>
            <label className="min-w-[210px] flex-1">
              <span className="mb-1 block text-[11px] font-semibold text-slate-500">
                Nhà thầu
              </span>
              <select
                value={vendorId}
                onChange={(event) => setVendorId(event.target.value)}
                className={dashboardSelectClass}
                disabled={loadingVendors}
              >
                <option value="">Tất cả nhà thầu</option>
                {vendors.map((vendor) => (
                  <option key={vendor.id} value={vendor.id}>
                    {vendor.name}
                  </option>
                ))}
              </select>
            </label>
          </DashboardFilterGroup>
          <DashboardInfoPill icon={<Building2 size={14} />}>
            {selectedVendorLabel}
          </DashboardInfoPill>
          <SCMDButton
            variant="ghost"
            onClick={() => void loadComplianceData()}
            className="h-9 rounded-[10px] px-3 text-xs"
            disabled={loadingReports}
          >
            {loadingReports ? (
              <Loader2 size={14} className="animate-spin" />
            ) : (
              <RefreshCcw size={14} />
            )}
            Làm mới
          </SCMDButton>
          <SCMDButton
            onClick={handleGenerateReport}
            disabled={!vendorId || generating}
            className="h-9 rounded-[10px] px-3 text-xs"
          >
            {generating ? (
              <Loader2 size={14} className="animate-spin" />
            ) : (
              <FileCheck2 size={14} />
            )}
            Tạo báo cáo tháng
          </SCMDButton>
        </DashboardFilterBar>

        <DashboardMetricGrid className="md:grid-cols-4">
          <DashboardMetricCard
            label="Scorecard"
            value={complianceSummary.scorecards}
            description="Bản ghi trong kỳ lọc"
            icon={<BarChart3 size={18} />}
          />
          <DashboardMetricCard
            label="Báo cáo"
            value={complianceSummary.reports}
            description={`${complianceSummary.finalizedReports} đã chốt / ${complianceSummary.draftReports} đang xử lý`}
            icon={<FileCheck2 size={18} />}
            tone={complianceSummary.draftReports > 0 ? "warning" : "success"}
          />
          <DashboardMetricCard
            label="Phạt đề xuất"
            value={formatCurrency(complianceSummary.totalPenalty)}
            description="Tổng theo bộ lọc hiện tại"
            tone={complianceSummary.totalPenalty > 0 ? "danger" : "success"}
          />
          <DashboardMetricCard
            label="Vi phạm chờ xử lý"
            value={complianceSummary.pendingViolations}
            description="Cần review trước nghiệm thu"
            tone={complianceSummary.pendingViolations > 0 ? "warning" : "success"}
          />
        </DashboardMetricGrid>

        <div className="grid grid-cols-1 gap-5 xl:grid-cols-[minmax(0,1fr)_360px]">
          <SCMDCard className="rounded-[14px] border border-white/8 bg-white/[0.035] p-4">
            <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
              <div>
                <h3 className="text-sm font-semibold text-white">
                  Vendor scorecard
                </h3>
                <p className="mt-1 text-xs text-slate-400">
                  Quét nhanh chất lượng vận hành trước khi chốt báo cáo tháng.
                </p>
              </div>
              {loadingReports ? (
                <DashboardInfoPill icon={<Loader2 size={14} className="animate-spin" />}>
                  Đang đồng bộ
                </DashboardInfoPill>
              ) : null}
            </div>

            {scorecards.length === 0 ? (
              <div className="rounded-[12px] border border-dashed border-white/10 p-8 text-center text-sm text-slate-400">
                Chưa có scorecard cho bộ lọc hiện tại.
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
                {scorecards.map((scorecard) => (
                  <article
                    key={scorecard.id}
                    className="rounded-[12px] border border-white/8 bg-slate-950/25 p-4"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <p className="text-sm font-semibold text-white">
                          {vendorMap.get(scorecard.vendorId) ||
                            scorecard.vendorId}
                        </p>
                        <p className="mt-1 text-xs text-slate-500">
                          Kỳ {scorecard.month} ·{" "}
                          {scorecard.confirmedViolationsCount} vi phạm xác nhận
                        </p>
                      </div>
                      <span className="text-2xl font-semibold text-white">
                        {formatScore(scorecard.totalScore)}
                      </span>
                    </div>
                    <div className="mt-4 grid grid-cols-3 gap-2 text-xs">
                      <Metric label="Tuần tra" value={formatPercent(scorecard.patrolRate)} />
                      <Metric label="Sự cố" value={formatPercent(scorecard.incidentRate)} />
                      <Metric label="Kỷ luật" value={formatPercent(scorecard.disciplineRate)} />
                    </div>
                    <div className="mt-4 flex items-center justify-between rounded-[10px] border border-white/8 bg-white/[0.025] px-3 py-2 text-xs">
                      <span className="text-slate-400">Phạt đề xuất</span>
                      <span className="font-semibold text-amber-200">
                        {formatCurrency(scorecard.totalPenaltySuggested)}
                      </span>
                    </div>
                  </article>
                ))}
              </div>
            )}
          </SCMDCard>

          <SCMDCard className="rounded-[14px] border border-white/8 bg-white/[0.035] p-4">
            <h3 className="text-sm font-semibold text-white">Tín hiệu nhanh</h3>
            <div className="mt-4 space-y-3">
              <Insight
                label="Nhà thầu đang xem"
                value={selectedVendorLabel}
              />
              <Insight
                label="Trạng thái kỳ báo cáo"
                value={
                  complianceSummary.finalizedReports > 0
                    ? "Đã có báo cáo finalized"
                    : "Chưa chốt nghiệm thu"
                }
              />
              <Insight
                label="Vendor nổi bật"
                value={
                  topScorecard
                    ? `${vendorMap.get(topScorecard.vendorId) || topScorecard.vendorId}: ${formatScore(topScorecard.totalScore)} điểm`
                    : "Chưa có dữ liệu scorecard"
                }
              />
              <Insight
                label="Hành động khuyến nghị"
                value="Rà soát vi phạm pending, tạo report cho nhà thầu cần đối soát, sau đó finalize và xuất artifact."
              />
            </div>
          </SCMDCard>
        </div>

        <SCMDCard className="rounded-[14px] border border-white/8 bg-white/[0.035] p-4">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-semibold text-white">
                Báo cáo nghiệm thu tháng
              </h3>
              <p className="mt-1 text-xs text-slate-400">
                Khu vực thao tác chính cho finalize, revision và export artifact.
              </p>
            </div>
            <DashboardInfoPill icon={<Shield size={14} />}>
              {reports.length} báo cáo
            </DashboardInfoPill>
          </div>

          {reports.length === 0 ? (
            <div className="rounded-[12px] border border-dashed border-white/10 p-8 text-center text-sm text-slate-400">
              Chưa có báo cáo nghiệm thu tháng cho bộ lọc hiện tại.
            </div>
          ) : (
            <div className="space-y-3">
              {reports.map((report) => {
                const generatedAt = formatDateTime(report.generatedAt);
                const finalizedAt = formatDateTime(report.finalizedAt);
                const isActing = actingReportId === report.id;
                const isFinalized = report.status === "FINALIZED";

                return (
                  <article
                    key={report.id}
                    className="rounded-[12px] border border-white/8 bg-slate-950/25 p-4"
                  >
                    <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                      <div className="min-w-0">
                        <div className="flex flex-wrap items-center gap-2">
                          <h4 className="text-sm font-semibold text-white">
                            {vendorMap.get(report.vendorId) || report.vendorId}
                          </h4>
                          <span className={statusClassName(report.status) + " rounded-full px-2.5 py-1 text-[11px] font-semibold"}>
                            {report.status}
                          </span>
                          <span className="rounded-full border border-slate-700 bg-slate-900 px-2.5 py-1 text-[11px] font-semibold text-slate-300">
                            Rev.{report.revisionNumber ?? 1}
                          </span>
                        </div>
                        <p className="mt-2 text-xs text-slate-500">
                          Kỳ {report.month}
                          {generatedAt ? ` · Tạo ${generatedAt}` : ""}
                          {finalizedAt ? ` · Chốt ${finalizedAt}` : ""}
                        </p>
                      </div>

                      <div className="grid grid-cols-2 gap-2 text-xs sm:grid-cols-4 lg:min-w-[360px]">
                        <Metric label="Tổng phạt" value={formatCurrency(report.totalPenaltyAmount)} />
                        <Metric label="Đã xác nhận" value={report.totalConfirmedViolations} />
                        <Metric label="Chờ xử lý" value={report.totalPendingViolations} />
                        <Metric label="Tranh chấp" value={report.disputes?.length ?? 0} />
                      </div>
                    </div>

                    <div className="mt-4 flex flex-wrap gap-2">
                      {!isFinalized ? (
                        <SCMDButton
                          onClick={() => void handleFinalizeReport(report.id)}
                          disabled={isActing}
                          className="h-9 rounded-[10px] px-3 text-xs"
                        >
                          {isActing ? <Loader2 size={14} className="animate-spin" /> : <Shield size={14} />}
                          Chốt báo cáo
                        </SCMDButton>
                      ) : (
                        <SCMDButton
                          variant="ghost"
                          onClick={() => void handleCreateRevision(report.id)}
                          disabled={isActing}
                          className="h-9 rounded-[10px] px-3 text-xs"
                        >
                          {isActing ? <Loader2 size={14} className="animate-spin" /> : <RefreshCcw size={14} />}
                          Tạo revision
                        </SCMDButton>
                      )}

                      <SCMDButton
                        variant="ghost"
                        onClick={() => void handleQueueExport(report.id, "pdf")}
                        disabled={isActing}
                        className="h-9 rounded-[10px] px-3 text-xs"
                      >
                        <Printer size={14} />
                        Xuất PDF
                      </SCMDButton>
                      <SCMDButton
                        variant="ghost"
                        onClick={() => void handleQueueExport(report.id, "excel")}
                        disabled={isActing}
                        className="h-9 rounded-[10px] px-3 text-xs"
                      >
                        <Download size={14} />
                        Xuất Excel
                      </SCMDButton>
                      {report.exportPdfAttachmentId ? (
                        <SCMDButton
                          variant="ghost"
                          onClick={() =>
                            void handleDownloadArtifact(
                              report.id,
                              report.exportPdfAttachmentId!,
                              "pdf",
                            )
                          }
                          disabled={isActing}
                          className="h-9 rounded-[10px] px-3 text-xs"
                        >
                          Tải PDF
                        </SCMDButton>
                      ) : null}
                      {report.exportExcelAttachmentId ? (
                        <SCMDButton
                          variant="ghost"
                          onClick={() =>
                            void handleDownloadArtifact(
                              report.id,
                              report.exportExcelAttachmentId!,
                              "excel",
                            )
                          }
                          disabled={isActing}
                          className="h-9 rounded-[10px] px-3 text-xs"
                        >
                          Tải Excel
                        </SCMDButton>
                      ) : null}
                    </div>
                  </article>
                );
              })}
            </div>
          )}
        </SCMDCard>

        <SCMDCard className="rounded-[14px] border border-white/8 bg-white/[0.035] p-4">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-semibold text-white">
                Lịch sử tuần tra gần nhất
              </h3>
              <p className="mt-1 text-xs text-slate-400">
                Giữ ngữ cảnh evidence ở danh sách ngắn để không làm loãng nhiệm vụ chính.
              </p>
            </div>
            <DashboardInfoPill>{displayedPatrolLogs.length} bản ghi</DashboardInfoPill>
          </div>

          {displayedPatrolLogs.length === 0 ? (
            <div className="rounded-[12px] border border-dashed border-white/10 p-8 text-center text-sm text-slate-400">
              Chưa có lịch sử tuần tra được ghi nhận.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table>
                <thead>
                  <tr>
                    <th>Thời gian</th>
                    <th>Nhân viên</th>
                    <th>Điểm</th>
                    <th>Trạng thái</th>
                    <th>Thao tác</th>
                  </tr>
                </thead>
                <tbody>
                  {displayedPatrolLogs.map((log: any) => (
                    <tr key={log.id}>
                      <td>
                        {log.timestamp
                          ? new Date(log.timestamp).toLocaleString("vi-VN")
                          : "-"}
                      </td>
                      <td>{log.staffName || log.staffId || "-"}</td>
                      <td>{log.checkpointName || "-"}</td>
                      <td>
                        <span
                          className={
                            log.isSuspicious
                              ? "rounded-full border border-red-500/20 bg-red-500/10 px-2 py-1 text-[11px] font-semibold text-red-300"
                              : "rounded-full border border-emerald-500/20 bg-emerald-500/10 px-2 py-1 text-[11px] font-semibold text-emerald-300"
                          }
                        >
                          {log.isSuspicious ? "Nghi vấn" : "Hợp lệ"}
                        </span>
                      </td>
                      <td>
                        <button
                          type="button"
                          onClick={() => onViewLog(log)}
                          className="inline-flex h-8 items-center gap-2 rounded-[9px] border border-white/10 bg-white/[0.035] px-3 text-xs font-semibold text-slate-200 hover:bg-white/[0.06]"
                        >
                          <Eye size={14} />
                          Chi tiết
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </SCMDCard>
      </div>
    );
  },
);

const Metric = ({
  label,
  value,
}: {
  label: React.ReactNode;
  value: React.ReactNode;
}) => (
  <div className="rounded-[10px] border border-white/8 bg-white/[0.025] px-3 py-2">
    <p className="text-[11px] text-slate-500">{label}</p>
    <p className="mt-1 text-sm font-semibold text-white">{value}</p>
  </div>
);

const Insight = ({
  label,
  value,
}: {
  label: React.ReactNode;
  value: React.ReactNode;
}) => (
  <div className="rounded-[10px] border border-white/8 bg-slate-950/25 px-3 py-3">
    <p className="text-[11px] text-slate-500">{label}</p>
    <p className="mt-1 text-sm font-semibold leading-5 text-slate-200">
      {value}
    </p>
  </div>
);
