import { useState, useEffect } from "react";
import { motion } from "motion/react";
import {
  Mail,
  MessageSquare,
  Save,
  CheckCircle2,
  ShieldAlert,
} from "lucide-react";
import { apiFetch } from "../../../lib/api";
import { SCMDButton } from "../../common/interfaces/components/SCMDButton";
import {
  DashboardErrorState,
  DashboardPageHeader,
  DashboardSpinner,
  dashboardInputClass,
  dashboardPanelClass,
} from "../../common/interfaces/components/DashboardUI";
import { cn } from "../../../lib/utils";

const settingsFieldLabelClass =
  "mb-2 block text-[10px] font-black uppercase tracking-[0.16em] text-scmd-silver/55";
const settingsToggleClass =
  "h-5 w-5 rounded-md border border-white/15 bg-scmd-navy accent-scmd-primary focus:ring-2 focus:ring-scmd-primary/30";

export const SettingsTab = () => {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [settings, setSettings] = useState({
    notifications: {
      email: {
        enabled: false,
        smtpHost: "",
        smtpPort: "",
        smtpUser: "",
        smtpPass: "",
        smtpFrom: "",
      },
      zalo: {
        enabled: true,
        startTime: "00:00",
        endTime: "23:59",
      },
    },
  });

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await apiFetch("/api/tenant/settings");
      if (data.settings?.notifications) {
        setSettings((prev) => ({
          ...prev,
          notifications: {
            ...prev.notifications,
            ...data.settings.notifications,
          },
        }));
      }
    } catch (err) {
      console.error("Lỗi tải cài đặt:", err);
      setError("Không thể tải cài đặt tenant. Vui lòng thử lại.");
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await apiFetch("/api/tenant/settings", {
        method: "PUT",
        body: JSON.stringify({ settings }),
      });
      setSuccess(true);
      setTimeout(() => setSuccess(false), 3000);
    } catch (err) {
      console.error("Lỗi lưu cài đặt:", err);
      setError(
        "Không thể lưu cài đặt. Vui lòng kiểm tra lại thông tin và thử lại.",
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <DashboardSpinner message="Đang tải cài đặt tenant..." fullHeight />;
  }

  return (
    <div className="mx-auto max-w-5xl space-y-6 pb-24">
      <DashboardPageHeader
        title="Cài đặt hệ thống"
        description="Tùy chỉnh kênh thông báo và kết nối phục vụ cảnh báo sự cố, báo cáo ca trực và nghiệm thu vận hành."
        eyebrow="Tenant settings"
      />

      {error && (
        <DashboardErrorState
          title="Có lỗi khi xử lý cài đặt"
          description={error}
          onRetry={fetchSettings}
          className="py-10"
        />
      )}

      <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
        {/* Email Settings */}
        <motion.div
          className={cn(dashboardPanelClass, "p-5 sm:p-6")}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="flex items-center gap-3 mb-6 pb-4 border-b border-white/5">
            <div className="w-10 h-10 bg-scmd-primary/10 text-scmd-primary rounded-xl flex items-center justify-center">
              <Mail size={20} />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white uppercase tracking-widest">
                Máy chủ Email (SMTP)
              </h2>
              <p className="text-[11px] text-scmd-silver/60">
                Sử dụng để gửi Report và Cảnh báo qua Email
              </p>
            </div>
          </div>

          <div className="space-y-4">
            <label className="flex min-h-[48px] cursor-pointer items-center gap-3 rounded-xl border border-white/10 bg-scmd-surface/50 p-3">
              <input
                type="checkbox"
                className={settingsToggleClass}
                checked={settings.notifications.email.enabled}
                onChange={(e) =>
                  setSettings((s) => ({
                    ...s,
                    notifications: {
                      ...s.notifications,
                      email: {
                        ...s.notifications.email,
                        enabled: e.target.checked,
                      },
                    },
                  }))
                }
              />
              <span className="text-sm font-medium text-white">
                Kích hoạt thông báo Email
              </span>
            </label>

            {settings.notifications.email.enabled && (
              <div className="space-y-4 mt-4 animate-in fade-in slide-in-from-top-2">
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div className="space-y-0">
                    <label className={settingsFieldLabelClass}>
                      Máy chủ SMTP
                    </label>
                    <input
                      type="text"
                      className={dashboardInputClass}
                      placeholder="smtp.gmail.com"
                      value={settings.notifications.email.smtpHost}
                      onChange={(e) =>
                        setSettings((s) => ({
                          ...s,
                          notifications: {
                            ...s.notifications,
                            email: {
                              ...s.notifications.email,
                              smtpHost: e.target.value,
                            },
                          },
                        }))
                      }
                    />
                  </div>
                  <div className="space-y-0">
                    <label className={settingsFieldLabelClass}>Cổng SMTP</label>
                    <input
                      type="text"
                      className={dashboardInputClass}
                      placeholder="587"
                      value={settings.notifications.email.smtpPort}
                      onChange={(e) =>
                        setSettings((s) => ({
                          ...s,
                          notifications: {
                            ...s.notifications,
                            email: {
                              ...s.notifications.email,
                              smtpPort: e.target.value,
                            },
                          },
                        }))
                      }
                    />
                  </div>
                </div>

                <div className="space-y-0">
                  <label className={settingsFieldLabelClass}>SMTP User</label>
                  <input
                    type="text"
                    className={dashboardInputClass}
                    placeholder="admin@domain.com"
                    value={settings.notifications.email.smtpUser}
                    onChange={(e) =>
                      setSettings((s) => ({
                        ...s,
                        notifications: {
                          ...s.notifications,
                          email: {
                            ...s.notifications.email,
                            smtpUser: e.target.value,
                          },
                        },
                      }))
                    }
                  />
                </div>

                <div className="space-y-0">
                  <label className={settingsFieldLabelClass}>
                    SMTP Password / App Password
                  </label>
                  <input
                    type="password"
                    className={dashboardInputClass}
                    placeholder="••••••••••••"
                    value={settings.notifications.email.smtpPass}
                    onChange={(e) =>
                      setSettings((s) => ({
                        ...s,
                        notifications: {
                          ...s.notifications,
                          email: {
                            ...s.notifications.email,
                            smtpPass: e.target.value,
                          },
                        },
                      }))
                    }
                  />
                  <span className="text-[10px] text-scmd-alert mt-2 flex gap-1 items-center">
                    <ShieldAlert size={10} /> Password sẽ được lưu trữ cục bộ
                    tại Tenant JSON
                  </span>
                </div>

                <div className="space-y-0">
                  <label className={settingsFieldLabelClass}>
                    Gửi từ (From Email)
                  </label>
                  <input
                    type="email"
                    className={dashboardInputClass}
                    placeholder="no-reply@domain.com"
                    value={settings.notifications.email.smtpFrom}
                    onChange={(e) =>
                      setSettings((s) => ({
                        ...s,
                        notifications: {
                          ...s.notifications,
                          email: {
                            ...s.notifications.email,
                            smtpFrom: e.target.value,
                          },
                        },
                      }))
                    }
                  />
                </div>
              </div>
            )}
          </div>
        </motion.div>

        {/* Zalo Settings */}
        <motion.div
          className={cn(dashboardPanelClass, "p-5 sm:p-6")}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0, transition: { delay: 0.1 } }}
        >
          <div className="flex items-center gap-3 mb-6 pb-4 border-b border-white/5">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-scmd-primary/10 text-scmd-primary">
              <MessageSquare size={20} />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white uppercase tracking-widest">
                Kênh thông báo Zalo
              </h2>
              <p className="text-[11px] text-scmd-silver/60">
                Sử dụng Zalo OA nội bộ của SCMD Pro
              </p>
            </div>
          </div>

          <div className="space-y-4">
            <label className="flex min-h-[48px] cursor-pointer items-center gap-3 rounded-xl border border-white/10 bg-scmd-surface/50 p-3">
              <input
                type="checkbox"
                className={settingsToggleClass}
                checked={settings.notifications.zalo.enabled}
                onChange={(e) =>
                  setSettings((s) => ({
                    ...s,
                    notifications: {
                      ...s.notifications,
                      zalo: {
                        ...s.notifications.zalo,
                        enabled: e.target.checked,
                      },
                    },
                  }))
                }
              />
              <span className="text-sm font-medium text-white">
                Kích hoạt nhận tin Zalo
              </span>
            </label>

            {settings.notifications.zalo.enabled && (
              <div className="space-y-4 mt-4 animate-in fade-in slide-in-from-top-2">
                <div className="rounded-2xl border border-scmd-primary/20 bg-scmd-primary/5 p-4">
                  <p className="text-xs font-semibold leading-relaxed text-scmd-primary">
                    Hệ thống sẽ gửi cảnh báo khẩn cấp và báo cáo tự động qua
                    Zalo cho các số điện thoại được gán quyền Admin / Supervisor
                    trong danh sách Nhân sự.
                  </p>
                </div>

                <h3 className="text-xs font-bold text-white mb-2 pt-2">
                  Khung giờ nhận tin nhắn hệ thống
                </h3>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-[1fr_auto_1fr] sm:items-center">
                  <div className="space-y-0">
                    <label className={settingsFieldLabelClass}>
                      Giờ bắt đầu
                    </label>
                    <input
                      type="time"
                      className={dashboardInputClass}
                      value={settings.notifications.zalo.startTime}
                      onChange={(e) =>
                        setSettings((s) => ({
                          ...s,
                          notifications: {
                            ...s.notifications,
                            zalo: {
                              ...s.notifications.zalo,
                              startTime: e.target.value,
                            },
                          },
                        }))
                      }
                    />
                  </div>
                  <div className="hidden pt-6 text-scmd-silver/40 sm:block">
                    -
                  </div>
                  <div className="space-y-0">
                    <label className={settingsFieldLabelClass}>
                      Giờ kết thúc
                    </label>
                    <input
                      type="time"
                      className={dashboardInputClass}
                      value={settings.notifications.zalo.endTime}
                      onChange={(e) =>
                        setSettings((s) => ({
                          ...s,
                          notifications: {
                            ...s.notifications,
                            zalo: {
                              ...s.notifications.zalo,
                              endTime: e.target.value,
                            },
                          },
                        }))
                      }
                    />
                  </div>
                </div>
                <p className="text-[10px] text-scmd-silver/60 mt-1">
                  Lưu ý: Các cảnh báo SOS khẩn cấp (có thương vong, cháy nổ) sẽ{" "}
                  <strong>BỎ QUA</strong> khung giờ này và luôn được gửi.
                </p>
              </div>
            )}
          </div>
        </motion.div>
      </div>

      <div className="flex justify-end pt-2">
        <SCMDButton
          onClick={handleSave}
          disabled={saving}
          variant="primary"
          className="h-14 w-full rounded-xl sm:w-auto"
        >
          {saving ? (
            <span className="h-5 w-5 animate-spin rounded-full border-2 border-white/30 border-t-white" />
          ) : success ? (
            <CheckCircle2 size={18} />
          ) : (
            <Save size={18} />
          )}
          {success ? "Đã lưu cài đặt" : "Lưu cài đặt"}
        </SCMDButton>
      </div>
    </div>
  );
};
