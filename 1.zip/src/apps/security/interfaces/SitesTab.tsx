import React from 'react';
import {
  Check,
  Loader2,
  MapPin,
  Navigation,
  Pencil,
  Plus,
  QrCode,
  Sparkles,
  Target,
  Trash2,
  Zap,
} from 'lucide-react';
import { motion } from 'motion/react';
import { cn } from '../../../lib/utils';
import { getAuthHeaders } from '../../common/utils/auth';
import {
  DashboardErrorState,
  DashboardMetricCard,
  DashboardMetricGrid,
  DashboardSpinner,
  dashboardTabButtonClass,
} from '../../common/interfaces/components/DashboardUI';
import { BenchmarkLearningMode } from './components/BenchmarkLearningMode';
import { TacticalMap, type MapPoint } from './components/TacticalMap';
import { AdminBenchmarkRecorder } from './AdminBenchmarkRecorder';
import type { AttendanceOpsSummary } from './AttendanceTab';
import type { Checkpoint, CheckItem, PatrolRoute } from './types';

interface SitesTabProps {
  contextualFilters?: Record<string, string>;
  checkpoints: Checkpoint[];
  checkpointsNextCursor: string | null;
  hasMoreCheckpoints: boolean;
  loadMoreCheckpoints: () => void;
  loadingMoreCheckpoints: boolean;
  routes: PatrolRoute[];
  editingCheckpoint: Checkpoint | null;
  newCheckpoint: { name: string; qr_hash: string; latitude: number; longitude: number; check_items: CheckItem[] };
  isSubmitting: boolean;
  siteSubTab: 'manage' | 'benchmark' | 'field' | 'map';
  setSiteSubTab: (v: 'manage' | 'benchmark' | 'field' | 'map') => void;
  setCheckpoints: React.Dispatch<React.SetStateAction<Checkpoint[]>>;
  setNewCheckpoint: React.Dispatch<
    React.SetStateAction<{ name: string; qr_hash: string; latitude: number; longitude: number; check_items: CheckItem[] }>
  >;
  setShowConfirmModal: (v: { id: string; type: 'checkpoint' | 'staff' | 'route'; name: string } | null) => void;
  setShowQRModal: (v: Checkpoint | null) => void;
  setMessage: (v: { text: string; type: 'success' | 'error' } | null) => void;
  setActiveTab: (tab: any) => void;
  startEditingCheckpoint: (cp: Checkpoint) => void;
  cancelEditing: () => void;
  handleAddCheckpoint: (e: React.FormEvent) => void;
  addCheckItem: () => void;
  removeCheckItem: (id: string) => void;
  updateCheckItem: (id: string, updates: Partial<CheckItem>) => void;
}

type SiteRecord = {
  id: string;
  siteName: string;
  status?: string;
  type?: string | null;
  siteType?: string | null;
  vendorId?: string | null;
  vendor?: { id: string; name: string; status?: string | null; riskLevel?: string | null } | null;
  guardPosts?: Array<{ id: string; postName: string; status?: string | null; requiredGuardCount?: number | null }>;
  contracts?: Array<{ id: string; contractName?: string | null; contractCode?: string | null; vendorId?: string | null; status?: string | null }>;
};

type ContractRecord = {
  id: string;
  contractName?: string;
  contractCode?: string;
  vendorId?: string | null;
  siteId?: string;
  status: string;
};

type AssignmentRecord = {
  id: string;
  status: string;
  route?: { id?: string; name?: string; siteId?: string | null; contractId?: string | null; vendorId?: string | null };
  staff?: { fullName?: string; username?: string };
};

type ExceptionRecord = {
  id: string;
  status: string;
  complianceScore?: number;
  route?: { id?: string; name?: string; siteId?: string | null; contractId?: string | null; vendorId?: string | null };
  staff?: { fullName?: string; username?: string };
};

type ExtendedCheckpoint = Checkpoint & { siteId?: string | null; guardPostId?: string | null };

const normalizeFilterValue = (value?: string) => {
  if (!value) return undefined;
  if (value === 'all' || value.startsWith('all-')) return undefined;
  return value;
};

const normalizeText = (value?: string | null) =>
  (value ?? '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .trim();

const slugify = (value?: string | null) =>
  normalizeText(value)
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');

const matchesFilterToken = (token: string | undefined, candidates: Array<string | null | undefined>) => {
  if (!token) return true;
  const normalizedToken = normalizeText(token);
  const slugToken = slugify(token);
  return candidates.some((candidate) => {
    const normalizedCandidate = normalizeText(candidate);
    return normalizedCandidate === normalizedToken || slugify(candidate) === slugToken;
  });
};

export const SitesTab: React.FC<SitesTabProps> = React.memo(({
  contextualFilters = {},
  checkpoints,
  routes,
  editingCheckpoint,
  newCheckpoint,
  isSubmitting,
  siteSubTab,
  setSiteSubTab,
  setCheckpoints,
  setNewCheckpoint,
  setShowConfirmModal,
  setShowQRModal,
  setMessage,
  setActiveTab: _setActiveTab,
  startEditingCheckpoint,
  cancelEditing,
  handleAddCheckpoint,
  addCheckItem,
  removeCheckItem,
  updateCheckItem,
  hasMoreCheckpoints,
  loadMoreCheckpoints,
  loadingMoreCheckpoints,
}) => {
  const [selectedRouteId, setSelectedRouteId] = React.useState<string | null>(null);
  const [sites, setSites] = React.useState<SiteRecord[]>([]);
  const [contracts, setContracts] = React.useState<ContractRecord[]>([]);
  const [assignments, setAssignments] = React.useState<AssignmentRecord[]>([]);
  const [exceptions, setExceptions] = React.useState<ExceptionRecord[]>([]);
  const [opsSummary, setOpsSummary] = React.useState<AttendanceOpsSummary | null>(null);
  const [isLoadingSupportData, setIsLoadingSupportData] = React.useState(true);
  const [supportDataError, setSupportDataError] = React.useState<string | null>(null);
  const [isLoadingOpsData, setIsLoadingOpsData] = React.useState(true);
  const [opsDataError, setOpsDataError] = React.useState<string | null>(null);
  const [routeForm, setRouteForm] = React.useState({
    routeName: '',
    siteId: '',
    contractId: '',
    expectedDurationMinutes: 30,
    requiredCompletionPercent: 95,
    status: 'DRAFT',
    scheduleStartTime: '08:00',
    scheduleEndTime: '18:00',
    repeatIntervalMinutes: 120,
  });
  const [routeCheckpointIds, setRouteCheckpointIds] = React.useState<string[]>([]);
  const [isSavingRoute, setIsSavingRoute] = React.useState(false);
  const routeFormRef = React.useRef<HTMLFormElement | null>(null);

  const checkpointRecords = checkpoints as ExtendedCheckpoint[];
  const normalizedVendorFilter = normalizeFilterValue(contextualFilters.vendor);
  const normalizedContractFilter = normalizeFilterValue(contextualFilters.contractId);
  const normalizedSiteStatusFilter = normalizeFilterValue(contextualFilters.siteStatus);
  const normalizedSiteTypeFilter = normalizeFilterValue(contextualFilters.siteType);
  const normalizedPostCountFilter = normalizeFilterValue(contextualFilters.postCount);
  const normalizedRiskLevelFilter = normalizeFilterValue(contextualFilters.riskLevel);
  const normalizedGpsFilter = normalizeFilterValue(contextualFilters.gpsStatus);

  const loadSupportData = React.useCallback(async () => {
    setIsLoadingSupportData(true);
    setSupportDataError(null);
    try {
      const [sitePayload, contractPayload, assignmentPayload, exceptionPayload] = await Promise.all([
        fetch('/api/admin/sites?limit=100', { headers: getAuthHeaders() }).then((r) => (r.ok ? r.json() : { data: [] })),
        fetch('/api/admin/contracts?limit=100', { headers: getAuthHeaders() }).then((r) => (r.ok ? r.json() : { data: [] })),
        fetch('/api/tenant/patrol-assignments', { headers: getAuthHeaders() }).then((r) => (r.ok ? r.json() : [])),
        fetch('/api/tenant/patrol-exceptions', { headers: getAuthHeaders() }).then((r) => (r.ok ? r.json() : [])),
      ]);

      setSites(Array.isArray(sitePayload) ? sitePayload : sitePayload?.data || []);
      setContracts(Array.isArray(contractPayload) ? contractPayload : contractPayload?.data || []);
      setAssignments(Array.isArray(assignmentPayload) ? assignmentPayload : assignmentPayload?.data || []);
      setExceptions(Array.isArray(exceptionPayload) ? exceptionPayload : exceptionPayload?.data || []);
    } catch {
      setSites([]);
      setContracts([]);
      setAssignments([]);
      setExceptions([]);
      setSupportDataError('Không tải được dữ liệu mục tiêu, tuyến tuần tra hoặc hợp đồng.');
    } finally {
      setIsLoadingSupportData(false);
    }
  }, []);

  React.useEffect(() => {
    void loadSupportData();
  }, [loadSupportData]);

  const resolvedVendorId = React.useMemo(() => {
    if (!normalizedVendorFilter) return undefined;
    const matchedSite = sites.find((site) => matchesFilterToken(normalizedVendorFilter, [site.vendorId, site.vendor?.id, site.vendor?.name]));
    if (matchedSite?.vendor?.id) return matchedSite.vendor.id;
    const matchedContract = contracts.find((contract) => matchesFilterToken(normalizedVendorFilter, [contract.vendorId]));
    return matchedContract?.vendorId ?? undefined;
  }, [contracts, normalizedVendorFilter, sites]);

  const resolvedContractId = React.useMemo(() => {
    if (!normalizedContractFilter) return undefined;
    const matchedContract = contracts.find((contract) =>
      matchesFilterToken(normalizedContractFilter, [contract.id, contract.contractCode, contract.contractName]),
    );
    return matchedContract?.id ?? undefined;
  }, [contracts, normalizedContractFilter]);

  const loadOpsSummary = React.useCallback(async () => {
    setIsLoadingOpsData(true);
    setOpsDataError(null);
    try {
      const params = new URLSearchParams({ shift: 'current-shift' });
      if (resolvedVendorId) params.set('vendor', resolvedVendorId);
      if (resolvedContractId) params.set('contractId', resolvedContractId);

      const response = await fetch(`/api/tenant/attendance/ops-summary?${params.toString()}`, { headers: getAuthHeaders() });
      if (!response.ok) {
        const payload = await response.json().catch(() => ({}));
        throw new Error(payload?.error || 'OPS_SUMMARY_FETCH_FAILED');
      }

      setOpsSummary((await response.json()) ?? null);
    } catch (error: any) {
      setOpsSummary(null);
      setOpsDataError(error?.message || 'Không tải được dữ liệu vận hành theo site.');
    } finally {
      setIsLoadingOpsData(false);
    }
  }, [resolvedContractId, resolvedVendorId]);

  React.useEffect(() => {
    void loadOpsSummary();
  }, [loadOpsSummary]);

  const getRouteCheckpointId = (item: PatrolRoute['checkpoints'][number]) => (typeof item === 'string' ? item : item.id);

  const getRouteScheduleLabel = (route: PatrolRoute) => {
    const schedule = route.complianceConfig?.schedule as any;
    if (schedule?.startTime && schedule?.endTime) {
      const repeat = schedule.repeatIntervalMinutes || route.repeatIntervalMinutes;
      return `${schedule.startTime}-${schedule.endTime}${repeat ? ` · lặp ${repeat}p` : ''}`;
    }
    if (route.repeatIntervalMinutes) return `Lặp mỗi ${route.repeatIntervalMinutes} phút`;
    return route.schedule || 'Chưa cấu hình lịch';
  };

  const createRoute = async (event: React.FormEvent) => {
    event.preventDefault();
    setIsSavingRoute(true);
    try {
      const selectedContract = contracts.find((contract) => contract.id === routeForm.contractId);
      const response = await fetch('/api/tenant/routes', {
        method: 'POST',
        headers: { ...getAuthHeaders(), 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...routeForm,
          complianceConfig: {
            schedule: {
              type: 'DAILY_TIME_WINDOW',
              startTime: routeForm.scheduleStartTime,
              endTime: routeForm.scheduleEndTime,
              repeatIntervalMinutes: routeForm.repeatIntervalMinutes,
            },
            requirements: { requireGps: true, requirePhotoFirstCheckpoint: true },
            sla: { requiredCompletionPercent: routeForm.requiredCompletionPercent },
          },
          vendorId: selectedContract?.vendorId,
          checkpoints: routeCheckpointIds.map((checkpointId, index) => ({
            checkpointId,
            sequenceNo: index + 1,
            required: true,
            gpsRequired: true,
            photoRequired: index === 0,
            noteRequired: false,
            geoRadiusMeters: 50,
          })),
        }),
      });

      if (!response.ok) throw new Error((await response.json())?.error || 'CREATE_ROUTE_FAILED');
      setMessage({ text: 'Đã tạo tuyến tuần tra.', type: 'success' });
      setRouteForm({
        routeName: '',
        siteId: '',
        contractId: '',
        expectedDurationMinutes: 30,
        requiredCompletionPercent: 95,
        status: 'DRAFT',
        scheduleStartTime: '08:00',
        scheduleEndTime: '18:00',
        repeatIntervalMinutes: 120,
      });
      setRouteCheckpointIds([]);
    } catch (error: any) {
      setMessage({ text: error?.message || 'Không thể tạo tuyến tuần tra.', type: 'error' });
    } finally {
      setIsSavingRoute(false);
    }
  };

  const filteredSites = React.useMemo(() => {
    return sites.filter((site) => {
      if (normalizedSiteStatusFilter && normalizeText(site.status) !== normalizeText(normalizedSiteStatusFilter)) return false;
      if (normalizedSiteTypeFilter && !matchesFilterToken(normalizedSiteTypeFilter, [site.type, site.siteType])) return false;
      if (!matchesFilterToken(normalizedVendorFilter, [site.vendorId, site.vendor?.id, site.vendor?.name])) return false;
      if (normalizedContractFilter) {
        const hasContract = (site.contracts ?? []).some((contract) =>
          matchesFilterToken(normalizedContractFilter, [contract.id, contract.contractCode, contract.contractName]),
        );
        if (!hasContract) return false;
      }
      if (normalizedRiskLevelFilter && normalizeText(site.vendor?.riskLevel) !== normalizeText(normalizedRiskLevelFilter)) return false;

      const guardPostCount = site.guardPosts?.length ?? 0;
      if (normalizedPostCountFilter === 'missing-posts' && guardPostCount > 0) return false;
      if (normalizedPostCountFilter === 'many-posts' && guardPostCount < 3) return false;

      const siteCheckpoints = checkpointRecords.filter((checkpoint) => checkpoint.siteId === site.id);
      if (normalizedGpsFilter === 'missing-gps' && siteCheckpoints.length > 0 && !siteCheckpoints.some((checkpoint) => !checkpoint.latitude || !checkpoint.longitude)) return false;
      if (normalizedGpsFilter === 'has-gps' && siteCheckpoints.some((checkpoint) => !checkpoint.latitude || !checkpoint.longitude)) return false;

      return true;
    });
  }, [
    checkpointRecords,
    normalizedContractFilter,
    normalizedGpsFilter,
    normalizedPostCountFilter,
    normalizedRiskLevelFilter,
    normalizedSiteStatusFilter,
    normalizedSiteTypeFilter,
    normalizedVendorFilter,
    sites,
  ]);

  const filteredSiteIds = React.useMemo(() => new Set(filteredSites.map((site) => site.id)), [filteredSites]);

  const filteredCheckpoints = React.useMemo(
    () => checkpointRecords.filter((checkpoint) => !checkpoint.siteId || filteredSiteIds.has(checkpoint.siteId)),
    [checkpointRecords, filteredSiteIds],
  );

  const filteredRoutes = React.useMemo(
    () => routes.filter((route) => !route.siteId || filteredSiteIds.has(route.siteId)),
    [filteredSiteIds, routes],
  );

  const filteredAssignments = React.useMemo(
    () => assignments.filter((assignment) => !assignment.route?.siteId || filteredSiteIds.has(assignment.route.siteId)),
    [assignments, filteredSiteIds],
  );

  const filteredExceptions = React.useMemo(
    () => exceptions.filter((exception) => !exception.route?.siteId || filteredSiteIds.has(exception.route.siteId)),
    [exceptions, filteredSiteIds],
  );

  const filteredUrgentItems = React.useMemo(
    () => (opsSummary?.urgentItems ?? []).filter((item) => !item.siteId || filteredSiteIds.has(item.siteId)),
    [filteredSiteIds, opsSummary],
  );

  const urgentCountsBySite = React.useMemo(() => {
    const map = new Map<string, number>();
    for (const item of filteredUrgentItems) {
      if (!item.siteId) continue;
      map.set(item.siteId, (map.get(item.siteId) ?? 0) + 1);
    }
    return map;
  }, [filteredUrgentItems]);

  const exceptionCountsBySite = React.useMemo(() => {
    const map = new Map<string, number>();
    for (const exception of filteredExceptions) {
      const siteId = exception.route?.siteId;
      if (!siteId) continue;
      map.set(siteId, (map.get(siteId) ?? 0) + 1);
    }
    return map;
  }, [filteredExceptions]);

  const routeCountsBySite = React.useMemo(() => {
    const map = new Map<string, { total: number; active: number }>();
    for (const route of filteredRoutes) {
      if (!route.siteId) continue;
      const current = map.get(route.siteId) ?? { total: 0, active: 0 };
      current.total += 1;
      if ((route.status ?? 'ACTIVE') === 'ACTIVE') current.active += 1;
      map.set(route.siteId, current);
    }
    return map;
  }, [filteredRoutes]);

  const checkpointsBySite = React.useMemo(() => {
    const map = new Map<string, { total: number; missingGps: number }>();
    for (const checkpoint of filteredCheckpoints) {
      if (!checkpoint.siteId) continue;
      const current = map.get(checkpoint.siteId) ?? { total: 0, missingGps: 0 };
      current.total += 1;
      if (!checkpoint.latitude || !checkpoint.longitude) current.missingGps += 1;
      map.set(checkpoint.siteId, current);
    }
    return map;
  }, [filteredCheckpoints]);

  const siteHealthRows = React.useMemo(() => {
    return filteredSites.map((site) => {
      const guardPostCount = site.guardPosts?.length ?? 0;
      const activeGuardPostCount = (site.guardPosts ?? []).filter((guardPost) => guardPost.status === 'ACTIVE').length;
      const activeContractCount = site.contracts?.length ?? 0;
      const routeStats = routeCountsBySite.get(site.id) ?? { total: 0, active: 0 };
      const checkpointStats = checkpointsBySite.get(site.id) ?? { total: 0, missingGps: 0 };
      const urgentCount = urgentCountsBySite.get(site.id) ?? 0;
      const exceptionCount = exceptionCountsBySite.get(site.id) ?? 0;
      const topUrgentItem = filteredUrgentItems.find((item) => item.siteId === site.id) ?? null;
      const riskReasons = [
        activeContractCount === 0 ? 'Thiếu hợp đồng active' : null,
        guardPostCount === 0 ? 'Chưa có chốt' : null,
        routeStats.active === 0 ? 'Không có tuyến active' : null,
        checkpointStats.missingGps > 0 ? 'Có checkpoint thiếu GPS' : null,
        urgentCount > 0 ? `${urgentCount} việc cần xử lý` : null,
        exceptionCount > 0 ? `${exceptionCount} ngoại lệ tuần tra` : null,
      ].filter(Boolean) as string[];

      return {
        site,
        activeContractCount,
        guardPostCount,
        activeGuardPostCount,
        checkpointCount: checkpointStats.total,
        activeRouteCount: routeStats.active,
        totalRouteCount: routeStats.total,
        urgentCount,
        exceptionCount,
        nextAction:
          topUrgentItem?.nextAction ??
          (activeContractCount === 0
            ? 'Gắn hợp đồng active'
            : routeStats.active === 0
              ? 'Tạo tuyến active'
              : guardPostCount === 0
                ? 'Tạo chốt bảo vệ'
                : 'Kiểm tra chi tiết site'),
        riskReasons,
      };
    });
  }, [checkpointsBySite, exceptionCountsBySite, filteredSites, filteredUrgentItems, routeCountsBySite, urgentCountsBySite]);

  const operationalMetrics = React.useMemo(() => {
    return [
      {
        label: 'Site có rủi ro',
        value: siteHealthRows.filter((row) => row.riskReasons.length > 0).length,
        tone: siteHealthRows.some((row) => row.riskReasons.length > 0) ? 'danger' as const : 'success' as const,
        description: 'Thiếu hợp đồng, thiếu chốt, thiếu tuyến hoặc có cảnh báo vận hành',
      },
      {
        label: 'Ca thiếu người',
        value: opsSummary?.totals.understaffedShifts ?? 0,
        tone: (opsSummary?.totals.understaffedShifts ?? 0) > 0 ? 'danger' as const : 'success' as const,
        description: 'Ca trực chưa đủ quân số theo hợp đồng đang active',
      },
      {
        label: 'Sai GPS',
        value: opsSummary?.totals.invalidGps ?? 0,
        tone: (opsSummary?.totals.invalidGps ?? 0) > 0 ? 'warning' as const : 'success' as const,
        description: 'Attendance có bằng chứng GPS rủi ro trong ca hiện tại',
      },
      {
        label: 'Tuyến trễ / ngoại lệ',
        value: filteredExceptions.length,
        tone: filteredExceptions.length > 0 ? 'warning' as const : 'success' as const,
        description: 'Ngoại lệ tuần tra đang cần supervisor hoặc vendor review',
      },
      {
        label: 'Chưa check-out',
        value: opsSummary?.totals.missingCheckOut ?? 0,
        tone: (opsSummary?.totals.missingCheckOut ?? 0) > 0 ? 'warning' as const : 'success' as const,
        description: 'Guard đã vào ca nhưng chưa có dấu mốc kết thúc ca',
      },
    ];
  }, [filteredExceptions.length, opsSummary, siteHealthRows]);

  const mapPoints: MapPoint[] = React.useMemo(() => {
    if (selectedRouteId) {
      const route = filteredRoutes.find((item) => item.id === selectedRouteId);
      if (route) {
        return route.checkpoints
          .map((item) => checkpointRecords.find((checkpoint) => checkpoint.id === getRouteCheckpointId(item)))
          .filter((checkpoint): checkpoint is ExtendedCheckpoint => Boolean(checkpoint))
          .map((checkpoint) => ({
            id: checkpoint.id,
            name: checkpoint.name,
            lat: checkpoint.latitude,
            lon: checkpoint.longitude,
            status: (checkpoint.status === 'active' ? 'ACTIVE' : 'INACTIVE') as any,
            type: 'CHECKPOINT',
          }));
      }
    }

    return filteredCheckpoints.map((checkpoint) => ({
      id: checkpoint.id,
      name: checkpoint.name,
      lat: checkpoint.latitude,
      lon: checkpoint.longitude,
      status: (checkpoint.status === 'active' ? 'ACTIVE' : 'INACTIVE') as any,
      type: 'CHECKPOINT',
    }));
  }, [checkpointRecords, filteredCheckpoints, filteredRoutes, selectedRouteId]);

  return (
    <motion.div key="sites" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-5">
      <div id="checkpoint-form" className="flex w-full flex-wrap gap-2 rounded-[12px] border border-white/8 bg-white/[0.025] p-1 sm:w-fit">
        <button onClick={() => setSiteSubTab('manage')} className={cn('flex items-center gap-2', dashboardTabButtonClass(siteSubTab === 'manage'))}>
          <MapPin size={13} /> Site vận hành
        </button>
        <button
          onClick={() => {
            setSiteSubTab('map');
            setSelectedRouteId(null);
          }}
          className={cn('flex items-center gap-2', dashboardTabButtonClass(siteSubTab === 'map'))}
        >
          <Navigation size={13} /> Bản đồ điểm kiểm soát
        </button>
        <button onClick={() => setSiteSubTab('benchmark')} className={cn('flex items-center gap-2', dashboardTabButtonClass(siteSubTab === 'benchmark'))}>
          <Target size={13} /> Chuẩn thời gian
          {checkpointRecords.filter((checkpoint) => !checkpoint.benchmark_work_duration).length > 0 ? (
            <span className="ml-1 rounded-md bg-amber-500/20 px-1.5 py-0.5 text-[9px] font-black text-amber-400">
              {checkpointRecords.filter((checkpoint) => !checkpoint.benchmark_work_duration).length} chưa học
            </span>
          ) : null}
        </button>
        <button onClick={() => setSiteSubTab('field')} className={cn('flex items-center gap-2', dashboardTabButtonClass(siteSubTab === 'field'))}>
          <Navigation size={13} /> Cấu hình thực địa
        </button>
      </div>

      {siteSubTab === 'map' ? (
        <div className="space-y-6 animate-in fade-in zoom-in duration-500">
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-4">
            <div className="space-y-4 lg:col-span-1">
              <div className="rounded-[2rem] border border-slate-800 bg-slate-900 p-6 shadow-xl">
                <h4 className="mb-4 text-xs font-black uppercase tracking-widest text-slate-500">Lọc theo lộ trình</h4>
                <div className="space-y-2">
                  <button
                    onClick={() => setSelectedRouteId(null)}
                    className={cn(
                      'w-full rounded-xl border px-4 py-3 text-left text-[11px] font-black uppercase tracking-wider transition-all',
                      !selectedRouteId ? 'border-white/20 bg-white/10 text-white shadow-lg' : 'border-transparent text-slate-500 hover:bg-white/5 hover:text-slate-300',
                    )}
                  >
                    Tất cả điểm kiểm soát
                  </button>
                  {filteredRoutes.map((route) => (
                    <button
                      key={route.id}
                      onClick={() => setSelectedRouteId(route.id)}
                      className={cn(
                        'w-full rounded-xl border px-4 py-3 text-left text-[11px] font-black uppercase tracking-wider transition-all',
                        selectedRouteId === route.id
                          ? 'border-sky-400/50 bg-sky-500 text-white shadow-lg shadow-sky-500/20'
                          : 'border-transparent text-slate-500 hover:bg-white/5 hover:text-slate-300',
                      )}
                    >
                      <div className="flex items-center justify-between">
                        <span>{route.name}</span>
                        <Zap size={12} className={selectedRouteId === route.id ? 'text-white' : 'text-slate-700'} />
                      </div>
                      <div className="mt-1 text-[8px] font-medium normal-case opacity-60">
                        {route.checkpoints.length} điểm · {getRouteScheduleLabel(route)}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              <div className="rounded-[2rem] border border-white/5 bg-scmd-surface p-6">
                <p className="text-[10px] font-medium leading-relaxed text-scmd-silver/40">
                  <strong className="text-scmd-silver/60">Chú ý:</strong> Bản đồ điểm kiểm soát dùng dữ liệu tọa độ hiện có trong hệ thống.
                </p>
              </div>
            </div>

            <div className="relative h-[600px] overflow-hidden rounded-[2.5rem] border border-slate-800 shadow-2xl lg:col-span-3">
              <TacticalMap
                points={mapPoints}
                showRouteLine={Boolean(selectedRouteId)}
                onPointClick={(point) => {
                  const checkpoint = checkpointRecords.find((item) => item.id === point.id);
                  if (checkpoint) startEditingCheckpoint(checkpoint);
                }}
              />
            </div>
          </div>
        </div>
      ) : null}

      {siteSubTab === 'field' ? (
        <div className="animate-in fade-in duration-500">
          <AdminBenchmarkRecorder />
        </div>
      ) : null}

      {siteSubTab === 'benchmark' ? (
        <BenchmarkLearningMode checkpoints={checkpointRecords as any} onCheckpointsUpdate={(updated: any) => setCheckpoints(updated)} />
      ) : null}

      {siteSubTab === 'manage' ? (
        <>
          {supportDataError ? (
            <DashboardErrorState
              title="Không tải được dữ liệu cấu hình mục tiêu"
              description={supportDataError}
              onRetry={loadSupportData}
              className="py-10"
            />
          ) : null}

          <div className="space-y-5 rounded-[24px] border border-white/8 bg-slate-950/85 p-5 shadow-xl">
            <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
              <div>
                <h3 className="text-lg font-black text-white">Site Operations Summary</h3>
                <p className="mt-1 text-sm text-slate-400">
                  Đưa rủi ro theo site, chốt, ca trực và tuần tra lên trước cấu hình.
                </p>
              </div>
              <button
                type="button"
                onClick={() => routeFormRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })}
                className="inline-flex min-h-11 items-center justify-center gap-2 rounded-xl border border-scmd-cyber/20 bg-scmd-cyber/10 px-4 text-[11px] font-black uppercase tracking-widest text-scmd-cyber transition-all hover:bg-scmd-cyber/20"
              >
                <Plus size={14} />
                Tạo tuyến tuần tra
              </button>
            </div>

            {isLoadingOpsData ? (
              <DashboardSpinner message="Đang tải dữ liệu vận hành site..." className="py-12" />
            ) : opsDataError ? (
              <DashboardErrorState
                title="Không tải được dữ liệu vận hành site"
                description={opsDataError}
                onRetry={loadOpsSummary}
                className="py-10"
              />
            ) : (
              <>
                <DashboardMetricGrid>
                  {operationalMetrics.map((metric) => (
                    <DashboardMetricCard key={metric.label} label={metric.label} value={metric.value} tone={metric.tone} description={metric.description} />
                  ))}
                </DashboardMetricGrid>

                <div className="overflow-hidden rounded-[18px] border border-red-500/20 bg-red-500/5">
                  <div className="flex items-center justify-between border-b border-white/6 px-4 py-3">
                    <div>
                      <p className="text-sm font-black uppercase tracking-[0.12em] text-red-200">Cần xử lý ngay tại mục tiêu</p>
                      <p className="mt-1 text-xs text-slate-400">Ưu tiên đưa người vận hành tới site/chốt đang có rủi ro thật.</p>
                    </div>
                    <span className="rounded-full border border-red-400/20 bg-red-500/10 px-3 py-1 text-[10px] font-black uppercase tracking-widest text-red-200">
                      {filteredUrgentItems.length} cảnh báo
                    </span>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full min-w-[880px] border-collapse text-left">
                      <thead>
                        <tr className="bg-slate-950/60 text-[10px] font-black uppercase tracking-[0.16em] text-slate-500">
                          <th className="px-4 py-3">Mức độ</th>
                          <th className="px-4 py-3">Site</th>
                          <th className="px-4 py-3">Ca / chốt</th>
                          <th className="px-4 py-3">Nhân sự</th>
                          <th className="px-4 py-3">Vấn đề</th>
                          <th className="px-4 py-3">Hành động tiếp theo</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/6">
                        {filteredUrgentItems.slice(0, 6).map((item) => (
                          <tr key={item.id} className="text-sm text-white">
                            <td className="px-4 py-3">
                              <span
                                className={cn(
                                  'inline-flex rounded-full px-2.5 py-1 text-[10px] font-black uppercase tracking-widest',
                                  item.severity === 'CRITICAL' ? 'bg-red-500 text-white' : 'bg-amber-500/15 text-amber-200',
                                )}
                              >
                                {item.severity}
                              </span>
                            </td>
                            <td className="px-4 py-3 font-bold">{item.siteName || 'Chưa gắn site'}</td>
                            <td className="px-4 py-3 text-slate-300">{item.shiftLabel || 'Chưa có ca'}</td>
                            <td className="px-4 py-3 text-slate-300">{item.guardName || 'Chưa rõ nhân sự'}</td>
                            <td className="px-4 py-3 text-slate-200">
                              {item.type === 'UNDERSTAFFED'
                                ? 'Thiếu quân số'
                                : item.type === 'MISSING_CHECKOUT'
                                  ? 'Chưa check-out'
                                  : item.type === 'WRONG_GPS'
                                    ? 'Sai GPS'
                                    : item.type === 'MISSING_CHECKIN'
                                      ? 'Chưa check-in'
                                      : 'Đi muộn'}
                            </td>
                            <td className="px-4 py-3 text-slate-300">{item.nextAction}</td>
                          </tr>
                        ))}
                        {filteredUrgentItems.length === 0 ? (
                          <tr>
                            <td colSpan={6} className="px-4 py-10 text-center text-sm text-slate-400">
                              Không có cảnh báo vận hành theo bộ lọc hiện tại.
                            </td>
                          </tr>
                        ) : null}
                      </tbody>
                    </table>
                  </div>
                </div>
              </>
            )}
          </div>

          <div className="overflow-hidden rounded-[24px] border border-white/8 bg-slate-950/85 shadow-xl">
            <div className="flex flex-col gap-2 border-b border-white/6 px-5 py-4 lg:flex-row lg:items-center lg:justify-between">
              <div>
                <h3 className="text-lg font-black text-white">Site Health</h3>
                <p className="mt-1 text-sm text-slate-400">
                  Trạng thái cấu hình và tín hiệu rủi ro theo site để điều hành trước khi đi vào checkpoint chi tiết.
                </p>
              </div>
              <span className="text-xs font-bold uppercase tracking-widest text-slate-500">{filteredSites.length} site trong phạm vi lọc</span>
            </div>
            {isLoadingSupportData ? (
              <DashboardSpinner message="Đang tổng hợp Site Health..." className="py-12" />
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full min-w-[1080px] border-collapse text-left">
                  <thead>
                    <tr className="bg-slate-950/60 text-[10px] font-black uppercase tracking-[0.16em] text-slate-500">
                      <th className="px-4 py-3">Site</th>
                      <th className="px-4 py-3">Vendor</th>
                      <th className="px-4 py-3">Hợp đồng active</th>
                      <th className="px-4 py-3">Chốt</th>
                      <th className="px-4 py-3">Checkpoint</th>
                      <th className="px-4 py-3">Tuyến active</th>
                      <th className="px-4 py-3">Bất thường</th>
                      <th className="px-4 py-3">Hành động</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/6">
                    {siteHealthRows.map((row) => (
                      <tr key={row.site.id} className="align-top text-sm text-white hover:bg-white/[0.02]">
                        <td className="px-4 py-3">
                          <div className="space-y-1">
                            <p className="font-bold text-white">{row.site.siteName}</p>
                            <p className="text-xs text-slate-400">{row.site.status || 'UNKNOWN'}</p>
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <div className="space-y-1">
                            <p className="font-bold text-white">{row.site.vendor?.name || 'Chưa gắn vendor'}</p>
                            <p className="text-xs text-slate-400">{row.site.vendor?.riskLevel || 'Chưa có risk level'}</p>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-slate-200">{row.activeContractCount > 0 ? row.activeContractCount : 'Thiếu contract'}</td>
                        <td className="px-4 py-3 text-slate-200">
                          {row.guardPostCount} / {row.activeGuardPostCount} active
                        </td>
                        <td className="px-4 py-3 text-slate-200">{row.checkpointCount}</td>
                        <td className="px-4 py-3 text-slate-200">
                          {row.activeRouteCount} / {row.totalRouteCount}
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex flex-wrap gap-2">
                            {row.riskReasons.length > 0 ? (
                              row.riskReasons.slice(0, 3).map((reason) => (
                                <span key={reason} className="inline-flex rounded-full border border-amber-500/20 bg-amber-500/10 px-2.5 py-1 text-[10px] font-black uppercase tracking-widest text-amber-200">
                                  {reason}
                                </span>
                              ))
                            ) : (
                              <span className="inline-flex rounded-full border border-emerald-500/20 bg-emerald-500/10 px-2.5 py-1 text-[10px] font-black uppercase tracking-widest text-emerald-200">
                                Ổn định
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="px-4 py-3 text-slate-300">{row.nextAction}</td>
                      </tr>
                    ))}
                    {siteHealthRows.length === 0 ? (
                      <tr>
                        <td colSpan={8} className="px-4 py-12">
                          <div className="mx-auto max-w-xl rounded-[14px] border border-dashed border-white/10 bg-white/[0.02] p-6 text-center">
                            <p className="text-sm font-bold text-white">Không có site nào khớp bộ lọc hiện tại.</p>
                            <p className="mt-2 text-xs leading-5 text-slate-400">
                              Hãy nới bộ lọc vendor, trạng thái hoặc rủi ro để xem lại toàn cảnh vận hành.
                            </p>
                          </div>
                        </td>
                      </tr>
                    ) : null}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          <div className="rounded-[24px] border border-slate-800 bg-slate-900 p-6 shadow-2xl">
            <div className="mb-6 flex items-center justify-between">
              <h3 className="text-xl font-black text-white">Tuyến tuần tra & checkpoint</h3>
              <button
                type="button"
                onClick={() => routeFormRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })}
                className="rounded-xl border border-scmd-cyber/20 bg-scmd-cyber/10 px-4 py-2 text-[10px] font-black uppercase tracking-widest text-scmd-cyber transition-all hover:bg-scmd-cyber/20"
              >
                Tạo tuyến tuần tra
              </button>
            </div>
            <form ref={routeFormRef} onSubmit={createRoute} className="mb-6 grid grid-cols-1 gap-4 rounded-2xl border border-slate-800 bg-slate-950 p-5 xl:grid-cols-6">
              <div className="xl:col-span-2">
                <label className="mb-2 block text-[10px] font-black uppercase tracking-widest text-slate-500">Tên tuyến</label>
                <input
                  value={routeForm.routeName}
                  onChange={(event) => setRouteForm({ ...routeForm, routeName: event.target.value })}
                  required
                  className="min-h-12 w-full rounded-xl border border-slate-800 bg-[#0D1324] px-4 text-sm font-bold text-white outline-none focus:border-[#2563EB]"
                  placeholder="Tuần tra kho đêm"
                />
              </div>
              <div>
                <label className="mb-2 block text-[10px] font-black uppercase tracking-widest text-slate-500">Site / mục tiêu</label>
                <select
                  value={routeForm.siteId}
                  onChange={(event) => setRouteForm({ ...routeForm, siteId: event.target.value })}
                  required={routeForm.status === 'ACTIVE'}
                  className="min-h-12 w-full rounded-xl border border-slate-800 bg-[#0D1324] px-4 text-sm font-bold text-white outline-none focus:border-[#2563EB]"
                >
                  <option value="">Chọn site</option>
                  {filteredSites.map((site) => (
                    <option key={site.id} value={site.id}>
                      {site.siteName}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="mb-2 block text-[10px] font-black uppercase tracking-widest text-slate-500">Hợp đồng</label>
                <select
                  value={routeForm.contractId}
                  onChange={(event) => setRouteForm({ ...routeForm, contractId: event.target.value })}
                  className="min-h-12 w-full rounded-xl border border-slate-800 bg-[#0D1324] px-4 text-sm font-bold text-white outline-none focus:border-[#2563EB]"
                >
                  <option value="">Gắn sau</option>
                  {contracts
                    .filter((contract) => (!routeForm.siteId || contract.siteId === routeForm.siteId) && (!resolvedVendorId || contract.vendorId === resolvedVendorId))
                    .map((contract) => (
                      <option key={contract.id} value={contract.id}>
                        {contract.contractCode || contract.contractName || contract.id}
                      </option>
                    ))}
                </select>
              </div>
              <div>
                <label className="mb-2 block text-[10px] font-black uppercase tracking-widest text-slate-500">SLA %</label>
                <input
                  type="number"
                  min={1}
                  max={100}
                  value={routeForm.requiredCompletionPercent}
                  onChange={(event) => setRouteForm({ ...routeForm, requiredCompletionPercent: Number(event.target.value) })}
                  className="min-h-12 w-full rounded-xl border border-slate-800 bg-[#0D1324] px-4 text-sm font-bold text-white outline-none focus:border-[#2563EB]"
                />
              </div>
              <div>
                <label className="mb-2 block text-[10px] font-black uppercase tracking-widest text-slate-500">Bắt đầu</label>
                <input
                  type="time"
                  value={routeForm.scheduleStartTime}
                  onChange={(event) => setRouteForm({ ...routeForm, scheduleStartTime: event.target.value })}
                  className="min-h-12 w-full rounded-xl border border-slate-800 bg-[#0D1324] px-4 text-sm font-bold text-white outline-none focus:border-[#2563EB]"
                />
              </div>
              <div>
                <label className="mb-2 block text-[10px] font-black uppercase tracking-widest text-slate-500">Kết thúc</label>
                <input
                  type="time"
                  value={routeForm.scheduleEndTime}
                  onChange={(event) => setRouteForm({ ...routeForm, scheduleEndTime: event.target.value })}
                  className="min-h-12 w-full rounded-xl border border-slate-800 bg-[#0D1324] px-4 text-sm font-bold text-white outline-none focus:border-[#2563EB]"
                />
              </div>
              <div>
                <label className="mb-2 block text-[10px] font-black uppercase tracking-widest text-slate-500">Lặp lại (phút)</label>
                <input
                  type="number"
                  min={15}
                  value={routeForm.repeatIntervalMinutes}
                  onChange={(event) => setRouteForm({ ...routeForm, repeatIntervalMinutes: Number(event.target.value) })}
                  className="min-h-12 w-full rounded-xl border border-slate-800 bg-[#0D1324] px-4 text-sm font-bold text-white outline-none focus:border-[#2563EB]"
                />
              </div>
              <div>
                <label className="mb-2 block text-[10px] font-black uppercase tracking-widest text-slate-500">Trạng thái</label>
                <select
                  value={routeForm.status}
                  onChange={(event) => setRouteForm({ ...routeForm, status: event.target.value })}
                  className="min-h-12 w-full rounded-xl border border-slate-800 bg-[#0D1324] px-4 text-sm font-bold text-white outline-none focus:border-[#2563EB]"
                >
                  <option value="DRAFT">DRAFT</option>
                  <option value="ACTIVE">ACTIVE</option>
                  <option value="INACTIVE">INACTIVE</option>
                </select>
              </div>
              <div className="xl:col-span-5">
                <label className="mb-2 block text-[10px] font-black uppercase tracking-widest text-slate-500">Checkpoint theo thứ tự</label>
                <div className="flex max-h-32 flex-wrap gap-2 overflow-y-auto rounded-xl border border-slate-800 bg-[#0D1324] p-3">
                  {filteredCheckpoints.map((checkpoint) => {
                    const selected = routeCheckpointIds.includes(checkpoint.id);
                    return (
                      <button
                        key={checkpoint.id}
                        type="button"
                        onClick={() =>
                          setRouteCheckpointIds((current) =>
                            selected ? current.filter((id) => id !== checkpoint.id) : [...current, checkpoint.id],
                          )
                        }
                        className={cn(
                          'min-h-10 rounded-lg border px-3 text-[10px] font-black uppercase tracking-normal',
                          selected ? 'border-[#2563EB] bg-[#2563EB] text-white' : 'border-slate-800 bg-white/5 text-slate-400 hover:text-white',
                        )}
                      >
                        {selected ? `${routeCheckpointIds.indexOf(checkpoint.id) + 1}. ` : ''}
                        {checkpoint.name}
                      </button>
                    );
                  })}
                </div>
              </div>
              <div className="flex items-end">
                <button
                  type="submit"
                  disabled={isSavingRoute || routeCheckpointIds.length === 0}
                  className="min-h-12 w-full rounded-xl bg-[#2563EB] px-4 text-[10px] font-black uppercase tracking-widest text-white disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {isSavingRoute ? 'Đang lưu' : 'Tạo tuyến'}
                </button>
              </div>
            </form>

            <div className="mb-6 grid grid-cols-1 gap-4 md:grid-cols-3">
              <div className="rounded-2xl border border-slate-800 bg-slate-950 p-5">
                <p className="text-[10px] font-black uppercase tracking-widest text-slate-500">Tuyến đang/chờ chạy</p>
                <p className="mt-2 text-3xl font-black text-white">
                  {filteredAssignments.filter((assignment) => ['PLANNED', 'ACTIVE'].includes(assignment.status)).length}
                </p>
              </div>
              <div className="rounded-2xl border border-slate-800 bg-slate-950 p-5">
                <p className="text-[10px] font-black uppercase tracking-widest text-slate-500">Tuyến trễ/vi phạm</p>
                <p className="mt-2 text-3xl font-black text-amber-300">{filteredExceptions.length}</p>
              </div>
              <div className="rounded-2xl border border-slate-800 bg-slate-950 p-5">
                <p className="text-[10px] font-black uppercase tracking-widest text-slate-500">Cần supervisor xử lý</p>
                <p className="mt-2 truncate text-sm font-black text-white">
                  {filteredExceptions[0]?.route?.name || filteredAssignments.find((assignment) => assignment.status === 'MISSED')?.route?.name || 'Không có cảnh báo'}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-4">
              {filteredRoutes.map((route) => (
                <div key={route.id} className="group rounded-3xl border border-slate-800 bg-slate-950 p-6 transition-all hover:border-sky-500/50">
                  <div className="mb-4 flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-sky-500/10 text-sky-400 transition-transform group-hover:scale-110">
                      <Zap size={20} />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-white">{route.name}</p>
                      <p className="text-[10px] font-bold uppercase text-slate-500">{getRouteScheduleLabel(route)}</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[8px] font-black uppercase tracking-widest text-slate-500">
                      SLA Goal: {typeof route.requiredCompletionPercent === 'number' ? `${route.requiredCompletionPercent}%` : 'Chưa cấu hình'}
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        setSiteSubTab('map');
                        setSelectedRouteId(route.id);
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      className="text-[10px] font-black uppercase tracking-widest text-sky-400 hover:underline"
                    >
                      Chi tiết
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
            <div className="space-y-6 lg:col-span-1">
              <div className="rounded-[24px] border border-white/5 bg-scmd-surface p-8 shadow-2xl">
                <div className="mb-6 flex items-center justify-between">
                  <h3 className="text-xl font-black text-white">{editingCheckpoint ? 'Sửa checkpoint' : 'Thêm checkpoint mới'}</h3>
                  {editingCheckpoint ? (
                    <button onClick={cancelEditing} className="text-xs font-bold text-red-500 hover:text-red-600">
                      Hủy sửa
                    </button>
                  ) : null}
                </div>

                <form onSubmit={handleAddCheckpoint} className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-widest text-slate-500">Tên checkpoint</label>
                    <input
                      type="text"
                      required
                      value={newCheckpoint.name}
                      onChange={(event) => setNewCheckpoint({ ...newCheckpoint, name: event.target.value })}
                      className="w-full rounded-2xl border border-white/5 bg-scmd-navy px-5 py-3 font-bold text-white outline-none transition-all placeholder:text-slate-500 focus:border-emerald-500 focus:ring-4 focus:ring-emerald-500/10"
                      placeholder="Ví dụ: Cổng số 3"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-widest text-slate-500">Mã QR / Hash định danh</label>
                    <input
                      type="text"
                      value={newCheckpoint.qr_hash}
                      onChange={(event) => setNewCheckpoint({ ...newCheckpoint, qr_hash: event.target.value })}
                      className="w-full rounded-2xl border border-white/5 bg-scmd-navy px-5 py-3 font-mono text-sm font-bold text-white outline-none transition-all placeholder:text-slate-500 focus:border-emerald-500 focus:ring-4 focus:ring-emerald-500/10"
                      placeholder="Để trống để hệ thống tự sinh khi tạo mới"
                    />
                    <p className="text-[11px] font-medium leading-relaxed text-slate-500">
                      {editingCheckpoint
                        ? 'Có thể cập nhật lại mã định danh QR nếu cần đồng bộ tem in mới.'
                        : 'Nếu không nhập, hệ thống sẽ tự sinh mã QR bảo mật khi lưu checkpoint mới.'}
                    </p>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-slate-500">Vĩ độ (Lat)</label>
                      <input
                        type="number"
                        step="any"
                        required
                        value={newCheckpoint.latitude}
                        onChange={(event) => setNewCheckpoint({ ...newCheckpoint, latitude: parseFloat(event.target.value) })}
                        className="w-full rounded-2xl border border-white/5 bg-scmd-navy px-5 py-3 font-mono text-sm font-bold text-white outline-none transition-all focus:border-emerald-500 focus:ring-4 focus:ring-emerald-500/10"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-slate-500">Kinh độ (Lon)</label>
                      <input
                        type="number"
                        step="any"
                        required
                        value={newCheckpoint.longitude}
                        onChange={(event) => setNewCheckpoint({ ...newCheckpoint, longitude: parseFloat(event.target.value) })}
                        className="w-full rounded-2xl border border-white/5 bg-scmd-navy px-5 py-3 font-mono text-sm font-bold text-white outline-none transition-all focus:border-emerald-500 focus:ring-4 focus:ring-emerald-500/10"
                      />
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      if (!navigator.geolocation) return;
                      navigator.geolocation.getCurrentPosition(
                        (position) => {
                          setNewCheckpoint({
                            ...newCheckpoint,
                            latitude: position.coords.latitude,
                            longitude: position.coords.longitude,
                          });
                          setMessage({ text: 'Đã lấy tọa độ hiện tại.', type: 'success' });
                          setTimeout(() => setMessage(null), 3000);
                        },
                        () => {
                          setMessage({ text: 'Lỗi lấy vị trí.', type: 'error' });
                          setTimeout(() => setMessage(null), 3000);
                        },
                      );
                    }}
                    className="flex w-full items-center justify-center gap-2 rounded-xl border border-white/10 bg-white/5 py-2 text-[10px] font-black text-scmd-silver/60 transition-all hover:bg-white/10"
                  >
                    <MapPin size={12} /> Lấy tọa độ hiện tại (GPS)
                  </button>

                  <div className="space-y-4 border-t border-white/5 pt-6">
                    <div className="flex items-center justify-between">
                      <label className="text-[10px] font-black uppercase tracking-widest text-slate-500">
                        Đầu việc checklist ({newCheckpoint.check_items.length})
                      </label>
                      <button type="button" onClick={addCheckItem} className="flex items-center gap-1 text-[10px] font-black uppercase tracking-widest text-emerald-400 hover:text-emerald-300">
                        <Plus size={12} /> Thêm
                      </button>
                    </div>

                    <div className="max-h-48 space-y-3 overflow-y-auto pr-1">
                      {newCheckpoint.check_items.map((item) => (
                        <div key={item.id} className="flex items-center gap-2 rounded-xl border border-white/5 bg-scmd-navy p-3">
                          <select
                            value={item.type}
                            onChange={(event) => updateCheckItem(item.id, { type: event.target.value as CheckItem['type'] })}
                            className="rounded-lg border border-white/10 bg-scmd-surface px-2 py-1 text-[10px] font-black uppercase text-white"
                          >
                            <option value="toggle">Toggle</option>
                            <option value="photo">Photo</option>
                            <option value="text">Text</option>
                          </select>
                          <input
                            type="text"
                            value={item.task}
                            onChange={(event) => updateCheckItem(item.id, { task: event.target.value })}
                            placeholder="Nội dung đầu việc..."
                            className="flex-1 rounded-lg border border-white/10 bg-scmd-surface px-3 py-1.5 text-xs font-bold text-white focus:border-emerald-500 focus:outline-none"
                          />
                          <label className="group/check flex cursor-pointer items-center gap-1">
                            <div
                              className={cn(
                                'flex h-4 w-4 items-center justify-center rounded border-2 transition-all',
                                item.required ? 'border-emerald-500 bg-emerald-500 text-white' : 'border-slate-600',
                              )}
                            >
                              {item.required ? <Check size={10} strokeWidth={4} /> : null}
                            </div>
                            <input type="checkbox" checked={item.required} onChange={(event) => updateCheckItem(item.id, { required: event.target.checked })} className="hidden" />
                          </label>
                          <button type="button" onClick={() => removeCheckItem(item.id)} className="text-slate-600 transition-colors hover:text-red-400">
                            <Trash2 size={14} />
                          </button>
                        </div>
                      ))}
                      {newCheckpoint.check_items.length === 0 ? (
                        <div className="rounded-2xl border-2 border-dashed border-white/5 py-8 text-center">
                          <p className="text-[10px] font-black uppercase tracking-widest text-slate-700">Chưa có đầu việc nào</p>
                        </div>
                      ) : null}
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className={cn(
                      'flex w-full items-center justify-center gap-2 rounded-2xl py-4 font-black text-slate-950 shadow-xl transition-all disabled:cursor-not-allowed disabled:opacity-50',
                      editingCheckpoint ? 'bg-scmd-cyber shadow-scmd-cyber/20' : 'bg-emerald-500 shadow-emerald-500/20',
                    )}
                  >
                    {isSubmitting ? <Loader2 className="animate-spin" /> : editingCheckpoint ? <Check size={20} /> : <Plus size={20} />}
                    {editingCheckpoint ? 'Cập nhật checkpoint' : 'Lưu checkpoint'}
                  </button>
                </form>
              </div>

              <div className="relative overflow-hidden rounded-[24px] bg-slate-900 p-6 text-white shadow-xl">
                <div className="relative z-10 flex items-start gap-4">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-white/10">
                    <Sparkles className="text-emerald-400" size={20} />
                  </div>
                  <p className="text-xs font-medium leading-relaxed text-slate-300">
                    <strong>Mẹo:</strong> Bạn có thể lấy tọa độ từ Google Maps. Hệ thống sẽ tự động sinh mã QR bảo mật cho checkpoint này.
                  </p>
                </div>
              </div>
            </div>

            <div className="lg:col-span-2">
              <div className="overflow-hidden rounded-[24px] border border-white/5 bg-scmd-surface shadow-2xl">
                <div className="flex items-center justify-between border-b border-white/5 bg-scmd-navy/40 p-6">
                  <h3 className="font-black text-white">Danh sách checkpoint</h3>
                  <span className="rounded-full border border-white/5 bg-white/5 px-3 py-1 text-[10px] font-black uppercase tracking-wider text-scmd-silver/60">
                    {filteredCheckpoints.length} điểm
                  </span>
                </div>

                <div className="divide-y divide-white/5">
                  {filteredCheckpoints.map((checkpoint) => (
                    <div key={checkpoint.id} className="group flex items-center justify-between border-l-4 border-transparent p-6 transition-all hover:border-scmd-cyber hover:bg-white/5">
                      <div className="flex items-center gap-5">
                        <div className="flex h-14 w-14 items-center justify-center rounded-2xl border border-white/5 bg-scmd-navy text-scmd-silver/20 transition-all group-hover:bg-emerald-500/10 group-hover:text-emerald-400">
                          <MapPin size={24} />
                        </div>
                        <div>
                          <div className="flex items-center gap-3">
                            <p className="text-lg font-black text-white">{checkpoint.name}</p>
                          </div>
                          <p className="mt-0.5 font-mono text-xs text-scmd-silver/40">
                            {(checkpoint.latitude ?? 0).toFixed(6)}, {(checkpoint.longitude ?? 0).toFixed(6)}
                          </p>
                          <div className="mt-3 flex items-center gap-4">
                            <div className="flex items-center gap-1.5">
                              <div className={cn('h-1.5 w-1.5 rounded-full', checkpoint.siteId ? 'bg-emerald-400' : 'bg-amber-400')} />
                              <span className="text-[10px] font-bold uppercase tracking-widest text-scmd-silver/40">Gắn site: {checkpoint.siteId ? 'Có' : 'Chưa gắn'}</span>
                            </div>
                            <div className="flex items-center gap-1.5">
                              <div className={cn('h-1.5 w-1.5 rounded-full', checkpoint.latitude && checkpoint.longitude ? 'bg-sky-500' : 'bg-amber-400')} />
                              <span className="text-[10px] font-bold uppercase tracking-widest text-scmd-silver/40">
                                GPS: {checkpoint.latitude && checkpoint.longitude ? 'Đã có tọa độ' : 'Thiếu tọa độ'}
                              </span>
                            </div>
                            <div className="flex items-center gap-1.5">
                              <div className="h-1.5 w-1.5 rounded-full bg-violet-400" />
                              <span className="text-[10px] font-bold uppercase tracking-widest text-scmd-silver/40">
                                Checklist: {checkpoint.check_items?.length ?? 0} đầu việc
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <button
                          onClick={() => startEditingCheckpoint(checkpoint)}
                          className="inline-flex items-center gap-2 rounded-xl border border-[#2563EB]/20 bg-[#2563EB]/10 px-4 py-2 text-[10px] font-black uppercase tracking-widest text-[#93C5FD] transition-all hover:bg-[#2563EB]/20 hover:text-white"
                          title="Chỉnh sửa checkpoint"
                        >
                          <Pencil size={14} />
                          Chỉnh sửa
                        </button>
                        <button
                          onClick={() => setShowQRModal(checkpoint)}
                          className="rounded-xl border border-dashed border-white/10 p-2.5 text-scmd-silver/30 transition-all hover:bg-emerald-500/10 hover:text-emerald-400"
                          title="In mã QR"
                        >
                          <QrCode size={18} />
                        </button>
                        <button
                          onClick={() => setShowConfirmModal({ id: checkpoint.id, type: 'checkpoint', name: checkpoint.name })}
                          className="rounded-xl p-2.5 text-scmd-silver/20 transition-all hover:bg-red-500/10 hover:text-red-500"
                          title="Xóa checkpoint"
                        >
                          <Trash2 size={18} />
                        </button>
                      </div>
                    </div>
                  ))}

                  {filteredCheckpoints.length === 0 ? (
                    <div className="p-20 text-center">
                      <div className="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-[32px] border border-white/5 bg-scmd-navy shadow-inner">
                        <Target className="text-scmd-silver/10" size={40} />
                      </div>
                      <p className="text-xs font-bold uppercase tracking-widest text-scmd-silver/40">Chưa có checkpoint nào khớp bộ lọc hiện tại.</p>
                      <p className="mt-3 text-xs text-slate-500">Hãy tạo checkpoint mới hoặc nới bộ lọc GPS/site/vendor để tiếp tục cấu hình.</p>
                    </div>
                  ) : null}

                  {hasMoreCheckpoints ? (
                    <div className="flex justify-center border-t border-white/5 bg-scmd-navy/20 p-6">
                      <button
                        onClick={loadMoreCheckpoints}
                        disabled={loadingMoreCheckpoints}
                        className="flex items-center gap-2 rounded-xl border border-emerald-500/10 bg-emerald-500/10 px-6 py-2.5 text-xs font-black uppercase tracking-widest text-emerald-400 transition-all hover:bg-emerald-500/20 disabled:opacity-50"
                      >
                        {loadingMoreCheckpoints ? <Loader2 size={14} className="animate-spin" /> : null}
                        Tải thêm checkpoint
                      </button>
                    </div>
                  ) : null}
                </div>
              </div>
            </div>
          </div>
        </>
      ) : null}
    </motion.div>
  );
});

export default SitesTab;
