/**
 * StaffTab.tsx — SCMD Pro v2.5 · Quản lý Hồ sơ Nhân sự
 *
 * CHANGELOG (patch này):
 * ─────────────────────────────────────────────────────────────────────────────
 * BUG FIX 1 — Field mismatch name ↔ fullName:
 *   - API backend trả về `fullName`. Client dùng `fullName` để bắt đúng schema.
 *   - Type `Staff` đã được refactor xóa bỏ field `name`.
 *
 * BUG FIX 2 — Role không thay đổi sau update:
 *   - Payload gửi lên đã bao gồm role (luôn có), server UpdateStaffUseCase
 *     gọi staff.updateProfile(fullName, role) → role được persist đúng.
 *   - Danh sách hiển thị lại sau fetchData() → role mới hiện đúng.
 *
 * ENHANCEMENT — Bổ sung trường danh sách nhân viên:
 *   - Bảng thêm cột: Họ tên đầy đủ, Vai trò (badge màu), Trạng thái (badge),
 *     Điện thoại, Ngày tạo. Tổng 6 cột.
 *   - Responsive: ẩn cột phụ ở mobile, giữ cột chính.
 *   - Search lọc theo fullName + staffId + username real-time.
 *   - Empty state rõ ràng.
 *
 * BRAND FIX — Tuân thủ NAVY THEME v1.1.5+ (AGENTS.md §5):
 *   - Background: #0D1324 (scmd-navy) — loại bỏ bg-white/95.
 *   - Primary action: #2563EB (scmd-cyber trong tailwind.config = Primary Blue).
 *   - Accent / link: #4285F4 (Blue 400).
 *   - Text phụ: #CCD6F6 (Light Silver).
 *   - Form input: nền slate-800/800, text white, border slate-700.
 *   - Không dùng italic ở bất kỳ đâu (tuân thủ typography rule).
 *   - Touch target button >= h-12 (48px).
 * ─────────────────────────────────────────────────────────────────────────────
 */

import React, { useState, useMemo, useEffect } from "react";
import { Users, Search, Activity, ChevronRight } from "lucide-react";
import { motion } from "motion/react";
import { useTranslation } from "react-i18next";
import { cn } from "../../../lib/utils";
import type { Staff } from "./types";
import { useDashboardStore } from "../store/useDashboardStore";
import { EmptyState } from "../../superadmin/interfaces/components/EmptyState.js";
import {
  DashboardErrorState,
  DashboardMetricCard,
  DashboardMetricGrid,
  DashboardPageHeader,
  DashboardSectionPanel,
  DashboardToolbarRow,
  dashboardInputClass,
  dashboardSelectClass,
} from "../../common/interfaces/components/DashboardUI";

// ─── Sub-components & Utils ────────────────────────────────────────────────
import { getDisplayName } from "./StaffTab.utils.js";
import { StaffForm } from "./components/StaffForm.js";
import { StaffTable } from "./components/StaffTable.js";
import { StaffCardList } from "./components/StaffCardList.js";
import { StaffDetailModal } from "./components/StaffDetailModal.js";
import { StaffPrintModal } from "./components/StaffPrintModal.js";
// ─── Props ──────────────────────────────────────────────────────────────────
interface StaffTabProps {
  staff: Staff[];
  editingStaff: Staff | null;
  selectedStaffDetail: Staff | null;
  staffModalTab: "info" | "performance" | "history";
  newStaff: {
    fullName: string;
    staffId: string;
    role: string;
    username: string;
    password: string;
    qualifications: string;
    certificates: string;
    rewards: string;
    disciplines: string;
    workHistory: any[];
    email: string;
    assignedVendorId?: string;
    assignedSiteId?: string;
    assignedContractId?: string;
    credentials: {
      idNumber: string;
      licenseNumber: string;
      expiryDate: string;
    };
  };
  isSubmitting: boolean;
  isLoading?: boolean;
  error?: string | null;
  onRetry?: () => void;
  showPrintModal: Staff | null;
  printFields: string[];
  filters?: { search: string; role: string; status: string };
  onFilterChange?: (filters: {
    search: string;
    role: string;
    status: string;
  }) => void;
  setNewStaff: React.Dispatch<React.SetStateAction<any>>;
  setStaffModalTab: (v: "info" | "performance" | "history") => void;
  setSelectedStaffDetail: (v: Staff | null) => void;
  setShowConfirmModal: (
    v: {
      id: string;
      type: "checkpoint" | "staff" | "route";
      name: string;
    } | null,
  ) => void;
  setShowPrintModal: (v: Staff | null) => void;
  setPrintFields: (v: string[]) => void;
  startEditingStaff: (s: Staff) => void;
  cancelEditingStaff: () => void;
  handleAddStaff: (e: React.FormEvent) => void;
  handlePrintStaffProfile: (s: Staff) => void;
  tenantInfo?: any;
}

// ════════════════════════════════════════════════════════════════════════════
export const StaffTab: React.FC<StaffTabProps> = React.memo(
  ({
    staff,
    editingStaff,
    selectedStaffDetail,
    staffModalTab,
    newStaff,
    isSubmitting,
    isLoading,
    error,
    onRetry,
    showPrintModal,
    printFields,
    setNewStaff,
    setStaffModalTab,
    setSelectedStaffDetail,
    setShowConfirmModal,
    setShowPrintModal,
    setPrintFields,
    startEditingStaff,
    cancelEditingStaff,
    handleAddStaff,
    handlePrintStaffProfile,
    filters: externalFilters,
    onFilterChange,
    tenantInfo,
  }) => {
    const { t } = useTranslation();
    const [internalSearch, setInternalSearch] = useState("");
    const [searchInputValue, setSearchInputValue] = useState(
      externalFilters?.search ?? "",
    );
    const [internalRoleFilter, setInternalRoleFilter] = useState("all");
    const [internalStatusFilter, setInternalStatusFilter] = useState("all");

    // Sync searchInputValue if external search changes (rare, but for consistency)
    useEffect(() => {
      if (
        externalFilters?.search !== undefined &&
        externalFilters.search !== searchInputValue
      ) {
        setSearchInputValue(externalFilters.search);
      }
    }, [externalFilters?.search]);

    // Unified filter state (excluding immediate search input)
    const search = externalFilters?.search ?? internalSearch;
    const roleFilter = externalFilters?.role ?? internalRoleFilter;
    const statusFilter = externalFilters?.status ?? internalStatusFilter;

    const [debouncedSearch, setDebouncedSearch] = useState(search);
    const [page, setPage] = useState(1);
    const itemsPerPage = 8;

    // Handle filter changes (Role/Status)
    const handleFilterUpdate = (
      newFilters: Partial<{ search: string; role: string; status: string }>,
    ) => {
      const updated = {
        search: newFilters.search !== undefined ? newFilters.search : search,
        role: newFilters.role !== undefined ? newFilters.role : roleFilter,
        status:
          newFilters.status !== undefined ? newFilters.status : statusFilter,
      };

      if (onFilterChange) {
        onFilterChange(updated);
      } else {
        if (newFilters.search !== undefined) {
          setInternalSearch(newFilters.search);
          setDebouncedSearch(newFilters.search);
        }
        if (newFilters.role !== undefined)
          setInternalRoleFilter(newFilters.role);
        if (newFilters.status !== undefined)
          setInternalStatusFilter(newFilters.status);
      }
    };

    // Debounce search input
    useEffect(() => {
      const timer = setTimeout(() => {
        // Only trigger if value actually changed and differs from current filter
        if (searchInputValue !== search) {
          handleFilterUpdate({ search: searchInputValue });
        }

        if (!onFilterChange) {
          setDebouncedSearch(searchInputValue);
        }
      }, 500);
      return () => clearTimeout(timer);
    }, [searchInputValue, onFilterChange]);

    // Reset page on filter change
    useEffect(() => {
      setPage(1);
    }, [debouncedSearch, roleFilter, statusFilter]);

    // ── Lọc + tìm kiếm danh sách ──────────────────────────────────────────────
    // Nếu dùng onFilterChange (Server-side), filteredStaff có thể chính là staff prop
    const filteredStaff = useMemo(() => {
      if (!Array.isArray(staff)) return [];
      if (onFilterChange) return staff; // Server filter, just return staff list as is

      const q = debouncedSearch.toLowerCase().trim();
      return staff.filter((s) => {
        const name = getDisplayName(s).toLowerCase();
        const staffId = (s.staffId || "").toLowerCase();
        const username = (s.username || "").toLowerCase();
        const phone = (s.phone || "").toString().toLowerCase();
        const email = (s.email || "").toLowerCase();

        const matchQ =
          !q ||
          name.includes(q) ||
          staffId.includes(q) ||
          username.includes(q) ||
          phone.includes(q) ||
          email.includes(q);

        const matchRole =
          roleFilter === "all" ||
          s.role === roleFilter ||
          s.role?.toLowerCase() === roleFilter;
        const matchStatus =
          statusFilter === "all" || (s as any).status === statusFilter;

        return matchQ && matchRole && matchStatus;
      });
    }, [staff, debouncedSearch, roleFilter, statusFilter, !!onFilterChange]);

    const totalPages = Math.ceil(filteredStaff.length / itemsPerPage);
    const pagedStaff = useMemo(() => {
      return filteredStaff.slice(
        (page - 1) * itemsPerPage,
        page * itemsPerPage,
      );
    }, [filteredStaff, page]);

    // Real-time online status from store
    const onlineUserIds = useDashboardStore((state) => state.onlineUserIds);

    // ── Thống kê nhanh ────────────────────────────────────────────────────────
    const stats = useMemo(() => {
      if (!Array.isArray(staff))
        return { total: 0, active: 0, guards: 0, admins: 0 };
      const total = staff.length;
      const onlineRealtimeCount = staff.filter(
        (s) => Array.isArray(onlineUserIds) && onlineUserIds.includes(s.id),
      ).length;
      const guards = staff.filter(
        (s) => s.role === "guard" || s.role === "Guard",
      ).length;
      const admins = staff.filter((s) =>
        [
          "tenant-admin",
          "Admin",
          "supervisor",
          "Supervisor",
          "vendor-commander",
          "vendor-representative",
        ].includes(s.role),
      ).length;
      return { total, active: onlineRealtimeCount, guards, admins };
    }, [staff, onlineUserIds]);

    return (
      <>
        <motion.div
          key="staff"
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35 }}
          className="space-y-6"
        >
          <DashboardPageHeader
            title={t("staff.title")}
            eyebrow="Personnel command"
            description="Quản lý hồ sơ, trạng thái trực tuyến, vai trò và thao tác nghiệp vụ của nhân sự bảo vệ trên cùng một chuẩn hiển thị."
          />

          <DashboardMetricGrid>
            <DashboardMetricCard
              label="Tổng quân số"
              value={stats.total.toString().padStart(2, "0")}
              icon={<Users size={18} />}
            />
            <DashboardMetricCard
              label="Trực tuyến"
              value={stats.active.toString().padStart(2, "0")}
              tone="success"
              icon={<Activity size={18} />}
              description="Theo trạng thái realtime"
            />
            <DashboardMetricCard
              label="Bảo vệ"
              value={stats.guards.toString().padStart(2, "0")}
              tone="primary"
              description="Nhân sự vận hành hiện trường"
            />
            <DashboardMetricCard
              label="Quản lý"
              value={stats.admins.toString().padStart(2, "0")}
              tone="warning"
              description="Admin, giám sát, chỉ huy"
            />
          </DashboardMetricGrid>

          <div className="grid grid-cols-1 items-start gap-6 lg:grid-cols-12">
            <div className="lg:col-span-4">
              <StaffForm
                editingStaff={editingStaff}
                newStaff={newStaff}
                isSubmitting={isSubmitting}
                setNewStaff={setNewStaff}
                cancelEditingStaff={cancelEditingStaff}
                handleAddStaff={handleAddStaff}
                tenantInfo={tenantInfo}
                staffCount={stats.total}
              />
            </div>

            <div className="lg:col-span-8">
              <DashboardSectionPanel
                title="Danh sách nhân sự"
                description={`${filteredStaff.length} hồ sơ phù hợp với bộ lọc hiện tại`}
                contentClassName="p-0"
              >
                <div className="border-b border-white/5 p-4 sm:p-5">
                  <DashboardToolbarRow className="p-3 sm:p-3">
                    <div className="relative w-full lg:max-w-sm">
                      <Search
                        className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-scmd-silver/30"
                        size={16}
                      />
                      <input
                        type="text"
                        value={searchInputValue}
                        onChange={(e) => setSearchInputValue(e.target.value)}
                        placeholder="Tìm theo tên, mã, login, SĐT..."
                        className={cn(dashboardInputClass, "pl-11")}
                      />
                    </div>

                    <div className="grid w-full grid-cols-1 gap-3 sm:grid-cols-2 lg:w-auto lg:min-w-[420px]">
                      <label className="space-y-2">
                        <span className="text-[10px] font-black uppercase tracking-[0.18em] text-scmd-silver/45">
                          Vai trò
                        </span>
                        <select
                          value={roleFilter}
                          onChange={(e) =>
                            handleFilterUpdate({ role: e.target.value })
                          }
                          className={dashboardSelectClass}
                        >
                          <option value="all">Tất cả vai trò</option>
                          <option value="guard">Bảo vệ</option>
                          <option value="supervisor">Giám sát</option>
                          <option value="vendor-commander">
                            Chỉ huy nhà thầu
                          </option>
                          <option value="vendor-representative">
                            Đại diện nhà thầu
                          </option>
                          <option value="tenant-admin">Quản trị</option>
                          <option value="technician">Kỹ thuật</option>
                        </select>
                      </label>

                      <label className="space-y-2">
                        <span className="text-[10px] font-black uppercase tracking-[0.18em] text-scmd-silver/45">
                          Trạng thái
                        </span>
                        <select
                          value={statusFilter}
                          onChange={(e) =>
                            handleFilterUpdate({ status: e.target.value })
                          }
                          className={dashboardSelectClass}
                        >
                          <option value="all">Tất cả trạng thái</option>
                          <option value="active">Hoạt động</option>
                          <option value="inactive">Tạm nghỉ</option>
                          <option value="suspended">Bị đình chỉ</option>
                        </select>
                      </label>
                    </div>
                  </DashboardToolbarRow>
                </div>

                {error && !isLoading ? (
                  <div className="p-5">
                    <DashboardErrorState
                      title="Không thể tải danh sách nhân sự"
                      description={error}
                      onRetry={onRetry}
                      className="py-14"
                    />
                  </div>
                ) : (
                  <>
                    <StaffTable
                      pagedStaff={pagedStaff}
                      onlineUserIds={onlineUserIds}
                      isLoading={isLoading || false}
                      staff={staff}
                      itemsPerPage={itemsPerPage}
                      setSelectedStaffDetail={setSelectedStaffDetail}
                      startEditingStaff={startEditingStaff}
                      setShowPrintModal={setShowPrintModal}
                      setShowConfirmModal={setShowConfirmModal}
                    />

                    <StaffCardList
                      pagedStaff={pagedStaff}
                      onlineUserIds={onlineUserIds}
                      isLoading={isLoading || false}
                      staff={staff}
                      itemsPerPage={itemsPerPage}
                      setSelectedStaffDetail={setSelectedStaffDetail}
                      startEditingStaff={startEditingStaff}
                      setShowConfirmModal={setShowConfirmModal}
                    />

                    {totalPages > 1 && (
                      <div className="flex flex-col gap-3 border-t border-white/5 bg-scmd-navy/25 px-4 py-4 sm:flex-row sm:items-center sm:justify-between sm:px-6">
                        <p className="text-[10px] font-black uppercase tracking-widest text-scmd-silver/45">
                          Hiển thị{" "}
                          <span className="text-scmd-primary">
                            {pagedStaff.length}
                          </span>{" "}
                          /{" "}
                          <span className="text-white">
                            {filteredStaff.length}
                          </span>{" "}
                          nhân sự
                        </p>
                        <div className="flex items-center gap-1 overflow-x-auto">
                          <button
                            type="button"
                            onClick={() => setPage((p) => Math.max(1, p - 1))}
                            disabled={page === 1}
                            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-white/8 bg-scmd-navy text-scmd-silver/50 transition-all hover:text-white disabled:cursor-not-allowed disabled:opacity-30"
                            aria-label="Trang trước"
                          >
                            <ChevronRight className="rotate-180" size={14} />
                          </button>

                          {Array.from(
                            { length: totalPages },
                            (_, i) => i + 1,
                          ).map((p) => {
                            const shouldShow =
                              p === 1 ||
                              p === totalPages ||
                              Math.abs(p - page) <= 1;
                            if (!shouldShow) {
                              if (p === 2 || p === totalPages - 1) {
                                return (
                                  <span
                                    key={p}
                                    className="px-1 text-scmd-silver/20"
                                  >
                                    ...
                                  </span>
                                );
                              }
                              return null;
                            }
                            return (
                              <button
                                key={p}
                                type="button"
                                onClick={() => setPage(p)}
                                className={cn(
                                  "h-10 w-10 shrink-0 rounded-xl text-[10px] font-black transition-all",
                                  page === p
                                    ? "bg-scmd-primary text-white shadow-lg shadow-scmd-primary/20"
                                    : "text-scmd-silver/50 hover:bg-white/5 hover:text-white",
                                )}
                              >
                                {p}
                              </button>
                            );
                          })}

                          <button
                            type="button"
                            onClick={() =>
                              setPage((p) => Math.min(totalPages, p + 1))
                            }
                            disabled={page === totalPages}
                            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-white/8 bg-scmd-navy text-scmd-silver/50 transition-all hover:text-white disabled:cursor-not-allowed disabled:opacity-30"
                            aria-label="Trang sau"
                          >
                            <ChevronRight size={14} />
                          </button>
                        </div>
                      </div>
                    )}

                    {!isLoading && filteredStaff.length === 0 && (
                      <div className="p-5">
                        <EmptyState
                          icon={<Users size={32} />}
                          title={
                            search ||
                            roleFilter !== "all" ||
                            statusFilter !== "all"
                              ? "Không tìm thấy nhân sự phù hợp"
                              : "Hệ thống nhân sự đang trống"
                          }
                          description={
                            search ||
                            roleFilter !== "all" ||
                            statusFilter !== "all"
                              ? "Thử thay đổi bộ lọc hoặc từ khóa để mở rộng phạm vi tìm kiếm."
                              : "Tạo hồ sơ đầu tiên bằng biểu mẫu bên trái để bắt đầu vận hành."
                          }
                          className="bg-scmd-navy/20"
                        />
                      </div>
                    )}
                  </>
                )}
              </DashboardSectionPanel>
            </div>
          </div>
        </motion.div>

        {/* ── Modals ─────────────────────────────────────────────────────── */}
        <StaffDetailModal
          selectedStaffDetail={selectedStaffDetail}
          staffModalTab={staffModalTab}
          setStaffModalTab={setStaffModalTab}
          setSelectedStaffDetail={setSelectedStaffDetail}
          startEditingStaff={startEditingStaff}
        />

        <StaffPrintModal
          showPrintModal={showPrintModal}
          printFields={printFields}
          setShowPrintModal={setShowPrintModal}
          setPrintFields={setPrintFields}
          handlePrintStaffProfile={handlePrintStaffProfile}
        />
      </>
    );
  },
);
