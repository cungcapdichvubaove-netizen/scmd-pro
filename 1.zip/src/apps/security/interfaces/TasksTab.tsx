import React from "react";
import { motion } from "motion/react";
import { ClipboardCheck, ListTodo, ShieldAlert } from "lucide-react";
import { TaskManager } from "../../tasks/TaskManager";
import {
  DashboardMetricCard,
  DashboardMetricGrid,
  DashboardPageHeader,
} from "../../common/interfaces/components/DashboardUI";

interface TasksTabProps {
  embedded?: boolean;
}

export const TasksTab: React.FC<TasksTabProps> = ({ embedded = false }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-5"
    >
      {embedded ? (
        <DashboardMetricGrid className="md:grid-cols-3 xl:grid-cols-3">
          <DashboardMetricCard
            label="Queue xử lý"
            value="Theo nhiệm vụ"
            tone="primary"
            icon={<ListTodo size={18} />}
            description="Nhiệm vụ phát sinh từ sự cố, vi phạm, đối soát và hành động hiện trường"
          />
          <DashboardMetricCard
            label="Trục nghiệp vụ"
            value="Site / ca / vendor"
            tone="success"
            icon={<ClipboardCheck size={18} />}
            description="Nhiệm vụ phải bám đúng ngữ cảnh vận hành thay vì danh sách công việc rời rạc"
          />
          <DashboardMetricCard
            label="Ưu tiên"
            value="Đóng việc rõ ràng"
            tone="warning"
            icon={<ShieldAlert size={18} />}
            description="Ưu tiên queue có hạn xử lý, trạng thái và owner cụ thể"
          />
        </DashboardMetricGrid>
      ) : (
        <DashboardPageHeader
          title="Trung tâm giao việc"
          description="Phân công, theo dõi tiến độ và xử lý nhiệm vụ vận hành an ninh theo site và ca trực."
          eyebrow="Task operations"
        />
      )}
      <TaskManager embedded />
    </motion.div>
  );
};
