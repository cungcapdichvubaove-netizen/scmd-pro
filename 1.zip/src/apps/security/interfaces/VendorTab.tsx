import React from "react";
import { motion } from "motion/react";
import { useShallow } from "zustand/react/shallow";
import { FeatureLock } from "../../common/interfaces/components/FeatureLock";
import { DashboardPageHeader } from "../../common/interfaces/components/DashboardUI";
import { useDashboardStore } from "../store/useDashboardStore";
import { VendorContractManagement } from "./components/VendorContractManagement";

interface VendorTabProps {
  embedded?: boolean;
}

export const VendorTab: React.FC<VendorTabProps> = ({ embedded = false }) => {
  const { isPro, tenantInfo, setShowUpgradeModal } = useDashboardStore(
    useShallow((state) => ({
      isPro: state.isPro,
      tenantInfo: state.tenantInfo,
      setShowUpgradeModal: state.setShowUpgradeModal,
    })),
  );

  const vendorManagementEnabled = tenantInfo?.resolvedFeatures?.vendor_management !== false;
  const contractComplianceEnabled = tenantInfo?.resolvedFeatures?.contract_compliance !== false;
  const isAccessible = isPro && vendorManagementEnabled && contractComplianceEnabled;

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-4 animate-in fade-in duration-300"
    >
      {!embedded ? (
        <DashboardPageHeader
          title="Nhà thầu & SLA"
          description="Quản lý hợp đồng bảo vệ thuê ngoài, SLA và dữ liệu phục vụ nghiệm thu hoặc phạt hợp đồng."
          eyebrow="Contract compliance"
        />
      ) : null}

      {!isAccessible ? (
        <FeatureLock
          title="Quản lý Nhà thầu & SLA"
          description={
            !isPro
              ? undefined
              : "Tenant này đang tắt tính năng quản lý nhà thầu hoặc tuân thủ hợp đồng trong ma trận tính năng."
          }
          onUpgrade={() => setShowUpgradeModal(true)}
        />
      ) : (
        <VendorContractManagement />
      )}
    </motion.div>
  );
};

export default VendorTab;
