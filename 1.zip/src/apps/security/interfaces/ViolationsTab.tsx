import React, { useMemo } from "react";
import { useShallow } from "zustand/react/shallow";
import { FeatureLock } from "../../common/interfaces/components/FeatureLock";
import {
  DashboardMetricCard,
  DashboardMetricGrid,
  DashboardPageHeader,
} from "../../common/interfaces/components/DashboardUI";
import { WatcherInsights } from "./components/WatcherInsights";
import { useDashboardStore } from "../store/useDashboardStore";

interface ViolationsTabProps {
  isPro: boolean;
  embedded?: boolean;
  setShowUpgradeModal: (val: boolean) => void;
  handleExportWatcherReport: () => void;
  handleAnomalyFeedback: (
    alertId: string,
    verdict: any,
    notes?: string,
  ) => void;
}

export const ViolationsTab: React.FC<ViolationsTabProps> = ({
  isPro,
  embedded = false,
  setShowUpgradeModal,
  handleExportWatcherReport,
  handleAnomalyFeedback,
}) => {
  const { activeSOS, anomalies, anomalyStats, nocFeed, trustScore } =
    useDashboardStore(
      useShallow((state) => ({
        activeSOS: state.activeSOS,
        anomalies: state.anomalies,
        anomalyStats: state.anomalyStats,
        nocFeed: state.nocFeed,
        trustScore: state.trustScore,
      })),
    );

  const sortedAnomalies = useMemo(() => {
    const p: Record<string, number> = { CRITICAL: 0, WARNING: 1 };
    return [...(anomalies || [])].sort((a, b) => {
      const diff = (p[a.severity] ?? 2) - (p[b.severity] ?? 2);
      return diff !== 0
        ? diff
        : new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime();
    });
  }, [anomalies]);

  return (
    <div className="space-y-5 animate-in fade-in duration-500">
      {!embedded ? (
        <DashboardPageHeader
          title="Sự cố & Vi phạm"
          eyebrow="Watcher center"
          description="Trung tâm xử lý tập trung mọi bất thường: SOS, gian lận, vi phạm SLA và cảnh báo vận hành."
        />
      ) : null}
      {!isPro ? (
        <FeatureLock
          title="An ninh tập trung & AI"
          onUpgrade={() => setShowUpgradeModal(true)}
        />
      ) : (
        <>
          <DashboardMetricGrid className="md:grid-cols-4 xl:grid-cols-4">
            <DashboardMetricCard
              label="SOS khẩn cấp"
              value={activeSOS ? "1" : "0"}
              tone={activeSOS ? "danger" : "success"}
              description={
                activeSOS
                  ? "Đang có cảnh báo cần xử lý ngay"
                  : "Không có SOS đang mở"
              }
            />
            <DashboardMetricCard
              label="Cảnh báo Watcher"
              value={anomalies.length}
              tone="warning"
              description="Bất thường được AI hoặc Watcher ghi nhận"
            />
            <DashboardMetricCard
              label="NOC warning"
              value={nocFeed.filter((f: any) => f.status === "WARNING").length}
              tone="primary"
              description="Tín hiệu cần rà soát trong NOC feed"
            />
            <DashboardMetricCard
              label="Trạng thái điều hành"
              value={activeSOS || anomalies.length > 0 ? "Cần review" : "Ổn định"}
              tone={activeSOS ? "danger" : anomalies.length > 0 ? "warning" : "success"}
              description="Ưu tiên review vi phạm và cảnh báo trước khi chốt đối soát"
            />
          </DashboardMetricGrid>
          <WatcherInsights
            trustScore={trustScore}
            anomalies={sortedAnomalies}
            anomalyStats={anomalyStats}
            onFeedback={handleAnomalyFeedback}
            onExportReport={handleExportWatcherReport}
          />
        </>
      )}
    </div>
  );
};
