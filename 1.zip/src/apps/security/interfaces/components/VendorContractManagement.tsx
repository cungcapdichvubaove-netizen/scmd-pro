﻿import React, { useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle,
  Clock3,
  FileText,
  Paperclip,
  Plus,
  Route,
  Search,
} from 'lucide-react';
import { cn } from '../../../../lib/utils';
import { useAuthStore } from '../../../common/store/useAuthStore';
import { useDashboardStore } from '../../store/useDashboardStore';
import { getAuthHeaders } from '../../../common/utils/auth';
import { SCMDButton } from '../../../common/interfaces/components/SCMDButton';
import { SCMDCard } from '../../../common/interfaces/components/SCMDCard';
import { ShiftSchedulerView } from './ShiftSchedulerView';

type WorkspaceTab = 'vendors' | 'sites' | 'contracts' | 'scheduler';
type ContractWorkspaceTab =
  | 'overview'
  | 'pricing'
  | 'posts'
  | 'staff-standards'
  | 'penalties'
  | 'checklist'
  | 'files'
  | 'versions';

interface VendorRecord {
  id: string;
  name: string;
  taxCode?: string;
  contactPerson?: string;
  contact_person?: string;
  email?: string;
  phone?: string;
  serviceScope?: string;
  status: 'ACTIVE' | 'SUSPENDED' | 'TERMINATED';
  riskLevel?: 'LOW' | 'MEDIUM' | 'HIGH';
  score?: number;
  _count?: { contracts?: number; sites?: number };
}

interface SiteRecord {
  id: string;
  siteName: string;
  address: string;
  siteType: string;
  status: 'ACTIVE' | 'INACTIVE';
  managerName?: string;
  managerPhone?: string;
  vendorId?: string;
  vendor?: VendorRecord;
  guardPosts?: GuardPostRecord[];
  contracts?: ContractRecord[];
}

interface GuardPostRecord {
  id: string;
  siteId: string;
  postName: string;
  postType: string;
  requiredGuardCount: number;
  gpsLat?: number;
  gpsLng?: number;
  radiusMeters: number;
  status: 'ACTIVE' | 'INACTIVE';
}

interface ContractRecord {
  id: string;
  vendorId: string;
  siteId?: string;
  contractName?: string;
  contractCode?: string;
  siteName: string;
  startDate: string;
  endDate: string;
  value: number;
  currency: string;
  guardCountPerShift: number;
  status: 'DRAFT' | 'ACTIVE' | 'EXPIRED' | 'TERMINATED';
  slaConfig?: Record<string, any>;
  acceptancePolicy?: Record<string, any>;
  evidencePolicy?: Record<string, any>;
  penaltyPolicy?: Record<string, any>;
  contractFileUrl?: string;
  activeVersion?: {
    id: string;
    lineItems?: Array<Record<string, any>>;
    shiftRequirements?: Array<Record<string, any>>;
    staffStandards?: Array<Record<string, any>>;
    penaltyRules?: Array<Record<string, any>>;
  };
  vendor?: VendorRecord;
  site?: SiteRecord;
  createdAt?: string;
  updatedAt?: string;
}

interface PricingRow {
  id: string;
  guardPostId: string;
  shiftLabel: string;
  requiredCount: number;
  unitPrice: number;
  billingCycle: 'SHIFT' | 'MONTH';
  notes: string;
}

interface ShiftRequirementRow {
  id: string;
  guardPostId: string;
  shiftLabel: string;
  startTime: string;
  endTime: string;
  requiredCount: number;
  patrolRequired: boolean;
  notes: string;
  appliesOnMonday?: boolean;
  appliesOnTuesday?: boolean;
  appliesOnWednesday?: boolean;
  appliesOnThursday?: boolean;
  appliesOnFriday?: boolean;
  appliesOnSaturday?: boolean;
  appliesOnSunday?: boolean;
}

interface StaffStandardRow {
  id: string;
  standardCode?: string;
  standardName: string;
  required: boolean;
  appliesTo: string;
  appliesToGuardPostId?: string;
  details: string;
}

interface PenaltyRuleRow {
  id: string;
  violationCode: string;
  violationName: string;
  penaltyAmount: number;
  penaltyUnit: 'CASE' | 'SHIFT' | 'DAY' | 'MONTH';
  graceMinutes: number;
  monthlyCap: number;
}

interface ChecklistRow {
  id: string;
  itemName: string;
  dataType: 'PHOTO' | 'NOTE' | 'QR' | 'GPS' | 'SIGNATURE';
  photoRequired: boolean;
  frequency: string;
  notes: string;
}

interface ContractFileRow {
  id: string;
  fileName: string;
  fileUrl: string;
  fileType: 'CONTRACT_SCAN' | 'APPENDIX' | 'SLA' | 'PENALTY' | 'OTHER';
  notes: string;
}

interface VersionRow {
  id: string;
  versionNo: number;
  status: string;
  effectiveFrom?: string;
  effectiveTo?: string;
  note?: string;
}

const CONTRACT_TABS: Array<{ id: ContractWorkspaceTab; label: string }> = [
  { id: 'overview', label: 'Tá»•ng quan' },
  { id: 'pricing', label: 'ÄÆ¡n giÃ¡ & Sá»‘ quÃ¢n' },
  { id: 'posts', label: 'Chá»‘t / Ca' },
  { id: 'staff-standards', label: 'TiÃªu chuáº©n nhÃ¢n sá»±' },
  { id: 'penalties', label: 'Äiá»u khoáº£n pháº¡t' },
  { id: 'checklist', label: 'Checklist / Ná»™i quy' },
  { id: 'files', label: 'File há»£p Ä‘á»“ng' },
  { id: 'versions', label: 'Lá»‹ch sá»­ version' },
];

const unwrap = async <T,>(res: Response): Promise<T[]> => {
  if (!res.ok) return [];
  const payload = await res.json();
  return Array.isArray(payload) ? payload : payload?.data || [];
};

const apiHeaders = () => ({ ...getAuthHeaders(), 'Content-Type': 'application/json' });

const statusTone = (status: string) => {
  if (status === 'ACTIVE') return 'border-emerald-500/30 bg-emerald-500/10 text-emerald-300';
  if (status === 'DRAFT') return 'border-blue-500/30 bg-blue-500/10 text-blue-300';
  if (status === 'SUSPENDED' || status === 'INACTIVE') return 'border-amber-500/30 bg-amber-500/10 text-amber-300';
  return 'border-red-500/30 bg-red-500/10 text-red-300';
};

const createRowId = () =>
  typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function'
    ? crypto.randomUUID()
    : `row-${Math.random().toString(36).slice(2, 10)}`;

const createPricingRow = (): PricingRow => ({
  id: createRowId(),
  guardPostId: '',
  shiftLabel: 'Ca ngÃ y',
  requiredCount: 1,
  unitPrice: 0,
  billingCycle: 'MONTH',
  notes: '',
});

const createShiftRequirementRow = (): ShiftRequirementRow => ({
  id: createRowId(),
  guardPostId: '',
  shiftLabel: 'Ca ngÃ y',
  startTime: '07:00',
  endTime: '19:00',
  requiredCount: 1,
  patrolRequired: false,
  notes: '',
  appliesOnMonday: true,
  appliesOnTuesday: true,
  appliesOnWednesday: true,
  appliesOnThursday: true,
  appliesOnFriday: true,
  appliesOnSaturday: true,
  appliesOnSunday: true,
});

const createStaffStandardRow = (): StaffStandardRow => ({
  id: createRowId(),
  standardCode: '',
  standardName: 'Äá»“ng phá»¥c Ä‘áº§y Ä‘á»§',
  required: true,
  appliesTo: 'Táº¥t cáº£ chá»‘t/ca',
  appliesToGuardPostId: '',
  details: '',
});

const createPenaltyRuleRow = (): PenaltyRuleRow => ({
  id: createRowId(),
  violationCode: '',
  violationName: '',
  penaltyAmount: 0,
  penaltyUnit: 'CASE',
  graceMinutes: 0,
  monthlyCap: 0,
});

const createChecklistRow = (): ChecklistRow => ({
  id: createRowId(),
  itemName: '',
  dataType: 'PHOTO',
  photoRequired: true,
  frequency: 'Má»—i ca',
  notes: '',
});

const createContractFileRow = (): ContractFileRow => ({
  id: createRowId(),
  fileName: '',
  fileUrl: '',
  fileType: 'CONTRACT_SCAN',
  notes: '',
});

const sanitizeRows = <T extends Record<string, any>>(rows: T[], requiredKey?: keyof T) =>
  rows.filter((row) => {
    if (!requiredKey) return true;
    const value = row[requiredKey];
    if (typeof value === 'string') return value.trim().length > 0;
    return value !== null && value !== undefined;
  });

const getContractLineItems = (contract?: ContractRecord | null): PricingRow[] =>
  (contract?.activeVersion?.lineItems as PricingRow[] | undefined)
  || (contract?.acceptancePolicy?.contractLineItems as PricingRow[] | undefined)
  || [];

const getShiftRequirements = (contract?: ContractRecord | null): ShiftRequirementRow[] => {
  const structuredRows = contract?.activeVersion?.shiftRequirements;
  if (Array.isArray(structuredRows) && structuredRows.length > 0) {
    return structuredRows.map((row) => ({
      id: String(row.id || createRowId()),
      guardPostId: String(row.guardPostId || ''),
      shiftLabel: String(row.shiftName || row.positionName || 'Ca trá»±c'),
      startTime: String(row.startTime || ''),
      endTime: String(row.endTime || ''),
      requiredCount: Number(row.requiredStaffCount || 0),
      patrolRequired: Boolean(row.patrolRequired),
      notes: String(row.metadata?.notes || ''),
      appliesOnMonday: row.appliesOnMonday !== false,
      appliesOnTuesday: row.appliesOnTuesday !== false,
      appliesOnWednesday: row.appliesOnWednesday !== false,
      appliesOnThursday: row.appliesOnThursday !== false,
      appliesOnFriday: row.appliesOnFriday !== false,
      appliesOnSaturday: row.appliesOnSaturday !== false,
      appliesOnSunday: row.appliesOnSunday !== false,
    }));
  }

  return (contract?.acceptancePolicy?.shiftRequirements as ShiftRequirementRow[] | undefined) || [];
};

const getStaffStandards = (contract?: ContractRecord | null): StaffStandardRow[] => {
  const structuredRows = contract?.activeVersion?.staffStandards;
  if (Array.isArray(structuredRows) && structuredRows.length > 0) {
    return structuredRows.map((row) => ({
      id: String(row.id || createRowId()),
      standardCode: String(row.standardCode || ''),
      standardName: String(row.standardName || row.standardCode || 'TiÃªu chuáº©n nhÃ¢n sá»±'),
      required: String(row.blockingLevel || 'WARN').toUpperCase() === 'BLOCK',
      appliesTo: String(row.appliesToGuardPost?.postName || row.appliesToGuardPostId || 'Táº¥t cáº£ chá»‘t/ca'),
      appliesToGuardPostId: row.appliesToGuardPostId ? String(row.appliesToGuardPostId) : undefined,
      details: Array.isArray(row.requiredQualifications) ? row.requiredQualifications.join(', ') : '',
    }));
  }

  return (contract?.acceptancePolicy?.staffStandards as StaffStandardRow[] | undefined) || [];
};

const getPenaltyRules = (contract?: ContractRecord | null): PenaltyRuleRow[] =>
  (contract?.penaltyPolicy?.rules as PenaltyRuleRow[] | undefined) || [];

const getChecklistRequirements = (contract?: ContractRecord | null): ChecklistRow[] =>
  (contract?.evidencePolicy?.checklistRequirements as ChecklistRow[] | undefined) || [];

const getContractFiles = (contract?: ContractRecord | null): ContractFileRow[] => {
  const fileRows = (contract?.evidencePolicy?.contractFiles as ContractFileRow[] | undefined) || [];
  if (fileRows.length > 0) return fileRows;
  if (contract?.contractFileUrl) {
    return [{
      id: createRowId(),
      fileName: contract.contractName || contract.contractCode || 'Há»£p Ä‘á»“ng hiá»‡n táº¡i',
      fileUrl: contract.contractFileUrl,
      fileType: 'CONTRACT_SCAN',
      notes: 'Láº¥y tá»« contractFileUrl hiá»‡n táº¡i.',
    }];
  }
  return [];
};

const getVersionHistory = (contract?: ContractRecord | null): VersionRow[] => {
  const fromPolicy = (contract?.acceptancePolicy?.versionHistory as VersionRow[] | undefined) || [];
  if (fromPolicy.length > 0) return fromPolicy;
  if (!contract) return [];
  return [{
    id: contract.id,
    versionNo: 1,
    status: contract.status,
    effectiveFrom: contract.startDate,
    effectiveTo: contract.endDate,
    note: 'Báº£n hiá»‡n táº¡i Ä‘ang Ä‘Æ°á»£c lÆ°u trá»±c tiáº¿p trÃªn há»£p Ä‘á»“ng. TÃ­nh nÄƒng ContractVersion á»Ÿ há»‡ thá»‘ng sáº½ Ä‘Æ°á»£c bá»• sung á»Ÿ sprint sau.',
  }];
};

export const VendorContractManagement: React.FC = () => {
  const role = useAuthStore((state) => state.role);
  const tenantInfo = useDashboardStore((state) => state.tenantInfo);
  const aiContractScanAvailability = tenantInfo?.featureAvailability?.ai_contract_scan;
  const isVendorActor = role === 'vendor-commander' || role === 'vendor-representative';
  const canManageScheduling = role === 'vendor-commander' || role === 'tenant-admin' || role === 'super-admin';
  const [activeTab, setActiveTab] = useState<WorkspaceTab>(isVendorActor ? 'scheduler' : 'vendors');
  const [contractEditorTab, setContractEditorTab] = useState<ContractWorkspaceTab>('overview');
  const [contractDetailTab, setContractDetailTab] = useState<ContractWorkspaceTab>('overview');
  const [vendors, setVendors] = useState<VendorRecord[]>([]);
  const [sites, setSites] = useState<SiteRecord[]>([]);
  const [guardPosts, setGuardPosts] = useState<GuardPostRecord[]>([]);
  const [contracts, setContracts] = useState<ContractRecord[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSiteId, setSelectedSiteId] = useState<string>('');
  const [selectedContractId, setSelectedContractId] = useState<string>('');
  const [isSaving, setIsSaving] = useState(false);

  const [vendorForm, setVendorForm] = useState({
    name: '',
    taxCode: '',
    contactPerson: '',
    phone: '',
    email: '',
    serviceScope: 'Báº£o vá»‡ má»¥c tiÃªu cá»‘ Ä‘á»‹nh',
    riskLevel: 'LOW',
    status: 'ACTIVE',
  });

  const [siteForm, setSiteForm] = useState({
    siteName: '',
    address: '',
    siteType: 'BUILDING',
    managerName: '',
    managerPhone: '',
    vendorId: '',
  });

  const [guardPostForm, setGuardPostForm] = useState({
    postName: '',
    postType: 'GATE',
    requiredGuardCount: 1,
    gpsLat: '',
    gpsLng: '',
    radiusMeters: 50,
  });

  const [contractForm, setContractForm] = useState({
    contractName: '',
    contractCode: '',
    vendorId: '',
    siteId: '',
    startDate: '',
    endDate: '',
    value: 0,
    guardCountPerShift: 1,
    status: 'DRAFT',
    patrolCompletionTargetPercent: 95,
    incidentResponseMinutes: 15,
    incidentResolutionMinutes: 120,
    lateCheckInGraceMinutes: 5,
    missingGuardPenalty: 500000,
    missedPatrolPenalty: 300000,
    unresolvedIncidentPenalty: 1000000,
    minimumCompliancePercent: 95,
    requiredEvidenceTypes: ['PHOTO', 'NOTE'] as Array<'PHOTO' | 'VIDEO' | 'NOTE' | 'DOCUMENT' | 'SIGNATURE'>,
  });

  const [pricingRows, setPricingRows] = useState<PricingRow[]>([createPricingRow()]);
  const [shiftRequirementRows, setShiftRequirementRows] = useState<ShiftRequirementRow[]>([createShiftRequirementRow()]);
  const [staffStandardRows, setStaffStandardRows] = useState<StaffStandardRow[]>([createStaffStandardRow()]);
  const [penaltyRuleRows, setPenaltyRuleRows] = useState<PenaltyRuleRow[]>([createPenaltyRuleRow()]);
  const [checklistRows, setChecklistRows] = useState<ChecklistRow[]>([createChecklistRow()]);
  const [contractFiles, setContractFiles] = useState<ContractFileRow[]>([createContractFileRow()]);
  const [versionNote, setVersionNote] = useState('Khá»Ÿi táº¡o há»£p Ä‘á»“ng tá»« giao diá»‡n cáº¥u hÃ¬nh nÃ¢ng cao.');

  const loadData = async () => {
    const [vendorData, siteData, guardPostData, contractData] = await Promise.all([
      fetch('/api/admin/vendors?limit=100', { headers: getAuthHeaders() }).then((r) => unwrap<VendorRecord>(r)),
      fetch('/api/admin/sites?limit=100', { headers: getAuthHeaders() }).then((r) => unwrap<SiteRecord>(r)),
      fetch('/api/admin/guard-posts', { headers: getAuthHeaders() }).then((r) => unwrap<GuardPostRecord>(r)),
      fetch('/api/admin/contracts?limit=100', { headers: getAuthHeaders() }).then((r) => unwrap<ContractRecord>(r)),
    ]);

    setVendors(vendorData);
    setSites(siteData);
    setGuardPosts(guardPostData);
    setContracts(contractData);
    if (!selectedSiteId && siteData[0]) setSelectedSiteId(siteData[0].id);
    if (!selectedContractId && contractData[0]) setSelectedContractId(contractData[0].id);
  };

  useEffect(() => {
    void loadData();
  }, []);

  useEffect(() => {
    if (isVendorActor && activeTab !== 'scheduler' && activeTab !== 'contracts') {
      setActiveTab('scheduler');
    }
  }, [activeTab, isVendorActor]);

  const filteredVendors = useMemo(() => {
    const q = searchTerm.toLowerCase();
    return vendors.filter((v) => [v.name, v.taxCode, v.contactPerson, v.contact_person, v.phone, v.email].some((x) => x?.toLowerCase().includes(q)));
  }, [vendors, searchTerm]);

  const filteredSites = useMemo(() => {
    const q = searchTerm.toLowerCase();
    return sites.filter((s) => [s.siteName, s.address, s.vendor?.name].some((x) => x?.toLowerCase().includes(q)));
  }, [sites, searchTerm]);

  const filteredContracts = useMemo(() => {
    const q = searchTerm.toLowerCase();
    return contracts.filter((c) => [c.contractName, c.contractCode, c.siteName, c.vendor?.name].some((x) => x?.toLowerCase().includes(q)));
  }, [contracts, searchTerm]);

  const selectedSite = sites.find((site) => site.id === selectedSiteId);
  const selectedSitePosts = guardPosts.filter((post) => post.siteId === selectedSiteId);
  const selectedContract = filteredContracts.find((contract) => contract.id === selectedContractId) || filteredContracts[0] || null;

  const contractSitePosts = useMemo(() => {
    if (!contractForm.siteId) return [];
    return guardPosts.filter((post) => post.siteId === contractForm.siteId);
  }, [contractForm.siteId, guardPosts]);

  const contractVendorSites = useMemo(() => {
    if (!contractForm.vendorId) return sites;
    return sites.filter((site) => !site.vendorId || site.vendorId === contractForm.vendorId);
  }, [contractForm.vendorId, sites]);

  useEffect(() => {
    if (selectedContract && selectedContract.id !== selectedContractId) {
      setSelectedContractId(selectedContract.id);
    }
  }, [selectedContract, selectedContractId]);

  const saveJson = async (url: string, body: Record<string, any>) => {
    setIsSaving(true);
    try {
      const res = await fetch(url, { method: 'POST', headers: apiHeaders(), body: JSON.stringify(body) });
      if (!res.ok) throw new Error((await res.json())?.error || 'SAVE_FAILED');
      await loadData();
    } finally {
      setIsSaving(false);
    }
  };

  const createVendor = async (event: React.FormEvent) => {
    event.preventDefault();
    await saveJson('/api/admin/vendors', vendorForm);
    setVendorForm({ ...vendorForm, name: '', taxCode: '', contactPerson: '', phone: '', email: '' });
  };

  const createSite = async (event: React.FormEvent) => {
    event.preventDefault();
    await saveJson('/api/admin/sites', { ...siteForm, vendorId: siteForm.vendorId || undefined });
    setSiteForm({ ...siteForm, siteName: '', address: '', managerName: '', managerPhone: '' });
  };

  const createGuardPost = async (event: React.FormEvent) => {
    event.preventDefault();
    await saveJson('/api/admin/guard-posts', {
      ...guardPostForm,
      siteId: selectedSiteId,
      gpsLat: guardPostForm.gpsLat ? Number(guardPostForm.gpsLat) : undefined,
      gpsLng: guardPostForm.gpsLng ? Number(guardPostForm.gpsLng) : undefined,
    });
    setGuardPostForm({ postName: '', postType: 'GATE', requiredGuardCount: 1, gpsLat: '', gpsLng: '', radiusMeters: 50 });
  };

  const createContract = async (event: React.FormEvent) => {
    event.preventDefault();
    const contractLineItems = sanitizeRows(pricingRows, 'guardPostId').map((row) => ({
      guardPostId: row.guardPostId,
      shiftLabel: row.shiftLabel,
      requiredCount: Number(row.requiredCount),
      unitPrice: Number(row.unitPrice),
      billingCycle: row.billingCycle,
      notes: row.notes,
    }));

    const shiftRequirements = sanitizeRows(shiftRequirementRows, 'guardPostId').map((row) => ({
      guardPostId: row.guardPostId,
      shiftLabel: row.shiftLabel,
      startTime: row.startTime,
      endTime: row.endTime,
      requiredCount: Number(row.requiredCount),
      patrolRequired: row.patrolRequired,
      appliesOnMonday: row.appliesOnMonday !== false,
      appliesOnTuesday: row.appliesOnTuesday !== false,
      appliesOnWednesday: row.appliesOnWednesday !== false,
      appliesOnThursday: row.appliesOnThursday !== false,
      appliesOnFriday: row.appliesOnFriday !== false,
      appliesOnSaturday: row.appliesOnSaturday !== false,
      appliesOnSunday: row.appliesOnSunday !== false,
      notes: row.notes,
    }));

    const staffStandards = sanitizeRows(staffStandardRows, 'standardName').map((row, index) => ({
      standardCode: row.standardCode || `STD_${index + 1}`,
      standardName: row.standardName,
      required: row.required,
      appliesTo: row.appliesTo,
      appliesToGuardPostId: row.appliesToGuardPostId || undefined,
      requiredQualifications: row.details
        .split(',')
        .map((item) => item.trim())
        .filter(Boolean),
      details: row.details,
    }));

    const penaltyRules = sanitizeRows(penaltyRuleRows, 'violationName').map((row) => ({
      violationCode: row.violationCode,
      violationName: row.violationName,
      penaltyAmount: Number(row.penaltyAmount),
      penaltyUnit: row.penaltyUnit,
      graceMinutes: Number(row.graceMinutes),
      monthlyCap: Number(row.monthlyCap),
    }));

    const checklistRequirements = sanitizeRows(checklistRows, 'itemName').map((row) => ({
      itemName: row.itemName,
      dataType: row.dataType,
      photoRequired: row.photoRequired,
      frequency: row.frequency,
      notes: row.notes,
    }));

    const normalizedFiles = sanitizeRows(contractFiles, 'fileName').map((row) => ({
      fileName: row.fileName,
      fileUrl: row.fileUrl,
      fileType: row.fileType,
      notes: row.notes,
    }));

    await saveJson('/api/admin/contracts', {
      contractName: contractForm.contractName,
      contractCode: contractForm.contractCode,
      vendorId: contractForm.vendorId,
      siteId: contractForm.siteId,
      startDate: contractForm.startDate,
      endDate: contractForm.endDate,
      value: Number(contractForm.value),
      currency: 'VND',
      guardCountPerShift: Number(contractForm.guardCountPerShift),
      status: contractForm.status,
      contractFileUrl: normalizedFiles[0]?.fileUrl || undefined,
      slaConfig: {
        patrolCompletionTargetPercent: Number(contractForm.patrolCompletionTargetPercent),
        incidentResponseMinutes: Number(contractForm.incidentResponseMinutes),
        incidentResolutionMinutes: Number(contractForm.incidentResolutionMinutes),
        lateCheckInGraceMinutes: Number(contractForm.lateCheckInGraceMinutes),
        requiredEvidenceTypes: contractForm.requiredEvidenceTypes,
      },
      acceptancePolicy: {
        monthlyAcceptance: true,
        minimumCompliancePercent: Number(contractForm.minimumCompliancePercent),
        contractLineItems,
        shiftRequirements,
        staffStandards,
        scoreFormulaVersion: 'V.5.5.0.10',
        versionHistory: [{
          id: createRowId(),
          versionNo: 1,
          status: contractForm.status,
          effectiveFrom: contractForm.startDate,
          effectiveTo: contractForm.endDate,
          note: versionNote,
        }],
      },
      evidencePolicy: {
        requiredEvidenceTypes: contractForm.requiredEvidenceTypes,
        checklistRequirements,
        contractFiles: normalizedFiles,
      },
      penaltyPolicy: {
        missingGuardPenalty: Number(contractForm.missingGuardPenalty),
        missedPatrolPenalty: Number(contractForm.missedPatrolPenalty),
        unresolvedIncidentPenalty: Number(contractForm.unresolvedIncidentPenalty),
        rules: penaltyRules,
      },
    });

    setContractForm({
      ...contractForm,
      contractName: '',
      contractCode: '',
      vendorId: '',
      siteId: '',
      startDate: '',
      endDate: '',
      value: 0,
      status: 'DRAFT',
    });
    setPricingRows([createPricingRow()]);
    setShiftRequirementRows([createShiftRequirementRow()]);
    setStaffStandardRows([createStaffStandardRow()]);
    setPenaltyRuleRows([createPenaltyRuleRow()]);
    setChecklistRows([createChecklistRow()]);
    setContractFiles([createContractFileRow()]);
    setVersionNote('Khá»Ÿi táº¡o há»£p Ä‘á»“ng tá»« giao diá»‡n cáº¥u hÃ¬nh nÃ¢ng cao.');
    setContractEditorTab('overview');
  };

  const renderContractEditorTab = () => {
    switch (contractEditorTab) {
      case 'overview':
        return (
          <div className="space-y-4">
            <Field label="TÃªn há»£p Ä‘á»“ng" value={contractForm.contractName} onChange={(v) => setContractForm({ ...contractForm, contractName: v })} required />
            <Field label="MÃ£ há»£p Ä‘á»“ng" value={contractForm.contractCode} onChange={(v) => setContractForm({ ...contractForm, contractCode: v })} required />
            <Select
              label="NhÃ  tháº§u"
              value={contractForm.vendorId}
              onChange={(v) => setContractForm({ ...contractForm, vendorId: v, siteId: '' })}
              options={['', ...vendors.map((v) => v.id)]}
              labels={{ '': 'Chá»n nhÃ  tháº§u', ...Object.fromEntries(vendors.map((v) => [v.id, v.name])) }}
            />
            <Select
              label="Má»¥c tiÃªu"
              value={contractForm.siteId}
              onChange={(v) => setContractForm({ ...contractForm, siteId: v })}
              options={['', ...contractVendorSites.map((s) => s.id)]}
              labels={{ '': 'Chá»n má»¥c tiÃªu', ...Object.fromEntries(contractVendorSites.map((s) => [s.id, s.siteName])) }}
            />
            <div className="grid grid-cols-2 gap-3">
              <Field label="NgÃ y báº¯t Ä‘áº§u" type="date" value={contractForm.startDate} onChange={(v) => setContractForm({ ...contractForm, startDate: v })} required />
              <Field label="NgÃ y káº¿t thÃºc" type="date" value={contractForm.endDate} onChange={(v) => setContractForm({ ...contractForm, endDate: v })} required />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Field label="GiÃ¡ trá»‹ há»£p Ä‘á»“ng" type="number" value={contractForm.value} onChange={(v) => setContractForm({ ...contractForm, value: Number(v) })} />
              <Field label="Sá»‘ ngÆ°á»i tá»‘i thiá»ƒu / ca" type="number" value={contractForm.guardCountPerShift} onChange={(v) => setContractForm({ ...contractForm, guardCountPerShift: Number(v) })} />
            </div>
            <Select label="Tráº¡ng thÃ¡i" value={contractForm.status} onChange={(v) => setContractForm({ ...contractForm, status: v })} options={['DRAFT', 'ACTIVE', 'EXPIRED', 'TERMINATED']} labels={{ DRAFT: 'NhÃ¡p', ACTIVE: 'Äang hoáº¡t Ä‘á»™ng', EXPIRED: 'Háº¿t háº¡n', TERMINATED: 'ÄÃ£ cháº¥m dá»©t' }} />
            <div className="grid grid-cols-2 gap-3">
              <Field label="Má»¥c tiÃªu tuáº§n tra %" type="number" value={contractForm.patrolCompletionTargetPercent} onChange={(v) => setContractForm({ ...contractForm, patrolCompletionTargetPercent: Number(v) })} />
              <Field label="Má»¥c tiÃªu nghiá»‡m thu %" type="number" value={contractForm.minimumCompliancePercent} onChange={(v) => setContractForm({ ...contractForm, minimumCompliancePercent: Number(v) })} />
            </div>
            <div className="grid grid-cols-3 gap-3">
              <Field label="Pháº£n há»“i sá»± cá»‘ (phÃºt)" type="number" value={contractForm.incidentResponseMinutes} onChange={(v) => setContractForm({ ...contractForm, incidentResponseMinutes: Number(v) })} />
              <Field label="Kháº¯c phá»¥c sá»± cá»‘ (phÃºt)" type="number" value={contractForm.incidentResolutionMinutes} onChange={(v) => setContractForm({ ...contractForm, incidentResolutionMinutes: Number(v) })} />
              <Field label="Thá»i gian gia háº¡n check-in (phÃºt)" type="number" value={contractForm.lateCheckInGraceMinutes} onChange={(v) => setContractForm({ ...contractForm, lateCheckInGraceMinutes: Number(v) })} />
            </div>
          </div>
        );
      case 'pricing':
        return (
          <StructuredTableCard
            title="Báº£ng Ä‘Æ¡n giÃ¡ vÃ  sá»‘ quÃ¢n"
            description="Quáº£n trá»‹ viÃªn nháº­p tá»«ng chá»‘t/ca theo Ä‘Ãºng Ä‘Æ¡n giÃ¡ thá»±c táº¿ thay vÃ¬ gá»™p vÃ o JSON."
            actionLabel="ThÃªm dÃ²ng Ä‘Æ¡n giÃ¡"
            onAdd={() => setPricingRows((rows) => [...rows, createPricingRow()])}
          >
            <div className="overflow-x-auto">
              <table className="min-w-full text-sm">
                <thead>
                  <tr className="border-b border-white/10 text-left text-[10px] font-black uppercase text-[var(--color-text-muted)]">
                    <th className="px-3 py-3">Chá»‘t</th>
                    <th className="px-3 py-3">Ca</th>
                    <th className="px-3 py-3">Sá»‘ ngÆ°á»i</th>
                    <th className="px-3 py-3">ÄÆ¡n giÃ¡</th>
                    <th className="px-3 py-3">Chu ká»³</th>
                    <th className="px-3 py-3">Ghi chÃº</th>
                    <th className="px-3 py-3" />
                  </tr>
                </thead>
                <tbody>
                  {pricingRows.map((row) => (
                    <tr key={row.id} className="border-b border-white/5">
                      <td className="px-3 py-3">
                        <InlineSelect
                          value={row.guardPostId}
                          onChange={(value) => setPricingRows((rows) => rows.map((item) => item.id === row.id ? { ...item, guardPostId: value } : item))}
                          options={['', ...contractSitePosts.map((post) => post.id)]}
                          labels={{ '': 'Chá»n chá»‘t', ...Object.fromEntries(contractSitePosts.map((post) => [post.id, post.postName])) }}
                        />
                      </td>
                      <td className="px-3 py-3"><InlineInput value={row.shiftLabel} onChange={(value) => setPricingRows((rows) => rows.map((item) => item.id === row.id ? { ...item, shiftLabel: value } : item))} /></td>
                      <td className="px-3 py-3"><InlineInput type="number" value={row.requiredCount} onChange={(value) => setPricingRows((rows) => rows.map((item) => item.id === row.id ? { ...item, requiredCount: Number(value) } : item))} /></td>
                      <td className="px-3 py-3"><InlineInput type="number" value={row.unitPrice} onChange={(value) => setPricingRows((rows) => rows.map((item) => item.id === row.id ? { ...item, unitPrice: Number(value) } : item))} /></td>
                      <td className="px-3 py-3">
                        <InlineSelect
                          value={row.billingCycle}
                          onChange={(value) => setPricingRows((rows) => rows.map((item) => item.id === row.id ? { ...item, billingCycle: value as PricingRow['billingCycle'] } : item))}
                          options={['SHIFT', 'MONTH']}
                          labels={{ SHIFT: 'Theo ca', MONTH: 'Theo thÃ¡ng' }}
                        />
                      </td>
                      <td className="px-3 py-3"><InlineInput value={row.notes} onChange={(value) => setPricingRows((rows) => rows.map((item) => item.id === row.id ? { ...item, notes: value } : item))} /></td>
                      <td className="px-3 py-3 text-right">
                        <RowDeleteButton onClick={() => setPricingRows((rows) => rows.length === 1 ? rows : rows.filter((item) => item.id !== row.id))} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </StructuredTableCard>
        );
      case 'posts':
        return (
          <StructuredTableCard
            title="Báº£ng chá»‘t / ca váº­n hÃ nh"
            description="Khai bÃ¡o theo gÃ³c nhÃ¬n Ä‘iá»u Ä‘á»™: chá»‘t nÃ o, ca nÃ o, giá» nÃ o, cáº§n bao nhiÃªu ngÆ°á»i vÃ  cÃ³ yÃªu cáº§u tuáº§n tra hay khÃ´ng."
            actionLabel="ThÃªm cáº¥u hÃ¬nh chá»‘t/ca"
            onAdd={() => setShiftRequirementRows((rows) => [...rows, createShiftRequirementRow()])}
          >
            <div className="overflow-x-auto">
              <table className="min-w-full text-sm">
                <thead>
                  <tr className="border-b border-white/10 text-left text-[10px] font-black uppercase text-[var(--color-text-muted)]">
                    <th className="px-3 py-3">Chá»‘t</th>
                    <th className="px-3 py-3">Ca</th>
                    <th className="px-3 py-3">Báº¯t Ä‘áº§u</th>
                    <th className="px-3 py-3">Káº¿t thÃºc</th>
                    <th className="px-3 py-3">Sá»‘ ngÆ°á»i</th>
                    <th className="px-3 py-3">Tuáº§n tra?</th>
                    <th className="px-3 py-3">T2-T8-CN</th>
                    <th className="px-3 py-3">Ghi chÃº</th>
                    <th className="px-3 py-3" />
                  </tr>
                </thead>
                <tbody>
                  {shiftRequirementRows.map((row) => (
                    <tr key={row.id} className="border-b border-white/5">
                      <td className="px-3 py-3">
                        <InlineSelect
                          value={row.guardPostId}
                          onChange={(value) => setShiftRequirementRows((rows) => rows.map((item) => item.id === row.id ? { ...item, guardPostId: value } : item))}
                          options={['', ...contractSitePosts.map((post) => post.id)]}
                          labels={{ '': 'Chá»n chá»‘t', ...Object.fromEntries(contractSitePosts.map((post) => [post.id, post.postName])) }}
                        />
                      </td>
                      <td className="px-3 py-3"><InlineInput value={row.shiftLabel} onChange={(value) => setShiftRequirementRows((rows) => rows.map((item) => item.id === row.id ? { ...item, shiftLabel: value } : item))} /></td>
                      <td className="px-3 py-3"><InlineInput type="time" value={row.startTime} onChange={(value) => setShiftRequirementRows((rows) => rows.map((item) => item.id === row.id ? { ...item, startTime: value } : item))} /></td>
                      <td className="px-3 py-3"><InlineInput type="time" value={row.endTime} onChange={(value) => setShiftRequirementRows((rows) => rows.map((item) => item.id === row.id ? { ...item, endTime: value } : item))} /></td>
                      <td className="px-3 py-3"><InlineInput type="number" value={row.requiredCount} onChange={(value) => setShiftRequirementRows((rows) => rows.map((item) => item.id === row.id ? { ...item, requiredCount: Number(value) } : item))} /></td>
                      <td className="px-3 py-3"><InlineToggle checked={row.patrolRequired} onChange={(checked) => setShiftRequirementRows((rows) => rows.map((item) => item.id === row.id ? { ...item, patrolRequired: checked } : item))} /></td>
                      <td className="px-3 py-3">
                        <div className="grid grid-cols-4 gap-1 xl:grid-cols-7">
                          {([
                            ['appliesOnMonday', 'T2'],
                            ['appliesOnTuesday', 'T3'],
                            ['appliesOnWednesday', 'T4'],
                            ['appliesOnThursday', 'T5'],
                            ['appliesOnFriday', 'T6'],
                            ['appliesOnSaturday', 'T7'],
                            ['appliesOnSunday', 'CN'],
                          ] as Array<[keyof ShiftRequirementRow, string]>).map(([key, label]) => (
                            <div key={String(key)} className="flex flex-col items-center gap-1 rounded-lg border border-white/10 px-1 py-2 text-[10px] text-[var(--color-text-secondary)]">
                              <span>{label}</span>
                              <InlineToggle
                                checked={Boolean(row[key])}
                                onChange={(checked) => setShiftRequirementRows((rows) => rows.map((item) => item.id === row.id ? { ...item, [key]: checked } : item))}
                              />
                            </div>
                          ))}
                        </div>
                      </td>
                      <td className="px-3 py-3"><InlineInput value={row.notes} onChange={(value) => setShiftRequirementRows((rows) => rows.map((item) => item.id === row.id ? { ...item, notes: value } : item))} /></td>
                      <td className="px-3 py-3 text-right">
                        <RowDeleteButton onClick={() => setShiftRequirementRows((rows) => rows.length === 1 ? rows : rows.filter((item) => item.id !== row.id))} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </StructuredTableCard>
        );
      case 'staff-standards':
        return (
          <StructuredTableCard
            title="Báº£ng tiÃªu chuáº©n nhÃ¢n sá»±"
            description="DÃ¹ng Ä‘á»ƒ khai bÃ¡o Ä‘iá»u kiá»‡n mÃ  báº£o vá»‡ pháº£i Ä‘Ã¡p á»©ng trÆ°á»›c khi Ä‘Æ°á»£c bá»‘ trÃ­ vÃ o ca/chá»‘t."
            actionLabel="ThÃªm tiÃªu chuáº©n"
            onAdd={() => setStaffStandardRows((rows) => [...rows, createStaffStandardRow()])}
          >
            <div className="overflow-x-auto">
              <table className="min-w-full text-sm">
                <thead>
                  <tr className="border-b border-white/10 text-left text-[10px] font-black uppercase text-[var(--color-text-muted)]">
                    <th className="px-3 py-3">MÃ£</th>
                    <th className="px-3 py-3">TiÃªu chuáº©n</th>
                    <th className="px-3 py-3">Báº¯t buá»™c</th>
                    <th className="px-3 py-3">Chá»‘t Ã¡p dá»¥ng</th>
                    <th className="px-3 py-3">NhÃ£n hiá»ƒn thá»‹</th>
                    <th className="px-3 py-3">Diá»…n giáº£i / TiÃªu chuáº©n</th>
                    <th className="px-3 py-3" />
                  </tr>
                </thead>
                <tbody>
                  {staffStandardRows.map((row) => (
                    <tr key={row.id} className="border-b border-white/5">
                      <td className="px-3 py-3"><InlineInput value={row.standardCode || ''} onChange={(value) => setStaffStandardRows((rows) => rows.map((item) => item.id === row.id ? { ...item, standardCode: value } : item))} /></td>
                      <td className="px-3 py-3"><InlineInput value={row.standardName} onChange={(value) => setStaffStandardRows((rows) => rows.map((item) => item.id === row.id ? { ...item, standardName: value } : item))} /></td>
                      <td className="px-3 py-3"><InlineToggle checked={row.required} onChange={(checked) => setStaffStandardRows((rows) => rows.map((item) => item.id === row.id ? { ...item, required: checked } : item))} /></td>
                      <td className="px-3 py-3">
                        <InlineSelect
                          value={row.appliesToGuardPostId || ''}
                          onChange={(value) => setStaffStandardRows((rows) => rows.map((item) => item.id === row.id ? {
                            ...item,
                            appliesToGuardPostId: value,
                            appliesTo: value ? (contractSitePosts.find((post) => post.id === value)?.postName || item.appliesTo) : 'Táº¥t cáº£ chá»‘t/ca',
                          } : item))}
                          options={['', ...contractSitePosts.map((post) => post.id)]}
                          labels={{ '': 'Táº¥t cáº£ chá»‘t/ca', ...Object.fromEntries(contractSitePosts.map((post) => [post.id, post.postName])) }}
                        />
                      </td>
                      <td className="px-3 py-3"><InlineInput value={row.appliesTo} onChange={(value) => setStaffStandardRows((rows) => rows.map((item) => item.id === row.id ? { ...item, appliesTo: value } : item))} /></td>
                      <td className="px-3 py-3"><InlineInput value={row.details} onChange={(value) => setStaffStandardRows((rows) => rows.map((item) => item.id === row.id ? { ...item, details: value } : item))} /></td>
                      <td className="px-3 py-3 text-right">
                        <RowDeleteButton onClick={() => setStaffStandardRows((rows) => rows.length === 1 ? rows : rows.filter((item) => item.id !== row.id))} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </StructuredTableCard>
        );
      case 'penalties':
        return (
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-3">
              <Field label="Pháº¡t thiáº¿u ngÆ°á»i" type="number" value={contractForm.missingGuardPenalty} onChange={(v) => setContractForm({ ...contractForm, missingGuardPenalty: Number(v) })} />
              <Field label="Pháº¡t bá» tuáº§n tra" type="number" value={contractForm.missedPatrolPenalty} onChange={(v) => setContractForm({ ...contractForm, missedPatrolPenalty: Number(v) })} />
              <Field label="Pháº¡t sá»± cá»‘ quÃ¡ SLA" type="number" value={contractForm.unresolvedIncidentPenalty} onChange={(v) => setContractForm({ ...contractForm, unresolvedIncidentPenalty: Number(v) })} />
            </div>
            <StructuredTableCard
              title="Báº£ng Ä‘iá»u khoáº£n pháº¡t"
              description="Quáº£n lÃ½ quy táº¯c pháº¡t theo tá»«ng loáº¡i lá»—i, má»©c pháº¡t, thá»i gian gia háº¡n vÃ  tráº§n theo thÃ¡ng mÃ  khÃ´ng cáº§n nháº­p JSON."
              actionLabel="ThÃªm Ä‘iá»u khoáº£n pháº¡t"
              onAdd={() => setPenaltyRuleRows((rows) => [...rows, createPenaltyRuleRow()])}
            >
              <div className="overflow-x-auto">
                <table className="min-w-full text-sm">
                  <thead>
                    <tr className="border-b border-white/10 text-left text-[10px] font-black uppercase text-[var(--color-text-muted)]">
                      <th className="px-3 py-3">MÃ£ lá»—i</th>
                      <th className="px-3 py-3">Lá»—i</th>
                      <th className="px-3 py-3">Má»©c pháº¡t</th>
                      <th className="px-3 py-3">ÄÆ¡n vá»‹ pháº¡t</th>
                      <th className="px-3 py-3">Gia háº¡n</th>
                      <th className="px-3 py-3">Tráº§n thÃ¡ng</th>
                      <th className="px-3 py-3" />
                    </tr>
                  </thead>
                  <tbody>
                    {penaltyRuleRows.map((row) => (
                      <tr key={row.id} className="border-b border-white/5">
                        <td className="px-3 py-3"><InlineInput value={row.violationCode} onChange={(value) => setPenaltyRuleRows((rows) => rows.map((item) => item.id === row.id ? { ...item, violationCode: value } : item))} /></td>
                        <td className="px-3 py-3"><InlineInput value={row.violationName} onChange={(value) => setPenaltyRuleRows((rows) => rows.map((item) => item.id === row.id ? { ...item, violationName: value } : item))} /></td>
                        <td className="px-3 py-3"><InlineInput type="number" value={row.penaltyAmount} onChange={(value) => setPenaltyRuleRows((rows) => rows.map((item) => item.id === row.id ? { ...item, penaltyAmount: Number(value) } : item))} /></td>
                        <td className="px-3 py-3">
                          <InlineSelect
                            value={row.penaltyUnit}
                            onChange={(value) => setPenaltyRuleRows((rows) => rows.map((item) => item.id === row.id ? { ...item, penaltyUnit: value as PenaltyRuleRow['penaltyUnit'] } : item))}
                            options={['CASE', 'SHIFT', 'DAY', 'MONTH']}
                            labels={{ CASE: 'Theo lá»—i', SHIFT: 'Theo ca', DAY: 'Theo ngÃ y', MONTH: 'Theo thÃ¡ng' }}
                          />
                        </td>
                        <td className="px-3 py-3"><InlineInput type="number" value={row.graceMinutes} onChange={(value) => setPenaltyRuleRows((rows) => rows.map((item) => item.id === row.id ? { ...item, graceMinutes: Number(value) } : item))} /></td>
                        <td className="px-3 py-3"><InlineInput type="number" value={row.monthlyCap} onChange={(value) => setPenaltyRuleRows((rows) => rows.map((item) => item.id === row.id ? { ...item, monthlyCap: Number(value) } : item))} /></td>
                        <td className="px-3 py-3 text-right">
                          <RowDeleteButton onClick={() => setPenaltyRuleRows((rows) => rows.length === 1 ? rows : rows.filter((item) => item.id !== row.id))} />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </StructuredTableCard>
          </div>
        );
      case 'checklist':
        return (
          <StructuredTableCard
            title="Checklist / ná»™i quy váº­n hÃ nh"
            description="Chuáº©n hÃ³a Ä‘áº§u vÃ o thá»±c Ä‘á»‹a: loáº¡i dá»¯ liá»‡u nÃ o pháº£i cÃ³, táº§n suáº¥t vÃ  cÃ³ báº¯t buá»™c áº£nh hay khÃ´ng."
            actionLabel="ThÃªm checklist"
            onAdd={() => setChecklistRows((rows) => [...rows, createChecklistRow()])}
          >
            <div className="overflow-x-auto">
              <table className="min-w-full text-sm">
                <thead>
                  <tr className="border-b border-white/10 text-left text-[10px] font-black uppercase text-[var(--color-text-muted)]">
                    <th className="px-3 py-3">Checklist</th>
                    <th className="px-3 py-3">Loáº¡i dá»¯ liá»‡u</th>
                    <th className="px-3 py-3">Báº¯t buá»™c áº£nh?</th>
                    <th className="px-3 py-3">Táº§n suáº¥t</th>
                    <th className="px-3 py-3">Ghi chÃº</th>
                    <th className="px-3 py-3" />
                  </tr>
                </thead>
                <tbody>
                  {checklistRows.map((row) => (
                    <tr key={row.id} className="border-b border-white/5">
                      <td className="px-3 py-3"><InlineInput value={row.itemName} onChange={(value) => setChecklistRows((rows) => rows.map((item) => item.id === row.id ? { ...item, itemName: value } : item))} /></td>
                      <td className="px-3 py-3">
                        <InlineSelect
                          value={row.dataType}
                          onChange={(value) => setChecklistRows((rows) => rows.map((item) => item.id === row.id ? { ...item, dataType: value as ChecklistRow['dataType'] } : item))}
                          options={['PHOTO', 'NOTE', 'QR', 'GPS', 'SIGNATURE']}
                        />
                      </td>
                      <td className="px-3 py-3"><InlineToggle checked={row.photoRequired} onChange={(checked) => setChecklistRows((rows) => rows.map((item) => item.id === row.id ? { ...item, photoRequired: checked } : item))} /></td>
                      <td className="px-3 py-3"><InlineInput value={row.frequency} onChange={(value) => setChecklistRows((rows) => rows.map((item) => item.id === row.id ? { ...item, frequency: value } : item))} /></td>
                      <td className="px-3 py-3"><InlineInput value={row.notes} onChange={(value) => setChecklistRows((rows) => rows.map((item) => item.id === row.id ? { ...item, notes: value } : item))} /></td>
                      <td className="px-3 py-3 text-right">
                        <RowDeleteButton onClick={() => setChecklistRows((rows) => rows.length === 1 ? rows : rows.filter((item) => item.id !== row.id))} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </StructuredTableCard>
        );
      case 'files':
        return (
          <StructuredTableCard
            title="File há»£p Ä‘á»“ng / phá»¥ lá»¥c"
            description="DÃ¹ng báº£ng Ä‘á»ƒ gáº¯n URL tá»‡p, loáº¡i tÃ i liá»‡u vÃ  ghi chÃº. KhÃ´ng báº¯t quáº£n trá»‹ viÃªn nháº­p Ä‘á»‘i tÆ°á»£ng JSON thÃ´."
            actionLabel="ThÃªm tá»‡p"
            onAdd={() => setContractFiles((rows) => [...rows, createContractFileRow()])}
          >
            <div className="overflow-x-auto">
              <table className="min-w-full text-sm">
                <thead>
                  <tr className="border-b border-white/10 text-left text-[10px] font-black uppercase text-[var(--color-text-muted)]">
                    <th className="px-3 py-3">TÃªn tá»‡p</th>
                    <th className="px-3 py-3">URL</th>
                    <th className="px-3 py-3">Loáº¡i</th>
                    <th className="px-3 py-3">Ghi chÃº</th>
                    <th className="px-3 py-3" />
                  </tr>
                </thead>
                <tbody>
                  {contractFiles.map((row) => (
                    <tr key={row.id} className="border-b border-white/5">
                      <td className="px-3 py-3"><InlineInput value={row.fileName} onChange={(value) => setContractFiles((rows) => rows.map((item) => item.id === row.id ? { ...item, fileName: value } : item))} /></td>
                      <td className="px-3 py-3"><InlineInput value={row.fileUrl} onChange={(value) => setContractFiles((rows) => rows.map((item) => item.id === row.id ? { ...item, fileUrl: value } : item))} /></td>
                      <td className="px-3 py-3">
                        <InlineSelect
                          value={row.fileType}
                          onChange={(value) => setContractFiles((rows) => rows.map((item) => item.id === row.id ? { ...item, fileType: value as ContractFileRow['fileType'] } : item))}
                          options={['CONTRACT_SCAN', 'APPENDIX', 'SLA', 'PENALTY', 'OTHER']}
                          labels={{ CONTRACT_SCAN: 'Scan há»£p Ä‘á»“ng', APPENDIX: 'Phá»¥ lá»¥c', SLA: 'SLA', PENALTY: 'Pháº¡t', OTHER: 'KhÃ¡c' }}
                        />
                      </td>
                      <td className="px-3 py-3"><InlineInput value={row.notes} onChange={(value) => setContractFiles((rows) => rows.map((item) => item.id === row.id ? { ...item, notes: value } : item))} /></td>
                      <td className="px-3 py-3 text-right">
                        <RowDeleteButton onClick={() => setContractFiles((rows) => rows.length === 1 ? rows : rows.filter((item) => item.id !== row.id))} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </StructuredTableCard>
        );
      case 'versions':
        return (
          <div className="space-y-4">
            <label className="block">
              <span className="mb-2 block text-[10px] font-black uppercase tracking-normal text-[var(--color-text-muted)]">Ghi chÃº phiÃªn báº£n khá»Ÿi táº¡o</span>
              <textarea
                value={versionNote}
                onChange={(event) => setVersionNote(event.target.value)}
                rows={4}
                className="w-full rounded-xl border border-[var(--color-border)]/20 bg-[#0D1324]/70 px-4 py-3 text-sm font-bold text-white outline-none focus:border-[#2563EB]"
                placeholder="VÃ­ dá»¥: Ã¡p dá»¥ng Ä‘Æ¡n giÃ¡ má»›i tá»« 01/06, bá»• sung quy táº¯c pháº¡t thiáº¿u quÃ¢n..."
              />
            </label>
            <div className="rounded-2xl border border-amber-500/20 bg-amber-500/10 p-4 text-sm font-semibold text-amber-200">
              Há»‡ thá»‘ng hiá»‡n chÆ°a cÃ³ báº£ng `ContractVersion` riÃªng. Tab nÃ y dÃ¹ng Ä‘á»ƒ chuáº©n hÃ³a dá»¯ liá»‡u vÃ  hiá»ƒn thá»‹ lá»‹ch sá»­ phiÃªn báº£n mÃ´ phá»ng tá»« áº£nh chá»¥p cáº¥u hÃ¬nh Ä‘á»ƒ quáº£n trá»‹ viÃªn lÃ m quen vá»›i quy trÃ¬nh má»›i.
            </div>
            <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
              <p className="text-[10px] font-black uppercase tracking-normal text-[var(--color-text-muted)]">Báº£n xem trÆ°á»›c cá»§a phiÃªn báº£n sáº½ Ä‘Æ°á»£c lÆ°u</p>
              <div className="mt-3 grid grid-cols-4 gap-3 text-sm font-black text-white">
                <Metric label="PhiÃªn báº£n" value="Rev.1" />
                <Metric label="Tráº¡ng thÃ¡i" value={contractForm.status} />
                <Metric label="Hiá»‡u lá»±c tá»«" value={contractForm.startDate || 'ChÆ°a chá»n'} />
                <Metric label="Hiá»‡u lá»±c Ä‘áº¿n" value={contractForm.endDate || 'ChÆ°a chá»n'} />
              </div>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  const renderContractDetail = () => {
    if (!selectedContract) {
      return (
        <SCMDCard className="p-6">
          <p className="text-sm font-bold text-[var(--color-text-secondary)]">ChÆ°a cÃ³ há»£p Ä‘á»“ng Ä‘á»ƒ xem chi tiáº¿t.</p>
        </SCMDCard>
      );
    }

    const lineItems = getContractLineItems(selectedContract);
    const shiftRequirements = getShiftRequirements(selectedContract);
    const staffStandards = getStaffStandards(selectedContract);
    const penaltyRules = getPenaltyRules(selectedContract);
    const checklistRequirements = getChecklistRequirements(selectedContract);
    const fileRows = getContractFiles(selectedContract);
    const versionHistory = getVersionHistory(selectedContract);

    return (
      <SCMDCard className="p-5">
        <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
          <div>
            <h3 className="text-xl font-black uppercase text-white">{selectedContract.contractName || selectedContract.siteName}</h3>
            <p className="mt-1 text-xs font-bold uppercase text-[var(--color-text-muted)]">
              {selectedContract.contractCode || selectedContract.id} Â· {selectedContract.vendor?.name || vendors.find((v) => v.id === selectedContract.vendorId)?.name || 'NhÃ  tháº§u'}
            </p>
          </div>
          <Badge value={selectedContract.status} />
        </div>

        <div className="mt-5 grid grid-cols-2 gap-3 md:grid-cols-6">
          <Metric label="Má»¥c tiÃªu" value={selectedContract.site?.siteName || selectedContract.siteName} />
          <Metric label="Báº£o vá»‡/ca" value={selectedContract.guardCountPerShift} />
          <Metric label="Tá»« ngÃ y" value={new Date(selectedContract.startDate).toLocaleDateString('vi-VN')} />
          <Metric label="Äáº¿n ngÃ y" value={new Date(selectedContract.endDate).toLocaleDateString('vi-VN')} />
          <Metric label="GiÃ¡ trá»‹" value={Number(selectedContract.value || 0).toLocaleString('vi-VN')} />
          <Metric label="Nghiá»‡m thu tá»‘i thiá»ƒu" value={`${selectedContract.acceptancePolicy?.minimumCompliancePercent || 95}%`} />
        </div>

        <div className="mt-5 flex flex-wrap gap-2 rounded-xl border border-white/10 bg-[#0D1324]/60 p-2">
          {CONTRACT_TABS.map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setContractDetailTab(tab.id)}
              className={cn(
                'min-h-10 rounded-lg px-3 text-[10px] font-black uppercase transition',
                contractDetailTab === tab.id ? 'bg-[#2563EB] text-white' : 'text-[var(--color-text-muted)] hover:text-white'
              )}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="mt-5">
          {contractDetailTab === 'overview' && (
            <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
              <Policy icon={Route} label="Tuáº§n tra" value={`${selectedContract.slaConfig?.patrolCompletionTargetPercent || selectedContract.slaConfig?.min_patrol_compliance || 0}% hoÃ n thÃ nh`} />
              <Policy icon={AlertTriangle} label="Sá»± cá»‘" value={`${selectedContract.slaConfig?.incidentResponseMinutes || selectedContract.slaConfig?.max_incident_response_minutes || 0} phÃºt pháº£n há»“i`} />
              <Policy icon={FileText} label="Báº±ng chá»©ng" value={(selectedContract.evidencePolicy?.requiredEvidenceTypes || selectedContract.slaConfig?.requiredEvidenceTypes || ['PHOTO']).join(', ')} />
            </div>
          )}

          {contractDetailTab === 'pricing' && <DetailTablePricing rows={lineItems} guardPosts={guardPosts} />}
          {contractDetailTab === 'posts' && <DetailTablePosts rows={shiftRequirements} guardPosts={guardPosts} />}
          {contractDetailTab === 'staff-standards' && <DetailTableStandards rows={staffStandards} />}
          {contractDetailTab === 'penalties' && <DetailTablePenalties rows={penaltyRules} />}
          {contractDetailTab === 'checklist' && <DetailTableChecklist rows={checklistRequirements} />}
          {contractDetailTab === 'files' && <DetailTableFiles rows={fileRows} />}
          {contractDetailTab === 'versions' && <DetailTableVersions rows={versionHistory} />}
        </div>
      </SCMDCard>
    );
  };

  return (
    <div className="space-y-5 pb-20">
      <header className="sticky top-0 z-30 -mx-4 border-b border-white/10 bg-slate-950/96 px-4 py-4 backdrop-blur-xl sm:-mx-6 sm:px-6 lg:-mx-8 lg:px-8">
        <div className="mx-auto flex max-w-[1500px] flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
          <div className="min-w-0">
            <h1 className="text-[24px] font-bold tracking-[-0.02em] text-white">Nhà thầu & hợp đồng</h1>
            <p className="mt-1 text-[14px] font-medium leading-6 text-slate-300">
              Quản lý vendor, mục tiêu, chốt và hợp đồng theo hướng đối soát dịch vụ bảo vệ thuê ngoài.
            </p>
          </div>
          <nav className="flex shrink-0 flex-wrap gap-4 lg:justify-end" aria-label="Điều hướng nhà thầu và hợp đồng">
            {(isVendorActor
              ? [
                  ['scheduler', 'Điều phối ca trực'],
                  ['contracts', 'Hợp đồng / SLA'],
                ]
              : [
                  ['vendors', 'Nhà thầu'],
                  ['sites', 'Mục tiêu / Chốt'],
                  ['contracts', 'Hợp đồng / SLA'],
                  ...(canManageScheduling ? [['scheduler', 'Điều phối ca trực']] : []),
                ]).map(([key, label]) => (
              <button
                key={key}
                onClick={() => setActiveTab(key as WorkspaceTab)}
                className={cn(
                  'min-h-9 border-b-2 px-1 text-[13px] font-semibold transition-colors',
                  activeTab === key ? 'border-[#2563EB] text-white' : 'border-transparent text-slate-400 hover:text-white',
                )}
              >
                {label}
              </button>
            ))}
          </nav>
        </div>
      </header>

      {aiContractScanAvailability?.status === 'BLOCKED_BY_GOVERNANCE' && (
        <SCMDCard className="border-amber-500/30 bg-amber-500/10 p-5">
          <div className="flex items-start gap-3">
            <AlertTriangle size={20} className="mt-0.5 text-amber-300" />
            <div>
              <p className="text-sm font-black uppercase text-amber-200">QuÃ©t AI cho há»£p Ä‘á»“ng Ä‘ang bá»‹ cháº·n á»Ÿ táº§ng quáº£n trá»‹</p>
              <p className="mt-1 text-sm font-semibold text-amber-100/90">
                GÃ³i thuÃª bao cÃ³ thá»ƒ bao gá»“m tÃ­nh nÄƒng nÃ y, nhÆ°ng mÃ´i trÆ°á»ng cháº¡y hiá»‡n chÆ°a cho phÃ©p sá»­ dá»¥ng vÃ¬ bá»™ quy táº¯c há»£p Ä‘á»“ng chÆ°a sáºµn sÃ ng.
              </p>
              <div className="mt-3 flex flex-wrap gap-2 text-[10px] font-black uppercase tracking-normal">
                <span className="rounded-lg border border-emerald-500/20 bg-emerald-500/10 px-2 py-1 text-emerald-300">GÃ³i dá»‹ch vá»¥: ÄÃ£ báº­t</span>
                <span className="rounded-lg border border-amber-500/20 bg-amber-500/10 px-2 py-1 text-amber-200">MÃ´i trÆ°á»ng cháº¡y: Bá»‹ cháº·n bá»Ÿi chÃ­nh sÃ¡ch quáº£n trá»‹</span>
                <span className="rounded-lg border border-white/10 bg-white/5 px-2 py-1 text-[var(--color-text-secondary)]">LÃ½ do: {aiContractScanAvailability.reason || 'KhÃ´ng cÃ³'}</span>
              </div>
            </div>
          </div>
        </SCMDCard>
      )}

      <div className="flex flex-col gap-3 border-b border-white/8 pb-3 lg:flex-row lg:items-center lg:justify-between">
        <div className="relative w-full lg:max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--color-text-muted)]" size={16} />
          <input
            value={searchTerm}
            onChange={(event) => setSearchTerm(event.target.value)}
            placeholder="Tìm nhà thầu, mục tiêu hoặc mã hợp đồng"
            className="min-h-10 w-full rounded-lg border border-[var(--color-border)]/15 bg-[#0D1324]/65 pl-10 pr-4 text-sm font-medium text-white outline-none focus:border-[#2563EB]"
          />
        </div>
        <div className="flex flex-wrap gap-2 text-[12px] font-semibold">
          <span className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1.5 text-slate-200">{vendors.length} nhà thầu</span>
          <span className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1.5 text-slate-200">{sites.filter((s) => s.status === 'ACTIVE').length} mục tiêu active</span>
          <span className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1.5 text-slate-200">{guardPosts.length} chốt</span>
          <span className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1.5 text-slate-200">{contracts.filter((c) => c.status === 'ACTIVE').length} hợp đồng active</span>
        </div>
      </div>


      {activeTab === 'vendors' && !isVendorActor && (
        <div className="grid grid-cols-1 gap-5 xl:grid-cols-[minmax(0,1fr)_360px]">
          <SCMDCard className="overflow-hidden p-0">
            <div className="border-b border-white/8 px-4 py-3">
              <h3 className="text-sm font-bold text-white">Danh sách nhà thầu</h3>
              <p className="mt-1 text-[12px] text-[var(--color-text-secondary)]">Ưu tiên nhìn trạng thái, số site, số hợp đồng và mức tuân thủ ngay trên một bảng.</p>
            </div>
            <div className="overflow-x-auto">
              <table className="min-w-full text-sm">
                <thead>
                  <tr className="border-b border-white/8 text-left text-[11px] font-semibold text-[var(--color-text-muted)]">
                    <th className="px-4 py-3">Nhà thầu</th>
                    <th className="px-4 py-3">Liên hệ</th>
                    <th className="px-4 py-3">Site</th>
                    <th className="px-4 py-3">Hợp đồng</th>
                    <th className="px-4 py-3">Rủi ro</th>
                    <th className="px-4 py-3">Tuân thủ</th>
                    <th className="px-4 py-3">Trạng thái</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredVendors.map((vendor) => (
                    <tr key={vendor.id} className="border-b border-white/5 hover:bg-white/[0.03]">
                      <td className="px-4 py-3">
                        <p className="font-semibold text-white">{vendor.name}</p>
                        <p className="mt-1 text-[11px] text-[var(--color-text-secondary)]">{vendor.serviceScope || 'Dịch vụ bảo vệ thuê ngoài'}</p>
                      </td>
                      <td className="px-4 py-3 text-[12px] text-[var(--color-text-secondary)]">
                        <p>{vendor.contactPerson || vendor.contact_person || 'Chưa có liên hệ'}</p>
                        <p className="mt-1">{vendor.phone || 'Chưa có số'}</p>
                      </td>
                      <td className="px-4 py-3 text-white">{sites.filter((s) => s.vendorId === vendor.id || s.vendor?.id === vendor.id).length}</td>
                      <td className="px-4 py-3 text-white">{contracts.filter((c) => c.vendorId === vendor.id && c.status === 'ACTIVE').length}</td>
                      <td className="px-4 py-3">
                        <span className={cn('rounded-full px-2 py-1 text-[11px] font-semibold', vendor.riskLevel === 'HIGH' ? 'bg-red-500/10 text-red-300' : vendor.riskLevel === 'MEDIUM' ? 'bg-amber-500/10 text-amber-300' : 'bg-emerald-500/10 text-emerald-300')}>
                          {vendor.riskLevel || 'LOW'}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-white">{Math.round(vendor.score || 100)}%</td>
                      <td className="px-4 py-3"><Badge value={vendor.status} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </SCMDCard>
          <FormPanel title="Tạo nhà thầu" onSubmit={createVendor} isSaving={isSaving}>
            <Field label="Tên nhà thầu" value={vendorForm.name} onChange={(v) => setVendorForm({ ...vendorForm, name: v })} required />
            <Field label="Mã số thuế" value={vendorForm.taxCode} onChange={(v) => setVendorForm({ ...vendorForm, taxCode: v })} />
            <Field label="Người liên hệ" value={vendorForm.contactPerson} onChange={(v) => setVendorForm({ ...vendorForm, contactPerson: v })} required />
            <Field label="Điện thoại" value={vendorForm.phone} onChange={(v) => setVendorForm({ ...vendorForm, phone: v })} required />
            <Field label="Email" value={vendorForm.email} onChange={(v) => setVendorForm({ ...vendorForm, email: v })} required type="email" />
            <Select label="Mức độ rủi ro" value={vendorForm.riskLevel} onChange={(v) => setVendorForm({ ...vendorForm, riskLevel: v })} options={['LOW', 'MEDIUM', 'HIGH']} labels={{ LOW: 'Thấp', MEDIUM: 'Trung bình', HIGH: 'Cao' }} />
          </FormPanel>
        </div>
      )}

      {activeTab === 'sites' && !isVendorActor && (
        <div className="grid grid-cols-1 gap-5 xl:grid-cols-[minmax(0,1fr)_360px]">
          <SCMDCard className="overflow-hidden p-0">
            <div className="border-b border-white/8 px-4 py-3">
              <h3 className="text-sm font-bold text-white">Danh sách mục tiêu / chốt</h3>
              <p className="mt-1 text-[12px] text-[var(--color-text-secondary)]">Bảng này ưu tiên site, vendor, số chốt và hợp đồng active để thao tác nhanh.</p>
            </div>
            <div className="overflow-x-auto">
              <table className="min-w-full text-sm">
                <thead>
                  <tr className="border-b border-white/8 text-left text-[11px] font-semibold text-[var(--color-text-muted)]">
                    <th className="px-4 py-3">Mục tiêu</th>
                    <th className="px-4 py-3">Nhà thầu</th>
                    <th className="px-4 py-3">Chốt</th>
                    <th className="px-4 py-3">Hợp đồng</th>
                    <th className="px-4 py-3">Loại</th>
                    <th className="px-4 py-3">Trạng thái</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredSites.map((site) => {
                    const sitePosts = guardPosts.filter((post) => post.siteId === site.id);
                    const activeContract = contracts.find((contract) => contract.siteId === site.id && contract.status === 'ACTIVE');
                    return (
                      <tr key={site.id} className="border-b border-white/5 hover:bg-white/[0.03]">
                        <td className="px-4 py-3">
                          <button onClick={() => setSelectedSiteId(site.id)} className="text-left font-semibold text-white hover:text-[#93C5FD]">
                            {site.siteName}
                          </button>
                          <p className="mt-1 text-[11px] text-[var(--color-text-secondary)]">{site.address}</p>
                        </td>
                        <td className="px-4 py-3 text-white">{site.vendor?.name || activeContract?.vendor?.name || 'Chưa gán'}</td>
                        <td className="px-4 py-3 text-white">{sitePosts.length}</td>
                        <td className="px-4 py-3 text-white">{activeContract ? activeContract.contractCode || 'Có' : 'Chưa có'}</td>
                        <td className="px-4 py-3 text-white">{site.siteType}</td>
                        <td className="px-4 py-3"><Badge value={site.status} /></td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            {selectedSite?.id && selectedSitePosts.length > 0 ? (
              <div className="border-t border-white/8 px-4 py-3">
                <p className="mb-3 text-[12px] font-semibold text-white">Chốt thuộc mục tiêu đang chọn</p>
                <div className="grid grid-cols-1 gap-2 md:grid-cols-2">
                  {selectedSitePosts.map((post) => (
                    <div key={post.id} className="rounded-lg border border-white/8 bg-white/[0.03] p-3">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <p className="font-semibold text-white">{post.postName}</p>
                          <p className="mt-1 text-[11px] text-[var(--color-text-secondary)]">{post.postType} · {post.requiredGuardCount} bảo vệ/ca · {post.radiusMeters}m</p>
                        </div>
                        <Badge value={post.status} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : null}
          </SCMDCard>
          <div className="space-y-5">
            <FormPanel title="Táº¡o má»¥c tiÃªu" onSubmit={createSite} isSaving={isSaving}>
              <Field label="TÃªn má»¥c tiÃªu" value={siteForm.siteName} onChange={(v) => setSiteForm({ ...siteForm, siteName: v })} required />
              <Field label="Äá»‹a chá»‰" value={siteForm.address} onChange={(v) => setSiteForm({ ...siteForm, address: v })} required />
              <Select label="Loáº¡i má»¥c tiÃªu" value={siteForm.siteType} onChange={(v) => setSiteForm({ ...siteForm, siteType: v })} options={['FACTORY', 'OFFICE', 'WAREHOUSE', 'BUILDING', 'RETAIL', 'OTHER']} />
              <Select label="NhÃ  tháº§u phá»¥ trÃ¡ch" value={siteForm.vendorId} onChange={(v) => setSiteForm({ ...siteForm, vendorId: v })} options={['', ...vendors.map((v) => v.id)]} labels={{ '': 'Chá»n sau', ...Object.fromEntries(vendors.map((v) => [v.id, v.name])) }} />
              <Field label="Quáº£n lÃ½ má»¥c tiÃªu" value={siteForm.managerName} onChange={(v) => setSiteForm({ ...siteForm, managerName: v })} />
              <Field label="Sá»‘ Ä‘iá»‡n thoáº¡i quáº£n lÃ½" value={siteForm.managerPhone} onChange={(v) => setSiteForm({ ...siteForm, managerPhone: v })} />
            </FormPanel>

            <FormPanel title="Táº¡o chá»‘t báº£o vá»‡" onSubmit={createGuardPost} isSaving={isSaving || !selectedSiteId}>
              <Select label="Má»¥c tiÃªu" value={selectedSiteId} onChange={setSelectedSiteId} options={sites.map((s) => s.id)} labels={Object.fromEntries(sites.map((s) => [s.id, s.siteName]))} />
              <Field label="TÃªn chá»‘t" value={guardPostForm.postName} onChange={(v) => setGuardPostForm({ ...guardPostForm, postName: v })} required />
              <Select label="Loáº¡i chá»‘t" value={guardPostForm.postType} onChange={(v) => setGuardPostForm({ ...guardPostForm, postType: v })} options={['GATE', 'LOBBY', 'PARKING', 'WAREHOUSE', 'PERIMETER', 'CONTROL_ROOM', 'OTHER']} />
              <Field label="QuÃ¢n sá»‘ yÃªu cáº§u" type="number" value={guardPostForm.requiredGuardCount} onChange={(v) => setGuardPostForm({ ...guardPostForm, requiredGuardCount: Number(v) })} required />
              <div className="grid grid-cols-3 gap-3">
                <Field label="Lat" value={guardPostForm.gpsLat} onChange={(v) => setGuardPostForm({ ...guardPostForm, gpsLat: v })} />
                <Field label="Lng" value={guardPostForm.gpsLng} onChange={(v) => setGuardPostForm({ ...guardPostForm, gpsLng: v })} />
                <Field label="BÃ¡n kÃ­nh" type="number" value={guardPostForm.radiusMeters} onChange={(v) => setGuardPostForm({ ...guardPostForm, radiusMeters: Number(v) })} />
              </div>
            </FormPanel>
          </div>
        </div>
      )}

      {activeTab === 'contracts' && (
        <div className="grid grid-cols-1 gap-5 xl:grid-cols-[minmax(0,1fr)_420px]">
          <div className="space-y-4">
            <SCMDCard className="overflow-hidden p-0">
              <div className="border-b border-white/8 px-4 py-3">
                <h3 className="text-sm font-bold text-white">Danh sách hợp đồng / SLA</h3>
                <p className="mt-1 text-[12px] text-[var(--color-text-secondary)]">Ưu tiên nhìn mục tiêu, vendor, trạng thái, số hạng mục và phiên bản.</p>
              </div>
              <div className="overflow-x-auto">
                <table className="min-w-full text-sm">
                  <thead>
                    <tr className="border-b border-white/8 text-left text-[11px] font-semibold text-[var(--color-text-muted)]">
                      <th className="px-4 py-3">Hợp đồng</th>
                      <th className="px-4 py-3">Mục tiêu</th>
                      <th className="px-4 py-3">Bảo vệ/ca</th>
                      <th className="px-4 py-3">Hạng mục</th>
                      <th className="px-4 py-3">Phiên bản</th>
                      <th className="px-4 py-3">Trạng thái</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredContracts.map((contract) => (
                      <tr key={contract.id} className={cn('border-b border-white/5 hover:bg-white/[0.03]', selectedContract?.id === contract.id && 'bg-white/[0.04]')}>
                        <td className="px-4 py-3">
                          <button onClick={() => setSelectedContractId(contract.id)} className="text-left font-semibold text-white hover:text-[#93C5FD]">
                            {contract.contractName || contract.siteName}
                          </button>
                          <p className="mt-1 text-[11px] text-[var(--color-text-secondary)]">{contract.contractCode || contract.id} · {contract.vendor?.name || vendors.find((v) => v.id === contract.vendorId)?.name || 'Nhà thầu'}</p>
                        </td>
                        <td className="px-4 py-3 text-white">{contract.site?.siteName || contract.siteName}</td>
                        <td className="px-4 py-3 text-white">{contract.guardCountPerShift}</td>
                        <td className="px-4 py-3 text-white">{getContractLineItems(contract).length}</td>
                        <td className="px-4 py-3 text-white">Rev.{getVersionHistory(contract)[0]?.versionNo || 1}</td>
                        <td className="px-4 py-3"><Badge value={contract.status} /></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </SCMDCard>

            {!isVendorActor && renderContractDetail()}
          </div>
          <div className="space-y-4">
          {!isVendorActor ? (
            <SCMDCard className="p-5">
              <form className="space-y-5" onSubmit={createContract}>
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-black uppercase text-white">Biá»ƒu máº«u cáº¥u hÃ¬nh há»£p Ä‘á»“ng nÃ¢ng cao</h3>
                    <p className="mt-1 text-xs font-semibold text-[var(--color-text-secondary)]">Nháº­p theo báº£ng nghiá»‡p vá»¥; há»‡ thá»‘ng sáº½ tá»± chuyá»ƒn thÃ nh cáº¥u hÃ¬nh JSON á»Ÿ ná»n sau.</p>
                  </div>
                  <Plus size={18} className="text-[#2563EB]" />
                </div>

                <div className="flex flex-wrap gap-2 rounded-xl border border-white/10 bg-[#0D1324]/60 p-2">
                  {CONTRACT_TABS.map((tab) => (
                    <button
                      key={tab.id}
                      type="button"
                      onClick={() => setContractEditorTab(tab.id)}
                      className={cn(
                        'min-h-10 rounded-lg px-3 text-[10px] font-black uppercase transition',
                        contractEditorTab === tab.id ? 'bg-[#2563EB] text-white' : 'text-[var(--color-text-muted)] hover:text-white'
                      )}
                    >
                      {tab.label}
                    </button>
                  ))}
                </div>

                {renderContractEditorTab()}

                <SCMDButton type="submit" isLoading={isSaving} className="min-h-12 w-full !rounded-xl !bg-[#2563EB]">
                  LÆ°u cáº¥u hÃ¬nh há»£p Ä‘á»“ng
                </SCMDButton>
              </form>
            </SCMDCard>
          ) : (
            <SCMDCard className="p-5">
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-black uppercase text-white">Pháº¡m vi há»£p Ä‘á»“ng Ä‘Æ°á»£c phÃ¢n cÃ´ng</h3>
                  <p className="mt-1 text-xs font-semibold text-[var(--color-text-secondary)]">
                    Chá»‰ huy chá»‰ Ä‘Æ°á»£c xem há»£p Ä‘á»“ng/SLA trong pháº¡m vi nhÃ  tháº§u Ä‘á»ƒ phÃ¢n ca vÃ  Ä‘á»‘i chiáº¿u, khÃ´ng Ä‘Æ°á»£c chá»‰nh sá»­a há»£p Ä‘á»“ng.
                  </p>
                </div>
                {renderContractDetail()}
              </div>
            </SCMDCard>
          )}
          </div>
        </div>
      )}

      {activeTab === 'scheduler' && <ShiftSchedulerView />}
    </div>
  );
};

const FormPanel = ({ title, children, onSubmit, isSaving }: { title: string; children: React.ReactNode; onSubmit: (event: React.FormEvent) => void; isSaving: boolean }) => (
  <SCMDCard className="p-5">
    <form className="space-y-4" onSubmit={onSubmit}>
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-black uppercase text-white">{title}</h3>
        <Plus size={18} className="text-[#2563EB]" />
      </div>
      {children}
      <SCMDButton type="submit" isLoading={isSaving} className="min-h-12 w-full !rounded-xl !bg-[#2563EB]">
        LÆ°u cáº¥u hÃ¬nh
      </SCMDButton>
    </form>
  </SCMDCard>
);

const StructuredTableCard = ({
  title,
  description,
  actionLabel,
  onAdd,
  children,
}: {
  title: string;
  description: string;
  actionLabel: string;
  onAdd: () => void;
  children: React.ReactNode;
}) => (
  <div className="space-y-3">
    <div className="flex flex-col gap-3 rounded-2xl border border-white/10 bg-white/5 p-4 md:flex-row md:items-center md:justify-between">
      <div>
        <p className="text-sm font-black uppercase text-white">{title}</p>
        <p className="mt-1 text-xs font-semibold text-[var(--color-text-secondary)]">{description}</p>
      </div>
      <button
        type="button"
        onClick={onAdd}
        className="inline-flex min-h-10 items-center justify-center rounded-xl border border-[#2563EB]/20 bg-[#2563EB]/10 px-4 text-[10px] font-black uppercase text-[#93C5FD] transition hover:bg-[#2563EB]/20"
      >
        {actionLabel}
      </button>
    </div>
    <div className="rounded-2xl border border-white/10 bg-[#0D1324]/55">{children}</div>
  </div>
);

const Field = ({ label, value, onChange, type = 'text', required = false }: { label: string; value: string | number; onChange: (value: string) => void; type?: string; required?: boolean }) => (
  <label className="block">
    <span className="mb-2 block text-[10px] font-black uppercase tracking-normal text-[var(--color-text-muted)]">{label}</span>
    <input
      type={type}
      value={value}
      onChange={(event) => onChange(event.target.value)}
      required={required}
      className="min-h-12 w-full rounded-xl border border-[var(--color-border)]/20 bg-[#0D1324]/70 px-4 text-sm font-bold text-white outline-none focus:border-[#2563EB]"
    />
  </label>
);

const Select = ({ label, value, onChange, options, labels = {} }: { label: string; value: string; onChange: (value: string) => void; options: string[]; labels?: Record<string, string> }) => (
  <label className="block">
    <span className="mb-2 block text-[10px] font-black uppercase tracking-normal text-[var(--color-text-muted)]">{label}</span>
    <select
      value={value}
      onChange={(event) => onChange(event.target.value)}
      className="min-h-12 w-full rounded-xl border border-[var(--color-border)]/20 bg-[#0D1324]/70 px-4 text-sm font-bold text-white outline-none focus:border-[#2563EB]"
    >
      {options.map((option) => (
        <option key={option || 'empty'} value={option}>{labels[option] || option}</option>
      ))}
    </select>
  </label>
);

const Badge = ({ value }: { value: string }) => (
  <span className={cn('inline-flex min-h-8 items-center rounded-lg border px-3 text-[10px] font-black uppercase tracking-normal', statusTone(value))}>
    {value}
  </span>
);

const Metric = ({ label, value }: { label: string; value: React.ReactNode }) => (
  <div className="rounded-xl border border-white/10 bg-white/5 p-3">
    <p className="text-[10px] font-black uppercase tracking-normal text-[var(--color-text-muted)]">{label}</p>
    <p className="mt-1 truncate text-sm font-black text-white">{value}</p>
  </div>
);

const Policy = ({ icon: Icon, label, value }: { icon: any; label: string; value: string }) => (
  <div className="flex items-center gap-3 rounded-xl border border-white/10 bg-white/5 p-4">
    <Icon size={18} className="text-[#2563EB]" />
    <div>
      <p className="text-[10px] font-black uppercase tracking-normal text-[var(--color-text-muted)]">{label}</p>
      <p className="text-sm font-black text-white">{value}</p>
    </div>
  </div>
);

const InlineInput = ({ value, onChange, type = 'text' }: { value: string | number; onChange: (value: string) => void; type?: string }) => (
  <input
    type={type}
    value={value}
    onChange={(event) => onChange(event.target.value)}
    className="min-h-10 w-full rounded-lg border border-white/10 bg-white/5 px-3 text-sm font-bold text-white outline-none focus:border-[#2563EB]"
  />
);

const InlineSelect = ({ value, onChange, options, labels = {} }: { value: string; onChange: (value: string) => void; options: string[]; labels?: Record<string, string> }) => (
  <select
    value={value}
    onChange={(event) => onChange(event.target.value)}
    className="min-h-10 w-full rounded-lg border border-white/10 bg-white/5 px-3 text-sm font-bold text-white outline-none focus:border-[#2563EB]"
  >
    {options.map((option) => (
      <option key={option || 'empty'} value={option}>
        {labels[option] || option}
      </option>
    ))}
  </select>
);

const InlineToggle = ({ checked, onChange }: { checked: boolean; onChange: (checked: boolean) => void }) => (
  <button
    type="button"
    onClick={() => onChange(!checked)}
    className={cn(
      'inline-flex min-h-10 min-w-20 items-center justify-center rounded-lg border px-3 text-[10px] font-black uppercase transition',
      checked ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-300' : 'border-white/10 bg-white/5 text-[var(--color-text-muted)]'
    )}
  >
    {checked ? 'CÃ³' : 'KhÃ´ng'}
  </button>
);

const RowDeleteButton = ({ onClick }: { onClick: () => void }) => (
  <button
    type="button"
    onClick={onClick}
    className="rounded-lg border border-red-500/20 bg-red-500/10 px-3 py-2 text-[10px] font-black uppercase text-red-300 transition hover:bg-red-500/20"
  >
    XÃ³a
  </button>
);

const DetailEmpty = ({ title, description }: { title: string; description: string }) => (
  <div className="rounded-2xl border border-dashed border-white/10 bg-white/5 p-5 text-center">
    <p className="text-sm font-black uppercase text-white">{title}</p>
    <p className="mt-2 text-xs font-semibold text-[var(--color-text-secondary)]">{description}</p>
  </div>
);

const DetailTablePricing = ({ rows, guardPosts }: { rows: PricingRow[]; guardPosts: GuardPostRecord[] }) => {
  if (rows.length === 0) {
    return <DetailEmpty title="ChÆ°a cÃ³ báº£ng Ä‘Æ¡n giÃ¡" description="Há»£p Ä‘á»“ng nÃ y chÆ°a Ä‘Æ°á»£c chuáº©n hÃ³a háº¡ng má»¥c theo chá»‘t/ca." />;
  }
  return (
    <div className="overflow-x-auto">
      <table className="min-w-full text-sm">
        <thead>
          <tr className="border-b border-white/10 text-left text-[10px] font-black uppercase text-[var(--color-text-muted)]">
            <th className="px-3 py-3">Chá»‘t</th>
            <th className="px-3 py-3">Ca</th>
            <th className="px-3 py-3">Sá»‘ ngÆ°á»i</th>
            <th className="px-3 py-3">ÄÆ¡n giÃ¡</th>
            <th className="px-3 py-3">Chu ká»³</th>
            <th className="px-3 py-3">Ghi chÃº</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={row.id} className="border-b border-white/5">
              <td className="px-3 py-3 text-white">{guardPosts.find((post) => post.id === row.guardPostId)?.postName || row.guardPostId}</td>
              <td className="px-3 py-3 text-white">{row.shiftLabel}</td>
              <td className="px-3 py-3 text-white">{row.requiredCount}</td>
              <td className="px-3 py-3 text-white">{Number(row.unitPrice || 0).toLocaleString('vi-VN')}</td>
              <td className="px-3 py-3 text-white">{row.billingCycle === 'SHIFT' ? 'Theo ca' : 'Theo thÃ¡ng'}</td>
              <td className="px-3 py-3 text-[var(--color-text-secondary)]">{row.notes || 'â€”'}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

const DetailTablePosts = ({ rows, guardPosts }: { rows: ShiftRequirementRow[]; guardPosts: GuardPostRecord[] }) => {
  if (rows.length === 0) {
    return <DetailEmpty title="ChÆ°a cÃ³ báº£ng chá»‘t / ca" description="Há»£p Ä‘á»“ng nÃ y chÆ°a Ä‘Æ°á»£c tÃ¡ch yÃªu cáº§u váº­n hÃ nh theo chá»‘t/ca." />;
  }
  return (
    <div className="overflow-x-auto">
      <table className="min-w-full text-sm">
        <thead>
          <tr className="border-b border-white/10 text-left text-[10px] font-black uppercase text-[var(--color-text-muted)]">
            <th className="px-3 py-3">Chá»‘t</th>
            <th className="px-3 py-3">Ca</th>
            <th className="px-3 py-3">Thá»i gian</th>
            <th className="px-3 py-3">Sá»‘ ngÆ°á»i</th>
            <th className="px-3 py-3">Tuáº§n tra</th>
            <th className="px-3 py-3">Ghi chÃº</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={row.id} className="border-b border-white/5">
              <td className="px-3 py-3 text-white">{guardPosts.find((post) => post.id === row.guardPostId)?.postName || row.guardPostId}</td>
              <td className="px-3 py-3 text-white">{row.shiftLabel}</td>
              <td className="px-3 py-3 text-white">{row.startTime} - {row.endTime}</td>
              <td className="px-3 py-3 text-white">{row.requiredCount}</td>
              <td className="px-3 py-3 text-white">{row.patrolRequired ? 'CÃ³' : 'KhÃ´ng'}</td>
              <td className="px-3 py-3 text-[var(--color-text-secondary)]">
                {[
                  row.appliesOnMonday !== false ? 'T2' : null,
                  row.appliesOnTuesday !== false ? 'T3' : null,
                  row.appliesOnWednesday !== false ? 'T4' : null,
                  row.appliesOnThursday !== false ? 'T5' : null,
                  row.appliesOnFriday !== false ? 'T6' : null,
                  row.appliesOnSaturday !== false ? 'T7' : null,
                  row.appliesOnSunday !== false ? 'CN' : null,
                ].filter(Boolean).join(', ')}{row.notes ? ` Â· ${row.notes}` : ''}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

const DetailTableStandards = ({ rows }: { rows: StaffStandardRow[] }) => {
  if (rows.length === 0) {
    return <DetailEmpty title="ChÆ°a cÃ³ tiÃªu chuáº©n nhÃ¢n sá»±" description="Há»£p Ä‘á»“ng nÃ y chÆ°a khai bÃ¡o tiÃªu chuáº©n báº£o vá»‡ theo chá»‘t/ca." />;
  }
  return (
    <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
      {rows.map((row) => (
        <div key={row.id} className="rounded-xl border border-white/10 bg-white/5 p-4">
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="font-black uppercase text-white">{row.standardName}</p>
              <p className="mt-1 text-[10px] font-black uppercase text-[var(--color-text-muted)]">{row.standardCode || 'STD'}</p>
            </div>
            <span className={cn('rounded-lg px-2 py-1 text-[10px] font-black uppercase', row.required ? 'bg-rose-500/10 text-rose-300' : 'bg-amber-500/10 text-amber-300')}>
              {row.required ? 'Báº®T BUá»˜C' : 'Cáº¢NH BÃO'}
            </span>
          </div>
          <p className="mt-2 text-xs font-bold text-[var(--color-text-secondary)]">Ãp dá»¥ng: {row.appliesTo || 'Táº¥t cáº£'}</p>
          <p className="mt-2 text-sm font-semibold text-white">{row.details || 'KhÃ´ng cÃ³ diá»…n giáº£i bá»• sung.'}</p>
        </div>
      ))}
    </div>
  );
};

const DetailTablePenalties = ({ rows }: { rows: PenaltyRuleRow[] }) => {
  if (rows.length === 0) {
    return <DetailEmpty title="ChÆ°a cÃ³ Ä‘iá»u khoáº£n pháº¡t" description="Há»£p Ä‘á»“ng nÃ y chÆ°a chuáº©n hÃ³a quy táº¯c pháº¡t theo dáº¡ng báº£ng." />;
  }
  return (
    <div className="overflow-x-auto">
      <table className="min-w-full text-sm">
        <thead>
          <tr className="border-b border-white/10 text-left text-[10px] font-black uppercase text-[var(--color-text-muted)]">
            <th className="px-3 py-3">MÃ£ lá»—i</th>
            <th className="px-3 py-3">Lá»—i</th>
            <th className="px-3 py-3">Má»©c pháº¡t</th>
            <th className="px-3 py-3">ÄÆ¡n vá»‹</th>
            <th className="px-3 py-3">Gia háº¡n</th>
            <th className="px-3 py-3">Tráº§n thÃ¡ng</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={row.id} className="border-b border-white/5">
              <td className="px-3 py-3 text-white">{row.violationCode || 'â€”'}</td>
              <td className="px-3 py-3 text-white">{row.violationName}</td>
              <td className="px-3 py-3 text-white">{Number(row.penaltyAmount || 0).toLocaleString('vi-VN')}</td>
              <td className="px-3 py-3 text-white">{row.penaltyUnit}</td>
              <td className="px-3 py-3 text-white">{row.graceMinutes} phÃºt</td>
              <td className="px-3 py-3 text-white">{Number(row.monthlyCap || 0).toLocaleString('vi-VN')}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

const DetailTableChecklist = ({ rows }: { rows: ChecklistRow[] }) => {
  if (rows.length === 0) {
    return <DetailEmpty title="ChÆ°a cÃ³ danh má»¥c kiá»ƒm tra / ná»™i quy" description="Há»£p Ä‘á»“ng nÃ y chÆ°a cáº¥u hÃ¬nh danh má»¥c kiá»ƒm tra dá»¯ liá»‡u thá»±c Ä‘á»‹a." />;
  }
  return (
    <div className="overflow-x-auto">
      <table className="min-w-full text-sm">
        <thead>
          <tr className="border-b border-white/10 text-left text-[10px] font-black uppercase text-[var(--color-text-muted)]">
            <th className="px-3 py-3">Checklist</th>
            <th className="px-3 py-3">Loáº¡i dá»¯ liá»‡u</th>
            <th className="px-3 py-3">Báº¯t buá»™c áº£nh?</th>
            <th className="px-3 py-3">Táº§n suáº¥t</th>
            <th className="px-3 py-3">Ghi chÃº</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={row.id} className="border-b border-white/5">
              <td className="px-3 py-3 text-white">{row.itemName}</td>
              <td className="px-3 py-3 text-white">{row.dataType}</td>
              <td className="px-3 py-3 text-white">{row.photoRequired ? 'CÃ³' : 'KhÃ´ng'}</td>
              <td className="px-3 py-3 text-white">{row.frequency}</td>
              <td className="px-3 py-3 text-[var(--color-text-secondary)]">{row.notes || 'â€”'}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

const DetailTableFiles = ({ rows }: { rows: ContractFileRow[] }) => {
  if (rows.length === 0) {
    return <DetailEmpty title="ChÆ°a cÃ³ tá»‡p há»£p Ä‘á»“ng" description="Há»£p Ä‘á»“ng nÃ y chÆ°a khai bÃ¡o báº£n quÃ©t há»£p Ä‘á»“ng hoáº·c phá»¥ lá»¥c." />;
  }
  return (
    <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
      {rows.map((row) => (
        <div key={row.id} className="rounded-xl border border-white/10 bg-white/5 p-4">
          <div className="flex items-center gap-2">
            <Paperclip size={16} className="text-[#2563EB]" />
            <p className="font-black uppercase text-white">{row.fileName}</p>
          </div>
          <p className="mt-2 text-xs font-bold text-[var(--color-text-secondary)]">{row.fileType}</p>
          <a href={row.fileUrl} target="_blank" rel="noreferrer" className="mt-3 block truncate text-sm font-bold text-[#93C5FD] hover:text-white">
            {row.fileUrl}
          </a>
          <p className="mt-2 text-sm font-semibold text-[var(--color-text-secondary)]">{row.notes || 'KhÃ´ng cÃ³ ghi chÃº'}</p>
        </div>
      ))}
    </div>
  );
};

const DetailTableVersions = ({ rows }: { rows: VersionRow[] }) => {
  if (rows.length === 0) {
    return <DetailEmpty title="ChÆ°a cÃ³ lá»‹ch sá»­ phiÃªn báº£n" description="TÃ­nh nÄƒng `ContractVersion` á»Ÿ há»‡ thá»‘ng chÆ°a Ä‘Æ°á»£c kÃ­ch hoáº¡t cho báº£n ghi nÃ y." />;
  }
  return (
    <div className="space-y-3">
      {rows.map((row) => (
        <div key={row.id} className="rounded-xl border border-white/10 bg-white/5 p-4">
          <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#2563EB]/10 text-[#2563EB]">
                <Clock3 size={18} />
              </div>
              <div>
                <p className="font-black uppercase text-white">Rev.{row.versionNo}</p>
                <p className="text-xs font-bold text-[var(--color-text-secondary)]">{row.effectiveFrom || 'â€”'} â†’ {row.effectiveTo || 'â€”'}</p>
              </div>
            </div>
            <Badge value={row.status} />
          </div>
          <p className="mt-3 text-sm font-semibold text-[var(--color-text-secondary)]">{row.note || 'KhÃ´ng cÃ³ ghi chÃº phiÃªn báº£n.'}</p>
        </div>
      ))}
    </div>
  );
};

