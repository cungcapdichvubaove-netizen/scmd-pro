import type { ActiveTab } from '../types';
import type { FilterField, TabFilterConfig } from './filterTypes';

const siteOptions = [
  { value: 'all-sites', label: 'Tất cả mục tiêu' },
  { value: 'ocb-hanoi', label: 'OCB - Chi nhánh Hà Nội' },
  { value: 'factory-a', label: 'Nhà máy A' },
];

const vendorOptions = [
  { value: 'all-vendors', label: 'Tất cả nhà cung cấp' },
  { value: 'ktc', label: 'KTC Security' },
  { value: 'alpha', label: 'Alpha Guard' },
];

const periodOptions = [
  { value: 'today', label: 'Hôm nay' },
  { value: 'current-shift', label: 'Ca hiện tại' },
  { value: 'week', label: 'Tuần này' },
  { value: 'month', label: 'Tháng này' },
];

const statusOptions = [
  { value: 'all-status', label: 'Tất cả trạng thái' },
  { value: 'ok', label: 'Đạt chuẩn' },
  { value: 'warning', label: 'Cảnh báo' },
  { value: 'breach', label: 'Vi phạm' },
];

const contractFilter: FilterField = {
  type: 'select',
  key: 'contractId',
  label: 'Hợp đồng',
  options: [{ value: 'all-contracts', label: 'Tất cả hợp đồng' }],
};

const currentMonth = new Date().toISOString().slice(0, 7);

export const TAB_FILTER_CONFIGS: Partial<Record<ActiveTab, TabFilterConfig>> = {
  overview: {
    tab: 'overview',
    title: 'Bộ lọc hàng đợi tổng quan',
    defaults: { period: 'today', site: 'all-sites', vendor: 'all-vendors', priority: 'priority-first', issueType: 'all-issues', slaRisk: 'all-sla', owner: '' },
    primary: [
      { type: 'select', key: 'period', label: 'Thời gian', options: periodOptions },
      { type: 'select', key: 'site', label: 'Mục tiêu', options: siteOptions },
      { type: 'select', key: 'vendor', label: 'Nhà cung cấp', options: vendorOptions },
      { type: 'select', key: 'priority', label: 'Ưu tiên', options: [
        { value: 'priority-first', label: 'Ưu tiên trước' },
        { value: 'critical', label: 'Cao' },
        { value: 'warning', label: 'Trung bình' },
        { value: 'all-priorities', label: 'Tất cả' },
      ] },
    ],
    advanced: [
      { type: 'select', key: 'issueType', label: 'Loại vấn đề', options: [
        { value: 'all-issues', label: 'Tất cả vấn đề' },
        { value: 'incident', label: 'Sự cố' },
        { value: 'patrol', label: 'Tuần tra' },
        { value: 'attendance', label: 'Ca trực' },
        { value: 'evidence', label: 'Bằng chứng' },
      ] },
      { type: 'select', key: 'slaRisk', label: 'Rủi ro SLA', options: [
        { value: 'all-sla', label: 'Tất cả SLA' },
        { value: 'breaching', label: 'Quá hạn' },
        { value: 'approaching', label: 'Sắp quá hạn' },
      ] },
      { type: 'search', key: 'owner', label: 'Người phụ trách', placeholder: 'Tìm người phụ trách...' },
    ],
    persist: 'url+localStorage',
  },
  attendance: {
    tab: 'attendance',
    title: 'Bộ lọc ca trực',
    defaults: { shift: 'current-shift', site: 'all-sites', vendor: 'all-vendors', coverageStatus: 'all-status', guard: '', contractId: 'all-contracts', checkInStatus: 'all-checkin', gpsStatus: 'all-gps' },
    primary: [
      { type: 'select', key: 'shift', label: 'Ngày/Ca', options: periodOptions },
      { type: 'select', key: 'site', label: 'Mục tiêu', options: siteOptions },
      { type: 'select', key: 'vendor', label: 'Nhà cung cấp', options: vendorOptions },
      { type: 'select', key: 'coverageStatus', label: 'Quân số', options: statusOptions },
    ],
    advanced: [
      { type: 'search', key: 'guard', label: 'Bảo vệ', placeholder: 'Tìm tên hoặc mã bảo vệ...' },
      contractFilter,
      { type: 'select', key: 'checkInStatus', label: 'Check-in', options: [{ value: 'all-checkin', label: 'Tất cả' }, { value: 'late', label: 'Đi trễ' }, { value: 'missing', label: 'Chưa check-in' }] },
      { type: 'select', key: 'gpsStatus', label: 'GPS', options: [{ value: 'all-gps', label: 'Tất cả' }, { value: 'valid', label: 'Đúng vị trí' }, { value: 'invalid', label: 'Sai vị trí' }] },
    ],
    persist: 'url+localStorage',
  },
  sites: {
    tab: 'sites',
    title: 'Bộ lọc mục tiêu và chốt',
    defaults: { siteType: 'all-types', siteStatus: 'ACTIVE', vendor: 'all-vendors', contractId: 'all-contracts', postCount: 'all-posts', riskLevel: 'all-risk', gpsStatus: 'all-gps' },
    primary: [
      { type: 'select', key: 'siteType', label: 'Loại site', options: [{ value: 'all-types', label: 'Tất cả loại' }, { value: 'FACTORY', label: 'Nhà máy' }, { value: 'OFFICE', label: 'Văn phòng' }, { value: 'WAREHOUSE', label: 'Kho' }] },
      { type: 'select', key: 'siteStatus', label: 'Trạng thái', options: [{ value: 'ACTIVE', label: 'Đang hoạt động' }, { value: 'INACTIVE', label: 'Tạm dừng' }, { value: 'all-status', label: 'Tất cả' }] },
      { type: 'select', key: 'vendor', label: 'Nhà cung cấp', options: vendorOptions },
    ],
    advanced: [
      contractFilter,
      { type: 'select', key: 'postCount', label: 'Số chốt', options: [{ value: 'all-posts', label: 'Tất cả' }, { value: 'missing-posts', label: 'Chưa có chốt' }, { value: 'many-posts', label: 'Nhiều chốt' }] },
      { type: 'select', key: 'riskLevel', label: 'Rủi ro', options: [{ value: 'all-risk', label: 'Tất cả' }, { value: 'HIGH', label: 'Cao' }, { value: 'MEDIUM', label: 'Trung bình' }, { value: 'LOW', label: 'Thấp' }] },
      { type: 'select', key: 'gpsStatus', label: 'GPS', options: [{ value: 'all-gps', label: 'Tất cả' }, { value: 'has-gps', label: 'Có GPS' }, { value: 'missing-gps', label: 'Thiếu GPS' }] },
    ],
    persist: 'url+localStorage',
  },
  incidents: {
    tab: 'incidents',
    title: 'Bộ lọc sự cố',
    defaults: { status: 'open', severity: 'all-severity', site: 'all-sites', sla: 'risk-first', incidentType: 'all-types', assignee: '', vendor: 'all-vendors', evidenceMissing: 'all-evidence' },
    primary: [
      { type: 'select', key: 'status', label: 'Trạng thái', options: [{ value: 'open', label: 'Sự cố mở' }, { value: 'closed', label: 'Đã đóng' }, { value: 'all-status', label: 'Tất cả' }] },
      { type: 'select', key: 'severity', label: 'Mức độ', options: [{ value: 'all-severity', label: 'Tất cả mức độ' }, { value: 'CRITICAL', label: 'Nghiêm trọng' }, { value: 'HIGH', label: 'Cao' }, { value: 'MEDIUM', label: 'Trung bình' }] },
      { type: 'select', key: 'site', label: 'Mục tiêu', options: siteOptions },
      { type: 'select', key: 'sla', label: 'SLA', options: [{ value: 'risk-first', label: 'Sắp quá SLA trước' }, { value: 'breached', label: 'Đã quá hạn' }, { value: 'within', label: 'Trong hạn' }] },
    ],
    advanced: [
      { type: 'select', key: 'incidentType', label: 'Loại sự cố', options: [{ value: 'all-types', label: 'Tất cả loại' }, { value: 'SECURITY_BREACH', label: 'Xâm nhập' }, { value: 'MISSING_GUARD', label: 'Thiếu bảo vệ' }, { value: 'CUSTOMER_COMPLAINT', label: 'Khiếu nại' }] },
      { type: 'search', key: 'assignee', label: 'Người phụ trách', placeholder: 'Tìm người phụ trách...' },
      { type: 'select', key: 'vendor', label: 'Nhà cung cấp', options: vendorOptions },
      { type: 'select', key: 'evidenceMissing', label: 'Bằng chứng', options: [{ value: 'all-evidence', label: 'Tất cả' }, { value: 'missing', label: 'Thiếu bằng chứng' }, { value: 'complete', label: 'Đủ bằng chứng' }] },
    ],
    persist: 'url+localStorage',
  },
  vendors: {
    tab: 'vendors',
    title: 'Bộ lọc nhà cung cấp',
    defaults: { status: 'ACTIVE', riskLevel: 'all-risk', complianceScore: 'all-score', activeContract: 'all-contracts', siteCount: 'all-sites', violationCount: 'all-violations' },
    primary: [
      { type: 'select', key: 'status', label: 'Trạng thái', options: [{ value: 'ACTIVE', label: 'Đang hoạt động' }, { value: 'SUSPENDED', label: 'Tạm dừng' }, { value: 'all-status', label: 'Tất cả' }] },
      { type: 'select', key: 'riskLevel', label: 'Rủi ro', options: [{ value: 'all-risk', label: 'Tất cả rủi ro' }, { value: 'HIGH', label: 'Cao' }, { value: 'MEDIUM', label: 'Trung bình' }, { value: 'LOW', label: 'Thấp' }] },
    ],
    advanced: [
      { type: 'select', key: 'complianceScore', label: 'Điểm tuân thủ', options: [{ value: 'all-score', label: 'Tất cả' }, { value: 'below-80', label: 'Dưới 80' }, { value: 'above-90', label: 'Trên 90' }] },
      { type: 'select', key: 'activeContract', label: 'Hợp đồng active', options: [{ value: 'all-contracts', label: 'Tất cả' }, { value: 'yes', label: 'Có' }, { value: 'no', label: 'Không' }] },
      { type: 'select', key: 'siteCount', label: 'Số mục tiêu', options: [{ value: 'all-sites', label: 'Tất cả' }, { value: 'none', label: 'Chưa có site' }, { value: 'many', label: 'Nhiều site' }] },
      { type: 'select', key: 'violationCount', label: 'Vi phạm', options: [{ value: 'all-violations', label: 'Tất cả' }, { value: 'has-violations', label: 'Có vi phạm' }, { value: 'none', label: 'Không vi phạm' }] },
    ],
    persist: 'url+localStorage',
  },
  staff: {
    tab: 'staff',
    title: 'Bộ lọc nhân sự',
    defaults: { search: '', vendor: 'all-vendors', site: 'all-sites', status: 'active', role: 'all', certification: 'all-certification', assignmentStatus: 'all-assignments', contractId: 'all-contracts' },
    primary: [
      { type: 'search', key: 'search', placeholder: 'Tìm nhân sự...' },
      { type: 'select', key: 'vendor', label: 'Nhà cung cấp', options: vendorOptions },
      { type: 'select', key: 'site', label: 'Mục tiêu', options: siteOptions },
      { type: 'select', key: 'status', label: 'Trạng thái', options: [{ value: 'active', label: 'Đang hoạt động' }, { value: 'inactive', label: 'Tạm dừng' }, { value: 'all', label: 'Tất cả' }] },
    ],
    advanced: [
      { type: 'select', key: 'role', label: 'Vai trò', options: [{ value: 'all', label: 'Tất cả vai trò' }, { value: 'guard', label: 'Bảo vệ' }, { value: 'supervisor', label: 'Giám sát' }, { value: 'tenant-admin', label: 'Quản trị' }] },
      { type: 'select', key: 'certification', label: 'Chứng chỉ', options: [{ value: 'all-certification', label: 'Tất cả' }, { value: 'valid', label: 'Còn hạn' }, { value: 'expired', label: 'Hết hạn' }] },
      { type: 'select', key: 'assignmentStatus', label: 'Phân công', options: [{ value: 'all-assignments', label: 'Tất cả' }, { value: 'assigned', label: 'Đã phân công' }, { value: 'unassigned', label: 'Chưa phân công' }] },
      contractFilter,
    ],
    persist: 'url+localStorage',
  },
  tasks: {
    tab: 'tasks',
    title: 'Bộ lọc nhiệm vụ',
    defaults: { status: 'open', priority: 'all-priority', assignee: '', dueDate: 'all-due', taskType: 'all-types', scope: 'all-scope', overdue: 'all-overdue' },
    primary: [
      { type: 'select', key: 'status', label: 'Trạng thái', options: [{ value: 'open', label: 'Việc mở' }, { value: 'PENDING', label: 'Chờ xử lý' }, { value: 'IN_PROGRESS', label: 'Đang làm' }, { value: 'COMPLETED', label: 'Hoàn tất' }] },
      { type: 'select', key: 'priority', label: 'Ưu tiên', options: [{ value: 'all-priority', label: 'Tất cả' }, { value: 'HIGH', label: 'Cao' }, { value: 'MEDIUM', label: 'Trung bình' }, { value: 'LOW', label: 'Thấp' }] },
      { type: 'search', key: 'assignee', label: 'Người phụ trách', placeholder: 'Tìm người phụ trách...' },
    ],
    advanced: [
      { type: 'select', key: 'dueDate', label: 'Hạn xử lý', options: [{ value: 'all-due', label: 'Tất cả' }, { value: 'today', label: 'Hôm nay' }, { value: 'week', label: 'Tuần này' }] },
      { type: 'select', key: 'taskType', label: 'Loại nhiệm vụ', options: [{ value: 'all-types', label: 'Tất cả loại' }, { value: 'incident', label: 'Sự cố' }, { value: 'patrol', label: 'Tuần tra' }, { value: 'audit', label: 'Audit' }] },
      { type: 'select', key: 'scope', label: 'Site/Nhà cung cấp', options: [{ value: 'all-scope', label: 'Tất cả phạm vi' }, ...siteOptions.slice(1), ...vendorOptions.slice(1)] },
      { type: 'select', key: 'overdue', label: 'Quá hạn', options: [{ value: 'all-overdue', label: 'Tất cả' }, { value: 'yes', label: 'Quá hạn' }, { value: 'no', label: 'Trong hạn' }] },
    ],
    persist: 'url+localStorage',
  },
  audit: {
    tab: 'audit',
    title: 'Bộ lọc kiểm tra đột xuất',
    defaults: { auditPeriod: 'recent', site: 'all-sites', status: 'all-status', auditor: '', scoreRange: 'all-score', findingSeverity: 'all-severity', vendor: 'all-vendors' },
    primary: [
      { type: 'select', key: 'auditPeriod', label: 'Kỳ audit', options: [{ value: 'recent', label: 'Audit gần đây' }, { value: 'today', label: 'Hôm nay' }, { value: 'month', label: 'Tháng này' }] },
      { type: 'select', key: 'site', label: 'Mục tiêu', options: siteOptions },
      { type: 'select', key: 'status', label: 'Trạng thái', options: statusOptions },
    ],
    advanced: [
      { type: 'search', key: 'auditor', label: 'Auditor', placeholder: 'Tìm người kiểm tra...' },
      { type: 'select', key: 'scoreRange', label: 'Điểm audit', options: [{ value: 'all-score', label: 'Tất cả' }, { value: 'below-80', label: 'Dưới 80' }, { value: 'above-90', label: 'Trên 90' }] },
      { type: 'select', key: 'findingSeverity', label: 'Mức finding', options: [{ value: 'all-severity', label: 'Tất cả' }, { value: 'HIGH', label: 'Cao' }, { value: 'MEDIUM', label: 'Trung bình' }] },
      { type: 'select', key: 'vendor', label: 'Nhà cung cấp', options: vendorOptions },
    ],
    persist: 'url+localStorage',
  },
  attachments: {
    tab: 'attachments',
    title: 'Bộ lọc bằng chứng',
    defaults: { search: '', category: 'all-categories', sourceType: 'all-sources', date: 'latest', uploader: '', linkedSource: 'all-linked', fileType: 'all-files' },
    primary: [
      { type: 'search', key: 'search', placeholder: 'Tìm tên tệp, tag, biên bản...' },
      { type: 'select', key: 'category', label: 'Danh mục', options: [{ value: 'all-categories', label: 'Tất cả danh mục' }, { value: 'INCIDENT', label: 'Sự cố' }, { value: 'EVIDENCE', label: 'Bằng chứng' }, { value: 'REPORT', label: 'Báo cáo' }] },
      { type: 'select', key: 'sourceType', label: 'Nguồn', options: [{ value: 'all-sources', label: 'Tất cả nguồn' }, { value: 'INCIDENT', label: 'Sự cố' }, { value: 'PATROL', label: 'Tuần tra' }, { value: 'ATTENDANCE', label: 'Ca trực' }] },
    ],
    advanced: [
      { type: 'select', key: 'date', label: 'Thời gian', options: [{ value: 'latest', label: 'Mới nhất trước' }, { value: 'today', label: 'Hôm nay' }, { value: 'month', label: 'Tháng này' }] },
      { type: 'search', key: 'uploader', label: 'Người tải lên', placeholder: 'Tìm người tải lên...' },
      { type: 'select', key: 'linkedSource', label: 'Liên kết', options: [{ value: 'all-linked', label: 'Tất cả' }, { value: 'incident', label: 'Sự cố' }, { value: 'patrol', label: 'Tuần tra' }, { value: 'report', label: 'Báo cáo' }] },
      { type: 'select', key: 'fileType', label: 'Loại tệp', options: [{ value: 'all-files', label: 'Tất cả' }, { value: 'image', label: 'Ảnh' }, { value: 'pdf', label: 'PDF' }, { value: 'video', label: 'Video' }] },
    ],
    persist: 'url+localStorage',
  },
  violations: {
    tab: 'violations',
    title: 'Bộ lọc vi phạm',
    defaults: { status: 'PENDING_REVIEW', severity: 'all-severity', sourceType: 'all-sources', vendor: 'all-vendors', site: 'all-sites', contractId: 'all-contracts', disputeStatus: 'all-disputes', penaltyStatus: 'all-penalties' },
    primary: [
      { type: 'select', key: 'status', label: 'Trạng thái', options: [{ value: 'PENDING_REVIEW', label: 'Chờ review' }, { value: 'CONFIRMED', label: 'Đã xác nhận' }, { value: 'DISPUTED', label: 'Đang dispute' }, { value: 'all-status', label: 'Tất cả' }] },
      { type: 'select', key: 'severity', label: 'Mức độ', options: [{ value: 'all-severity', label: 'Tất cả mức độ' }, { value: 'CRITICAL', label: 'Nghiêm trọng' }, { value: 'HIGH', label: 'Cao' }, { value: 'MEDIUM', label: 'Trung bình' }] },
      { type: 'select', key: 'sourceType', label: 'Nguồn', options: [{ value: 'all-sources', label: 'Tất cả nguồn' }, { value: 'SHIFT', label: 'Ca trực' }, { value: 'PATROL', label: 'Tuần tra' }, { value: 'INCIDENT', label: 'Sự cố' }] },
    ],
    advanced: [
      { type: 'select', key: 'vendor', label: 'Nhà cung cấp', options: vendorOptions },
      { type: 'select', key: 'site', label: 'Mục tiêu', options: siteOptions },
      contractFilter,
      { type: 'select', key: 'disputeStatus', label: 'Dispute', options: [{ value: 'all-disputes', label: 'Tất cả' }, { value: 'SUBMITTED', label: 'Đã gửi' }, { value: 'ACCEPTED', label: 'Được chấp nhận' }, { value: 'REJECTED', label: 'Bị từ chối' }] },
      { type: 'select', key: 'penaltyStatus', label: 'Phạt', options: [{ value: 'all-penalties', label: 'Tất cả' }, { value: 'suggested', label: 'Đề xuất phạt' }, { value: 'waived', label: 'Đã miễn' }] },
    ],
    persist: 'url+localStorage',
  },
  reports: {
    tab: 'reports',
    title: 'Bộ lọc báo cáo',
    defaults: { month: currentMonth, vendor: 'all-vendors', reportStatus: 'all-status', contractId: 'all-contracts', site: 'all-sites', exportStatus: 'all-export' },
    primary: [
      { type: 'select', key: 'month', label: 'Tháng', options: [{ value: currentMonth, label: 'Tháng hiện tại' }] },
      { type: 'select', key: 'vendor', label: 'Nhà cung cấp', options: vendorOptions },
      { type: 'select', key: 'reportStatus', label: 'Trạng thái', options: [{ value: 'all-status', label: 'Tất cả' }, { value: 'DRAFT', label: 'Nháp' }, { value: 'FINALIZED', label: 'Đã chốt' }, { value: 'VENDOR_DISPUTED', label: 'Nhà thầu phản hồi' }] },
    ],
    advanced: [
      contractFilter,
      { type: 'select', key: 'site', label: 'Mục tiêu', options: siteOptions },
      { type: 'select', key: 'exportStatus', label: 'Export', options: [{ value: 'all-export', label: 'Tất cả' }, { value: 'has-pdf', label: 'Đã có PDF' }, { value: 'has-excel', label: 'Đã có Excel' }, { value: 'missing-export', label: 'Chưa xuất' }] },
    ],
    persist: 'url+localStorage',
  },
};

export const getTabFilterConfig = (tab: ActiveTab) => TAB_FILTER_CONFIGS[tab] ?? null;
