import { useNavigate } from 'react-router-dom';
import { TenantLogin } from '../apps/tenants/interfaces/TenantLogin';
import { useAuth } from '../context/AuthContext';

export default function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleLoginSuccess = (userData: any) => {
    login({
      token: userData.token,
      role: userData.role,
      tenantId: userData.tenantId,
      name: userData.fullName || userData.name,
      staffId: userData.id
    });

    if (userData.role === 'super-admin') navigate('/super-admin/dashboard');
    else if (userData.role === 'tenant-admin') navigate('/admin/dashboard');
    else if (userData.role === 'guard') navigate('/guard/app');
    else navigate('/');
  };

  return (
    <TenantLogin 
      tenantName="Hệ thống SCMD Security"
      initialTenantCode={new URLSearchParams(window.location.search).get('tenant') || ''}
      onLogin={handleLoginSuccess}
    />
  );
}
