import { apiFetch } from "../lib/api";
import { LoginRequest, LoginResponse } from "../lib/contracts";

export const loginAPI = async (payload: LoginRequest): Promise<LoginResponse> => {
  const res = await fetch("/api/v1/auth/login", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(payload)
  });

  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || "Login failed");
  }

  return data as LoginResponse;
};

export const getMe = async () => {
    return await apiFetch('/api/me');
};

export const refreshTokenAPI = async (refreshToken: string): Promise<{ token: string; refreshToken: string }> => {
  const res = await fetch("/api/auth/refresh", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ refreshToken })
  });

  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || "Token refresh failed");
  }

  return data;
};
