import { useNavigate } from 'react-router-dom';
import { TenantLogin } from '../apps/tenants/interfaces/TenantLogin';
import { useAuth } from '../context/AuthContext';

export default function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleLoginSuccess = (userData: any) => {
    // FIX: Super-admin luôn thuộc 'tenant_system' (SYSTEM_TENANT_ID).
    // Nếu server không trả tenantId (null/undefined) — do DB seed hoặc RLS bypass path —
    // fallback về 'tenant_system' để store không removeItem('scmd_tenant_id'),
    // đảm bảo refreshSession và apiFetch hoạt động đúng với x-tenant-id header.
    const resolvedTenantId = userData.tenantId || (userData.role === 'super-admin' ? 'tenant_system' : undefined);
    login({
      token: userData.token,
      role: userData.role,
      tenantId: resolvedTenantId,
      name: userData.fullName || userData.name,
      staffId: userData.id
    });

    if (userData.role === 'super-admin') navigate('/super-admin/dashboard');
    else if (userData.role === 'tenant-admin') navigate('/admin/dashboard');
    else if (userData.role === 'guard') navigate('/guard/app');
    else navigate('/');
  };

  return (
    <TenantLogin 
      tenantName="Hệ thống SCMD Security"
      initialTenantCode={new URLSearchParams(window.location.search).get('tenant') || ''}
      onLogin={handleLoginSuccess}
    />
  );
}
