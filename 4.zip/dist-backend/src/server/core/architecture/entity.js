export class BaseEntity {
    _id;
    _tenantId;
    _props;
    _createdAt;
    _updatedAt;
    constructor(props, id, tenantId, createdAt, updatedAt) {
        this._id = id;
        this._tenantId = tenantId;
        this._props = props;
        this._createdAt = createdAt || new Date();
        this._updatedAt = updatedAt || new Date();
    }
    get id() { return this._id; }
    get tenantId() { return this._tenantId; }
    get createdAt() { return this._createdAt; }
    get updatedAt() { return this._updatedAt; }
    toJSON() {
        return {
            id: this._id,
            tenantId: this._tenantId,
            ...this._props,
            createdAt: this._createdAt.toISOString(),
            updatedAt: this._updatedAt.toISOString(),
        };
    }
}
