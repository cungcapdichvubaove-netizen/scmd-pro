export class BaseUseCase {
    /**
     * Main entry point for use cases with mandatory security context.
     */
    async execute(context, request) {
        // 1. Authorize (Permission Bypass Check)
        await this.authorize(context, request);
        // 2. Validate Input
        await this.validate(request, context);
        // 3. Execute Core Logic
        return await this.internalExecute(context, request);
    }
    async validate(_request, _context) {
        // Default implementation (can be overridden with Zod etc.)
    }
}
