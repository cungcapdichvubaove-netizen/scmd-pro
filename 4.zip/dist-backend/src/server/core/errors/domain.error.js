export class DomainError extends Error {
    isDomainError = true;
    constructor(message) {
        super(message);
        Object.setPrototypeOf(this, new.target.prototype);
        Error.captureStackTrace(this, this.constructor);
    }
}
export class NotFoundError extends DomainError {
    status = 404;
    constructor(message = 'Resource not found') {
        super(message);
        this.name = 'NotFoundError';
    }
}
export class ForbiddenError extends DomainError {
    status = 403;
    constructor(message = 'Access denied') {
        super(message);
        this.name = 'ForbiddenError';
    }
}
export class BadRequestError extends DomainError {
    status = 400;
    constructor(message = 'Bad request') {
        super(message);
        this.name = 'BadRequestError';
    }
}
export class UnauthorizedError extends DomainError {
    status = 401;
    constructor(message = 'Unauthorized') {
        super(message);
        this.name = 'UnauthorizedError';
    }
}
export class ConflictError extends DomainError {
    status = 409;
    constructor(message = 'Conflict occurred') {
        super(message);
        this.name = 'ConflictError';
    }
}
