import { BaseUseCase } from '../../architecture/usecase.js';
import { UserRole } from '../../architecture/types.js';
import { PatrolRepository } from '../../../modules/patrol/repositories/patrol.repository.js';
import { AuditService } from '../../audit/audit.service.js';
import { logger } from '../../logger/index.js';
import { AttendanceCheckOutUseCase } from '../attendance/check-out.usecase.js';
export class CompletePatrolUseCase extends BaseUseCase {
    async authorize(context) {
        const allowedRoles = [UserRole.GUARD, UserRole.SUPERVISOR, UserRole.TENANT_ADMIN, UserRole.SUPER_ADMIN];
        if (!allowedRoles.includes(context.role)) {
            throw new Error('UNAUTHORIZED_ACTION');
        }
    }
    async internalExecute(context, data) {
        try {
            // 1. Verify location if coords provided
            let isLocationValid = true;
            if (data.location) {
                isLocationValid = await PatrolRepository.verifyGuardLocation(context.tenantId, data.checkpointId, data.location.lat, data.location.lon);
                if (!isLocationValid) {
                    logger.warn({ context, checkpointId: data.checkpointId }, 'FRAUD_DETECTED: Guard completed patrol while too far from checkpoint');
                }
            }
            // 2. Save log to PG
            const log = await PatrolRepository.createLog(context, data.checkpointId, {
                startTime: data.startTime,
                endTime: data.endTime,
                checkItems: data.checkItemsData,
                anomaly: data.anomaly ?? (!isLocationValid ? 'LOCATION_MISMATCH_FRAUD' : null),
                status: !isLocationValid ? 'danger' : 'ok',
                location: data.location,
                deviceId: data.deviceId,
                offlineSignature: data._signature,
                offlineTimestamp: data._timestamp,
                syncTime: new Date().toISOString()
            });
            const logId = log.id;
            // 3. If isShiftEnd is requested, trigger automatic Check-out
            if (data.isShiftEnd) {
                const checkOutUseCase = new AttendanceCheckOutUseCase();
                try {
                    await checkOutUseCase.execute(context, {
                        location: data.location,
                        notes: `Tự động đóng ca sau khi hoàn thành tuần tra tại trạm ${data.checkpointId}`
                    });
                    logger.info({ staffId: context.userId }, 'Shift auto-closed via Patrol Report');
                }
                catch (err) {
                    // If already checked out or other error, log it but don't fail the patrol completion
                    logger.warn({ staffId: context.userId, err }, 'Failed to auto-close shift during patrol completion');
                }
            }
            await AuditService.log({
                userId: context.userId,
                tenantId: context.tenantId,
                action: 'PATROL_COMPLETE',
                resource: `patrol/checkpoint/${data.checkpointId}`,
                payload: {
                    logId,
                    checkpointId: data.checkpointId,
                    locationValid: isLocationValid,
                    hasAnomaly: !!data.anomaly || !isLocationValid
                },
                status: isLocationValid ? 'SUCCESS' : 'WARNING'
            });
            return { success: true, logId };
        }
        catch (err) {
            const error = err instanceof Error ? err : new Error(String(err));
            logger.error({ err: error, staffId: context.userId }, 'Complete patrol failed');
            throw error;
        }
    }
}
