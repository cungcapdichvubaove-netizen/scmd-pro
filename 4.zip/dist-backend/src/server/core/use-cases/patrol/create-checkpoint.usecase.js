import { BaseUseCase } from '../../architecture/usecase.js';
import { UserRole } from '../../architecture/types.js';
import { PatrolRepository } from '../../../modules/patrol/repositories/patrol.repository.js';
import { AuditService } from '../../audit/audit.service.js';
export class CreateCheckpointUseCase extends BaseUseCase {
    async authorize(context) {
        if (context.role !== UserRole.TENANT_ADMIN && context.role !== UserRole.SUPER_ADMIN) {
            throw new Error('UNAUTHORIZED_ACTION');
        }
    }
    async internalExecute(context, request) {
        const checkpoint = await PatrolRepository.createCheckpoint(context.tenantId, request);
        await AuditService.log({
            userId: context.userId,
            tenantId: context.tenantId,
            action: 'CREATE_CHECKPOINT',
            resource: `checkpoint/${checkpoint.id}`,
            status: 'SUCCESS',
            payload: { name: checkpoint.name }
        });
        return checkpoint;
    }
}
