import { BaseUseCase } from '../../architecture/usecase.js';
import { PatrolRepository } from '../../../modules/patrol/repositories/patrol.repository.js';
export class GetCheckpointsUseCase extends BaseUseCase {
    async authorize(context) {
        if (!context.tenantId)
            throw new Error('UNAUTHORIZED: tenantId missing');
    }
    async internalExecute(context, params) {
        if (params?.limit === 'all') {
            return await PatrolRepository.getAllCheckpointsByTenant(context.tenantId);
        }
        const limit = (typeof params?.limit === 'number') ? params.limit : 50;
        return await PatrolRepository.getCheckpointsByTenant(context.tenantId, params?.cursor, limit);
    }
}
