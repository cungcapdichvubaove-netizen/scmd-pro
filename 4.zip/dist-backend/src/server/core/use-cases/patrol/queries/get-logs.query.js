import { BaseUseCase } from '../../../architecture/usecase.js';
import { PatrolRepository } from '../../../../modules/patrol/repositories/patrol.repository.js';
export class GetLogsQuery extends BaseUseCase {
    async authorize(context) {
        // Basic auth check, tenant isolation handled in repository via withTenant
        if (!context.userId)
            throw new Error('UNAUTHORIZED');
    }
    async internalExecute(context, params) {
        const limit = params?.limit || 50;
        return await PatrolRepository.getLogsByTenant(context, params?.cursor, limit, params?.view);
    }
}
