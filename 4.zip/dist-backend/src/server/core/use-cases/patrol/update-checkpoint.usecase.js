import { BaseUseCase } from '../../architecture/usecase.js';
import { UserRole } from '../../architecture/types.js';
import { PatrolRepository } from '../../../modules/patrol/repositories/patrol.repository.js';
import { AuditService } from '../../audit/audit.service.js';
export class UpdateCheckpointUseCase extends BaseUseCase {
    async authorize(context) {
        if (context.role !== UserRole.TENANT_ADMIN && context.role !== UserRole.SUPER_ADMIN) {
            throw new Error('UNAUTHORIZED_ACTION');
        }
    }
    async internalExecute(context, request) {
        const { id, data } = request;
        const existing = await PatrolRepository.getCheckpointById(context.tenantId, id);
        if (!existing)
            throw new Error('Checkpoint not found');
        if (existing.tenantId !== context.tenantId)
            throw new Error('Cross-tenant access denied');
        const updated = await PatrolRepository.updateCheckpoint(context.tenantId, id, data);
        await AuditService.logSensitiveChange(context.userId, context.tenantId, 'UPDATE_CHECKPOINT', `checkpoint/${id}`, existing, updated);
        return updated;
    }
}
