import { BaseUseCase } from '../../architecture/usecase.js';
import { db } from '../../db/prisma.js';
import { AuditService } from '../../audit/audit.service.js';
export class DeleteTaskUseCase extends BaseUseCase {
    async authorize(context) {
        if (!context.tenantId)
            throw new Error('UNAUTHORIZED');
    }
    async internalExecute(context, id) {
        const { tenantId, userId } = context;
        const existingTask = await db.forTenant(tenantId).task.findFirst({
            where: { id, tenantId }
        });
        if (!existingTask) {
            throw new Error('Task not found');
        }
        await db.forTenant(tenantId).task.delete({
            where: { id, tenantId }
        });
        await AuditService.logSensitiveChange(userId, tenantId, 'TASK_DELETED', `task/${id}`, { title: existingTask.title, status: existingTask.status, assigneeId: existingTask.assigneeId }, null);
    }
}
