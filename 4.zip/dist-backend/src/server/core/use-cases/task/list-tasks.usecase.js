import { BaseUseCase } from '../../architecture/usecase.js';
import { UserRole } from '../../architecture/types.js';
import { db } from '../../db/prisma.js';
export class ListTasksUseCase extends BaseUseCase {
    async authorize(context) {
        if (!context.tenantId)
            throw new Error('UNAUTHORIZED');
    }
    async internalExecute(context, request) {
        const { tenantId, userId: staffId, role } = context;
        const { status, assigneeId, view } = request;
        const query = { tenantId };
        if (status)
            query.status = status;
        if (assigneeId)
            query.assigneeId = assigneeId;
        // Guard chỉ thấy task được giao cho mình
        if (role === UserRole.GUARD && !assigneeId) {
            query.assigneeId = staffId;
        }
        const isMobile = view === 'mobile';
        return await db.withTenant(tenantId, async (tx) => {
            return tx.task.findMany({
                where: query,
                orderBy: { createdAt: 'desc' },
                select: isMobile ? {
                    id: true,
                    title: true,
                    status: true,
                    priority: true,
                    dueDate: true,
                    assigneeId: true
                } : undefined
            });
        }, { readOnly: true });
    }
}
