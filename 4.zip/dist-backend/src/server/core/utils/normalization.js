export function canonicalStringify(obj) {
    if (obj === null || typeof obj !== 'object') {
        return JSON.stringify(obj);
    }
    if (Array.isArray(obj)) {
        return '[' + obj.map(item => canonicalStringify(item)).join(',') + ']';
    }
    const sortedKeys = Object.keys(obj).sort();
    const result = sortedKeys.map(key => {
        const value = obj[key];
        return `"${key}":${canonicalStringify(value)}`;
    });
    return '{' + result.join(',') + '}';
}
