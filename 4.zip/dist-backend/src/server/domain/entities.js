export var CheckItemType;
(function (CheckItemType) {
    CheckItemType["TOGGLE"] = "toggle";
    CheckItemType["PHOTO"] = "photo";
    CheckItemType["TEXT"] = "text";
})(CheckItemType || (CheckItemType = {}));
export var CheckpointStatus;
(function (CheckpointStatus) {
    CheckpointStatus["PENDING"] = "pending";
    CheckpointStatus["COMPLETED"] = "completed";
    CheckpointStatus["MISSED"] = "missed";
})(CheckpointStatus || (CheckpointStatus = {}));
export var IncidentSeverity;
(function (IncidentSeverity) {
    IncidentSeverity["LOW"] = "low";
    IncidentSeverity["MEDIUM"] = "medium";
    IncidentSeverity["HIGH"] = "high";
})(IncidentSeverity || (IncidentSeverity = {}));
// Note: These values must EXACTLY match the DB string values (CHECK_IN, CHECK_OUT).
export var AttendanceType;
(function (AttendanceType) {
    AttendanceType["CHECK_IN"] = "CHECK_IN";
    AttendanceType["CHECK_OUT"] = "CHECK_OUT";
    AttendanceType["LIVENESS"] = "LIVENESS";
})(AttendanceType || (AttendanceType = {}));
export var AttendanceStatus;
(function (AttendanceStatus) {
    AttendanceStatus["VALID"] = "valid";
    AttendanceStatus["INVALID"] = "invalid";
})(AttendanceStatus || (AttendanceStatus = {}));
export var TenantPlanType;
(function (TenantPlanType) {
    TenantPlanType["FREE"] = "free";
    TenantPlanType["PRO"] = "pro";
    TenantPlanType["ENTERPRISE"] = "enterprise";
})(TenantPlanType || (TenantPlanType = {}));
export var UsageEventType;
(function (UsageEventType) {
    UsageEventType["REGISTRATION"] = "registration";
    UsageEventType["FIRST_STAFF"] = "first_staff";
    UsageEventType["FIRST_CHECKPOINT"] = "first_checkpoint";
    UsageEventType["FIRST_PATROL"] = "first_patrol";
})(UsageEventType || (UsageEventType = {}));
export var VendorStatus;
(function (VendorStatus) {
    VendorStatus["ACTIVE"] = "active";
    VendorStatus["SUSPENDED"] = "suspended";
})(VendorStatus || (VendorStatus = {}));
export var ContractStatus;
(function (ContractStatus) {
    ContractStatus["ACTIVE"] = "active";
    ContractStatus["EXPIRED"] = "expired";
    ContractStatus["TERMINATED"] = "terminated";
})(ContractStatus || (ContractStatus = {}));
