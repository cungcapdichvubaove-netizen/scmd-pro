import { addMonths } from 'date-fns';
import { GRACE_PERIOD_DAYS } from '../../../shared/constants/billing.constants.js';
export class SubscriptionEntity {
    props;
    constructor(props) {
        this.props = props;
    }
    /** Còn hạn thực sự (chưa tính grace period) */
    get isActive() {
        if (this.props.plan === 'FREE')
            return false;
        if (!this.props.expiresAt)
            return false;
        return this.props.expiresAt > new Date();
    }
    /** Trong grace period (hết hạn nhưng chưa quá X ngày) */
    get isInGracePeriod() {
        if (!this.props.expiresAt || this.isActive)
            return false;
        const graceEnd = new Date(this.props.expiresAt);
        graceEnd.setDate(graceEnd.getDate() + (this.props.gracePeriodDays ?? GRACE_PERIOD_DAYS));
        return graceEnd > new Date();
    }
    /** Plan hiệu lực thực tế (tính cả grace period) */
    get effectivePlan() {
        if (this.isActive || this.isInGracePeriod)
            return this.props.plan;
        return 'FREE';
    }
    get daysRemaining() {
        if (!this.props.expiresAt)
            return null;
        const diff = this.props.expiresAt.getTime() - Date.now();
        return Math.max(0, Math.ceil(diff / (1000 * 60 * 60 * 24)));
    }
    get isExpiringSoon() {
        const days = this.daysRemaining;
        return days !== null && days <= 7;
    }
    get isOverUserLimit() {
        return this.props.activeUsers > this.props.paidUsers;
    }
    /**
     * Tính expiresAt mới khi gia hạn (date-fns để tránh edge case tháng).
     * - Còn hạn → cộng dồn từ expiresAt hiện tại
     * - Hết hạn hoặc FREE → tính từ activatedAt
     */
    calculateNewExpiry(months, activatedAt) {
        const base = this.isActive && this.props.expiresAt
            ? this.props.expiresAt
            : activatedAt;
        return addMonths(base, months); // date-fns xử lý end-of-month đúng
    }
}
