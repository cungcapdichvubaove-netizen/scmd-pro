import { BaseUseCase } from '../../../core/architecture/usecase.js';
import { GeminiService } from '../../../core/ai/gemini.service.js';
export class AnalyzeIncidentImageUseCase extends BaseUseCase {
    async authorize(context) {
        if (!context.tenantId)
            throw new Error('UNAUTHORIZED');
    }
    async validate(request) {
        if (!request.image)
            throw new Error('BAD_REQUEST: Cần cung cấp hình ảnh để phân tích');
    }
    async internalExecute(_ctx, input) {
        const analysis = await GeminiService.analyzeIncidentImage(input.image, input.description || '');
        return {
            severity: analysis.isHighSeverity ? 'Cao' : (analysis.confidence > 0.8 ? 'Trung bình' : 'Thấp'),
            classification: analysis.classification,
            advice: analysis.reason,
            confidence: analysis.confidence
        };
    }
}
