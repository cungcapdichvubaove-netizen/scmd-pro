import { IncidentRepository } from '../incident.repository.js';
import { IncidentStatus } from '@prisma/client';
export class ListIncidentsUseCase {
    repository;
    constructor() {
        this.repository = new IncidentRepository();
    }
    async execute(ctx, input) {
        const { status, type, limit = 50, cursor, view, sortBy, sortOrder = 'desc' } = input;
        const isMobile = view === 'mobile';
        // Normalize status string to Prisma Enum
        let statusEnum;
        if (status) {
            const normalized = status.toUpperCase();
            if (Object.values(IncidentStatus).includes(normalized)) {
                statusEnum = normalized;
            }
        }
        const { items, hasMore, limit: actualLimit } = await this.repository.list(ctx.tenantId, {
            status: statusEnum,
            type,
            limit,
            cursor,
            sortBy,
            sortOrder,
            isMobile
        });
        return {
            items,
            hasMore,
            limit: actualLimit,
            nextCursor: hasMore ? (items.length > 0 ? items[items.length - 1].id : null) : null
        };
    }
}
