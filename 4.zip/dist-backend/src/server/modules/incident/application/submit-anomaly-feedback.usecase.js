import { db as pgDb } from '../../../core/db/prisma.js';
export class SubmitAnomalyFeedbackUseCase {
    async execute(ctx, input) {
        const { alertId, verdict, notes } = input;
        const feedback = await pgDb.forTenant(ctx.tenantId).feedback.create({
            data: {
                tenantId: ctx.tenantId,
                userId: ctx.userId,
                title: `Anomaly Feedback: ${alertId}`,
                description: `${verdict} - ${notes || ''}`,
                type: 'AI_FEEDBACK',
                status: 'CLOSED',
                severity: verdict === 'TRUE_POSITIVE' ? 'HIGH' : 'LOW'
            }
        });
        return feedback;
    }
}
