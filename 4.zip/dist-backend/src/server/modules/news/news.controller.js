import { NewsRepository } from './news.repository.js';
import { logger } from '../../core/logger/index.js';
export class NewsController {
    static async getAll(_req, res, next) {
        try {
            const news = await NewsRepository.getAll();
            return res.json(news);
        }
        catch (err) {
            logger.error({ err }, 'Error fetching all news');
            return next(err);
        }
    }
    static async getBySlug(req, res, next) {
        try {
            const { slug } = req.params;
            const news = await NewsRepository.getBySlug(slug);
            if (!news) {
                return res.status(404).json({ error: 'News not found' });
            }
            return res.json(news);
        }
        catch (err) {
            logger.error({ err }, 'Error fetching news by slug');
            return next(err);
        }
    }
}
