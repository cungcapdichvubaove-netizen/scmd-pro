import { NotificationRepository } from './notification.repository.js';
import { logger } from '../../core/logger/index.js';
import { z } from 'zod';
export class NotificationController {
    /**
     * GET /api/notifications
     */
    static async list(req, res, next) {
        try {
            const tenantId = req.user.tenantId;
            const notifications = await NotificationRepository.findByTenant(tenantId);
            return res.json(notifications);
        }
        catch (err) {
            logger.error({ err }, 'Failed to list notifications');
            return next(err);
        }
    }
    /**
     * PATCH /api/notifications/:id/read
     */
    static async markAsRead(req, res, next) {
        try {
            const { id } = z.object({ id: z.string().min(1) }).parse(req.params);
            const tenantId = req.user.tenantId;
            await NotificationRepository.markAsRead(id, tenantId);
            return res.json({ success: true });
        }
        catch (err) {
            logger.error({ err }, 'Failed to mark notification as read');
            return next(err);
        }
    }
    /**
     * POST /api/notifications/mark-all-read
     */
    static async markAllAsRead(req, res, next) {
        try {
            const tenantId = req.user.tenantId;
            const userId = req.user.id;
            await NotificationRepository.markAllAsRead(tenantId, userId);
            return res.json({ success: true });
        }
        catch (err) {
            logger.error({ err }, 'Failed to mark all notifications as read');
            return next(err);
        }
    }
}
