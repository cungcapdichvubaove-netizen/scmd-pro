import { BaseUseCase } from '../../../core/architecture/usecase.js';
import { UserRole } from '../../../core/architecture/types.js';
import { StaffRepository } from '../staff.repository.js';
import { createStaffSchema } from '../staff.schema.js';
import { AuditService } from '../../../core/audit/audit.service.js';
export class CreateStaffUseCase extends BaseUseCase {
    async authorize(context) {
        if (context.role !== UserRole.TENANT_ADMIN && context.role !== UserRole.SUPER_ADMIN) {
            throw new Error('FORBIDDEN_ACTION');
        }
    }
    async validate(request, context) {
        createStaffSchema.parse(request);
        // Automated Integrity Check: Quota Guard
        const { IntegrityGuard } = await import('../../../core/db/integrity.manager.js');
        await IntegrityGuard.checkStaffQuota(context.tenantId);
    }
    async internalExecute(context, request) {
        const staff = await StaffRepository.create(context, request);
        await AuditService.log({
            userId: context.userId,
            tenantId: context.tenantId,
            action: 'CREATE_STAFF',
            resource: `staff/${staff.id}`,
            payload: { username: request.username, role: request.role },
            status: 'SUCCESS'
        });
        return staff;
    }
}
