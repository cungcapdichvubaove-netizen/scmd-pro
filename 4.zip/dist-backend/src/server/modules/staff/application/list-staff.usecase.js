import { BaseUseCase } from '../../../core/architecture/usecase.js';
import { UserRole } from '../../../core/architecture/types.js';
import { StaffRepository } from '../staff.repository.js';
export class ListStaffUseCase extends BaseUseCase {
    async authorize(context) {
        // Permission: staff:read (mapped in permissions.ts, normally handled by middleware)
        // But for defense-in-depth, we check role here too
        const allowedRoles = [UserRole.TENANT_ADMIN, UserRole.SUPERVISOR, UserRole.SUPER_ADMIN];
        if (!allowedRoles.includes(context.role)) {
            throw new Error('FORBIDDEN_ACCESS');
        }
    }
    async internalExecute(context, params) {
        const limit = params?.limit || 20;
        return await StaffRepository.getAllByTenant(context, params?.cursor, limit, {
            role: params?.role,
            status: params?.status,
            search: params?.search,
            view: params?.view
        });
    }
}
