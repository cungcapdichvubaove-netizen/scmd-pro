import { BaseUseCase } from '../../../core/architecture/usecase.js';
import { UserRole } from '../../../core/architecture/types.js';
import { StaffRepository } from '../staff.repository.js';
import { updateStaffSchema } from '../staff.schema.js';
import { AuditService } from '../../../core/audit/audit.service.js';
import { logger } from '../../../core/logger/index.js';
import { CacheManager } from '../../../core/cache/manager.js';
export class UpdateStaffUseCase extends BaseUseCase {
    async authorize(context, request) {
        if (context.role === UserRole.GUARD && context.userId !== request.id) {
            throw new Error('FORBIDDEN_ACTION');
        }
    }
    async validate(request) {
        updateStaffSchema.parse(request.data);
    }
    async internalExecute(context, request) {
        const { id, data } = request;
        const staff = await StaffRepository.getEntityById(context, id);
        if (!staff) {
            const error = new Error('NOT_FOUND_OR_ACCESS_DENIED');
            error.status = 404;
            throw error;
        }
        const isAdmin = context.role === UserRole.TENANT_ADMIN || context.role === UserRole.SUPER_ADMIN;
        const currentStaff = staff.toJSON();
        if (!isAdmin) {
            data.role = currentStaff.role;
            data.status = currentStaff.status;
        }
        else {
            if (data.role === UserRole.SUPER_ADMIN && context.role !== UserRole.SUPER_ADMIN) {
                logger.warn({ actorId: context.userId, targetId: id }, 'SECURITY VIOLATION: TenantAdmin attempted to promote a user to SuperAdmin. Blocked.');
                data.role = currentStaff.role;
            }
            if (currentStaff.role === UserRole.SUPER_ADMIN && context.role !== UserRole.SUPER_ADMIN && data.role && data.role !== UserRole.SUPER_ADMIN) {
                logger.warn({ actorId: context.userId, targetId: id }, 'SECURITY VIOLATION: TenantAdmin attempted to demote a SuperAdmin. Blocked.');
                data.role = currentStaff.role;
            }
        }
        if (data.fullName || data.phone !== undefined) {
            staff.updateProfile(data.fullName ?? currentStaff.fullName, data.role ?? currentStaff.role, data.phone);
        }
        if (data.status === 'inactive')
            staff.deactivate();
        else if (data.status === 'active')
            staff.activate();
        if (data.qualifications)
            staff.updateQualifications(data.qualifications);
        await StaffRepository.save(context, staff);
        // SEC-FIX [M-01]: Invalidate auth metadata cache immediately on change
        // Using CacheManager.del to ensure both L1 and L2 (Redis) caches are invalidated.
        await CacheManager.del(`auth_metadata:${id}`);
        const updated = staff.toJSON();
        await AuditService.logSensitiveChange(context.userId, context.tenantId, 'UPDATE_STAFF', `staff/${id}`, currentStaff, updated);
        return updated;
    }
}
