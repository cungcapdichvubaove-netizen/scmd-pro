import { BaseEntity } from '../../../core/architecture/entity.js';
export class StaffEntity extends BaseEntity {
    static create(id, tenantId, props, createdAt, updatedAt) {
        return new StaffEntity(props, id, tenantId, createdAt, updatedAt);
    }
    get username() { return this._props.username; }
    get email() { return this._props.email; }
    get fullName() { return this._props.fullName; }
    get phone() { return this._props.phone; }
    get role() { return this._props.role; }
    get status() { return this._props.status; }
    get password() { return this._props.password; }
    get qualifications() { return this._props.qualifications || []; }
    get idNumber() { return this._props.idNumber; }
    get licenseNumber() { return this._props.licenseNumber; }
    get idExpiry() { return this._props.idExpiry; }
    deactivate() {
        if (this._props.status === 'inactive') {
            throw new Error('Staff is already inactive');
        }
        this._props.status = 'inactive';
        this._updatedAt = new Date();
    }
    activate() {
        if (this._props.status === 'active') {
            throw new Error('Staff is already active');
        }
        this._props.status = 'active';
        this._updatedAt = new Date();
    }
    updateProfile(fullName, role, phone, idNumber, licenseNumber, idExpiry) {
        if (!fullName || fullName.trim() === '') {
            throw new Error('Full name cannot be empty');
        }
        this._props.fullName = fullName;
        if (role) {
            this._props.role = role;
        }
        if (phone !== undefined) {
            this._props.phone = phone;
        }
        if (idNumber !== undefined) {
            this._props.idNumber = idNumber;
        }
        if (licenseNumber !== undefined) {
            this._props.licenseNumber = licenseNumber;
        }
        if (idExpiry !== undefined) {
            this._props.idExpiry = idExpiry;
        }
        this._updatedAt = new Date();
    }
    updateQualifications(qualifications) {
        this._props.qualifications = qualifications;
        this._updatedAt = new Date();
    }
    validateStateTransition(nextState) {
        const validStates = ['active', 'inactive'];
        if (!validStates.includes(nextState)) {
            throw new Error(`Invalid state transition: ${nextState}`);
        }
    }
    getProps() {
        return this._props;
    }
    // FIX 5.1: Chống rò rỉ Password hash qua các truy vấn GET / PUT
    // Ghi đè phương thức toJSON() của lớp BaseEntity để loại bỏ password
    toJSON() {
        const { password, ...safeProps } = this._props;
        return {
            id: this._id,
            tenantId: this._tenantId,
            ...safeProps,
            createdAt: this._createdAt.toISOString(),
            updatedAt: this._updatedAt.toISOString()
        };
    }
}
