import { db } from '../../core/db/prisma.js';
import bcrypt from 'bcryptjs';
import { logger } from '../../core/logger/index.js';
import { CacheManager } from '../../core/cache/manager.js';
import { createStaffSchema } from './staff.schema.js';
import { EventBus } from '../../core/events/event-bus.js';
import { AuditService } from '../../core/audit/audit.service.js';
import { UserRole } from '../../core/architecture/types.js';
import { StaffEntity } from './domain/staff.entity.js';
import { canonicalStringify } from '../../core/utils/normalization.js';
export class StaffRepository {
    static PROFILE_TTL = 3600; // 1 hour
    static LIST_TTL = 300; // 5 minutes
    static getCacheKey(id) {
        return `staff:profile:${id}`;
    }
    static getListCacheKey(tenantId, pageKey) {
        return `staff:list:${tenantId}:${pageKey}`;
    }
    static normalizeFilters(f) {
        return canonicalStringify(f || {});
    }
    /**
     * Retrieves all staff for a tenant.
     * If role is GUARD, this will effectively return ONLY themselves thanks to withTenant proxy.
     */
    static async getAllByTenant(ctx, cursor, limit = 20, filters) {
        const isGuard = ctx.role === UserRole.GUARD;
        const filterKey = this.normalizeFilters(filters);
        const pageKey = (cursor || 'first') + ':' + filterKey;
        const cacheKey = this.getListCacheKey(ctx.tenantId, pageKey);
        return await CacheManager.wrap(cacheKey, async () => {
            const where = {};
            if (filters?.role && filters.role !== 'all') {
                where.role = filters.role;
            }
            if (filters?.status && filters.status !== 'all') {
                where.status = filters.status;
            }
            if (filters?.search) {
                const s = filters.search.trim();
                const searchConditions = [
                    { fullName: { contains: s, mode: 'insensitive' } },
                    { username: { contains: s, mode: 'insensitive' } },
                    { email: { contains: s, mode: 'insensitive' } },
                    { phone: { contains: s } } // Phone is numeric, doesn't need insensitive
                ];
                // If search looks like an exact ID fit
                if (s.length >= 8) {
                    searchConditions.push({ id: { equals: s } });
                }
                where.OR = searchConditions;
            }
            const isMobileView = filters?.view === 'mobile';
            const data = await db.forTenant(ctx.tenantId, { ownerId: isGuard ? ctx.userId : undefined, readOnly: true }).staff.findMany({
                where,
                take: Math.min(limit, 200),
                ...(cursor ? { cursor: { id: cursor }, skip: 1 } : {}),
                orderBy: [{ id: 'asc' }], // Cursor pagination needs stable ordering, usually ID
                select: {
                    id: true,
                    fullName: true,
                    role: true,
                    status: true,
                    // Only fetch extra fields if NOT mobile view
                    ...(isMobileView ? {} : {
                        username: true,
                        email: true,
                        phone: true,
                        qualifications: true,
                        idNumber: true,
                        licenseNumber: true,
                        idExpiry: true,
                        createdAt: true,
                    })
                }
            });
            return {
                data,
                nextCursor: data.length === Math.min(limit, 200) ? data[data.length - 1].id : null
            };
        }, this.LIST_TTL);
    }
    /**
     * Revokes all active sessions for a staff member by incrementing their token version.
     */
    static async revokeSessions(ctx, id) {
        const { redis } = await import('../../infra/redis/client.js');
        await db.withTenant(ctx.tenantId, async (tx) => {
            const staff = await tx.staff.update({
                where: { id },
                data: {
                    tokenVersion: { increment: 1 },
                    updatedAt: new Date()
                }
            });
            // Update Redis cache immediately for instant revocation and profile invalidation
            await CacheManager.del(`auth_metadata:${id}`);
            await redis.set(`user_token_version:${id}`, staff.tokenVersion.toString(), 'EX', 3600);
            await CacheManager.del(this.getCacheKey(id));
            await CacheManager.delByPattern(`staff:list:${ctx.tenantId}:*`);
            logger.info({ userId: ctx.userId, targetId: id, version: staff.tokenVersion }, 'Sessions revoked for staff member');
        }, { callerRole: ctx.role });
    }
    static async getById(ctx, id) {
        const cacheKey = this.getCacheKey(id);
        return await CacheManager.wrap(cacheKey, async () => {
            const isGuard = ctx.role === UserRole.GUARD;
            return await db.forTenant(ctx.tenantId, { ownerId: isGuard ? ctx.userId : undefined, readOnly: true }).staff.findUnique({
                where: { id },
                select: {
                    id: true,
                    tenantId: true,
                    username: true,
                    email: true,
                    fullName: true,
                    role: true,
                    status: true,
                    phone: true,
                    tokenVersion: true,
                    qualifications: true,
                    idNumber: true,
                    licenseNumber: true,
                    idExpiry: true,
                    createdAt: true,
                    updatedAt: true,
                }
            });
        }, this.PROFILE_TTL);
    }
    /**
     * Internal method for auth-related lookups that NEED the password hash.
     */
    static async getByIdWithPassword(ctx, id) {
        const isGuard = ctx.role === UserRole.GUARD;
        return await db.forTenant(ctx.tenantId, { ownerId: isGuard ? ctx.userId : undefined, readOnly: true }).staff.findUnique({
            where: { id }
        });
    }
    static async getEntityById(ctx, id) {
        const raw = await this.getByIdWithPassword(ctx, id);
        if (!raw)
            return null;
        return StaffEntity.create(raw.id, raw.tenantId, {
            username: raw.username,
            email: raw.email,
            fullName: raw.fullName,
            phone: raw.phone,
            role: raw.role,
            status: raw.status,
            password: raw.password,
            qualifications: raw.qualifications,
            idNumber: raw.idNumber,
            licenseNumber: raw.licenseNumber,
            idExpiry: raw.idExpiry ? new Date(raw.idExpiry) : null,
        }, raw.createdAt, raw.updatedAt);
    }
    static async save(ctx, entity) {
        const isGuard = ctx.role === UserRole.GUARD;
        return await db.withTenant(ctx.tenantId, async (tx) => {
            const before = await tx.staff.findUnique({ where: { id: entity.id } });
            if (!before) {
                const error = new Error('NOT_FOUND_OR_ACCESS_DENIED');
                error.status = 404;
                throw error;
            }
            const props = entity.getProps();
            const updated = await tx.staff.update({
                where: { id: entity.id },
                data: {
                    email: props.email,
                    fullName: props.fullName,
                    phone: props.phone,
                    role: props.role,
                    status: props.status,
                    qualifications: props.qualifications,
                    idNumber: props.idNumber,
                    licenseNumber: props.licenseNumber,
                    idExpiry: props.idExpiry,
                    updatedAt: new Date()
                }
            });
            // Invalidate Cache for consistency
            await Promise.all([
                CacheManager.del(this.getCacheKey(entity.id)),
                CacheManager.delByPattern(`staff:list:${ctx.tenantId}:*`),
                CacheManager.del(`auth_metadata:${entity.id}`)
            ]);
            // Domain Event
            await EventBus.dispatch({
                type: 'STAFF_UPDATED',
                version: '1.1',
                tenantId: ctx.tenantId,
                actorId: ctx.userId,
                payload: {
                    staffId: entity.id,
                    before: before,
                    after: updated,
                    changes: { status: props.status, role: props.role }
                }
            }, tx);
            return entity;
        }, { ownerId: isGuard ? ctx.userId : undefined, callerRole: ctx.role });
    }
    /**
     * Creates a new staff member within a transaction.
     */
    static async create(ctx, data) {
        const validated = createStaffSchema.parse(data);
        // CRITICAL: Hash password before persisting
        if (validated.password) {
            const rounds = parseInt(process.env.BCRYPT_ROUNDS || '10', 10);
            validated.password = await bcrypt.hash(validated.password, rounds);
        }
        return await db.withTenant(ctx.tenantId, async (tx) => {
            // 1. Check max employees limit
            const tenant = await tx.tenant.findUnique({
                where: { id: ctx.tenantId },
                select: { maxEmployees: true }
            });
            if (tenant) {
                const currentCount = await tx.staff.count({
                    where: { tenantId: ctx.tenantId }
                });
                if (currentCount >= tenant.maxEmployees) {
                    throw new Error('LIMIT_REACHED: Số lượng nhân viên đã đạt giới hạn tối đa của gói dịch vụ. Vui lòng nâng cấp hoặc xóa bớt nhân sự cũ.');
                }
            }
            // 2. Transactional check for duplicate username
            const existing = await tx.staff.findUnique({
                where: { username: validated.username }
            });
            if (existing)
                throw new Error('CONFLICT_USERNAME');
            // 3. Create staff record
            const staff = await tx.staff.create({
                data: {
                    ...validated
                }
            });
            // Invalidate list cache
            await CacheManager.delByPattern(`staff:list:${ctx.tenantId}:*`);
            // 3. Dispatch Domain Event (Transactional Outbox)
            await EventBus.dispatch({
                type: 'STAFF_CREATED',
                version: '1.1',
                tenantId: ctx.tenantId,
                actorId: ctx.userId,
                payload: { staffId: staff.id, fullName: staff.fullName }
            }, tx);
            return staff;
        }, { callerRole: ctx.role });
    }
    static async update(ctx, id, data) {
        const isGuard = ctx.role === UserRole.GUARD;
        // FIX 4.5: Password Security - Băm mật khẩu nếu có thay đổi trong Repository update path
        if (data.password) {
            const rounds = parseInt(process.env.BCRYPT_ROUNDS || '10', 10);
            data.password = await bcrypt.hash(data.password, rounds);
        }
        return await db.withTenant(ctx.tenantId, async (tx) => {
            // 1. Fetch current state for diffing (with ownership check if guard)
            const before = await tx.staff.findUnique({ where: { id } });
            if (!before) {
                const error = new Error('NOT_FOUND_OR_ACCESS_DENIED');
                error.status = 404;
                throw error;
            }
            // 2. Perform update
            const staff = await tx.staff.update({
                where: { id },
                data: {
                    ...data,
                    updatedAt: new Date()
                }
            });
            // Invalidate Caches
            await Promise.all([
                CacheManager.del(this.getCacheKey(id)),
                CacheManager.delByPattern(`staff:list:${ctx.tenantId}:*`),
                CacheManager.del(`auth_metadata:${id}`)
            ]);
            // 3. Log Sensitive Change with Diff
            await AuditService.logSensitiveChange(ctx.userId, ctx.tenantId, 'UPDATE_STAFF', `staff/${id}`, before, staff);
            return staff;
        }, { ownerId: isGuard ? ctx.userId : undefined, callerRole: ctx.role });
    }
    static async delete(ctx, id) {
        const { redis } = await import('../../infra/redis/client.js');
        return await db.withTenant(ctx.tenantId, async (tx) => {
            const before = await tx.staff.findUnique({ where: { id } });
            if (!before)
                return; // Idempotent or Access Denied
            await tx.staff.delete({
                where: { id }
            });
            // Invalidate Cache
            await Promise.all([
                CacheManager.del(this.getCacheKey(id)),
                CacheManager.delByPattern(`staff:list:${ctx.tenantId}:*`),
                redis.del(`user_token_version:${id}`),
                CacheManager.del(`auth_metadata:${id}`)
            ]);
            // Domain Event
            await EventBus.dispatch({
                type: 'STAFF_DELETED',
                version: '1.1',
                tenantId: ctx.tenantId,
                actorId: ctx.userId,
                payload: { staffId: id, before }
            }, tx);
        }, { callerRole: ctx.role });
    }
    static DUMMY_HASH = '$2b$10$EixZA5VK1pJ4qC0XzYJ3beFsd5X7L.R5vY96lT0.K3Jp1r2q3s4t5'; // Balanced timing hash
    static async getByUsername(username, ip) {
        // SECURITY SEC-003: Use raw SQL to bypass RLS for super-admin global lookup
        // Cannot use Prisma ORM here because the isolation guard blocks unscoped queries
        // even with systemBypass() due to Prisma extension chain ordering.
        const results = await db.$queryRaw `
      SELECT * FROM "staff" WHERE username = ${username} LIMIT 1
    `;
        const user = results[0] || null;
        // Safety check: only allow super-admin if queried via global scope
        // We use a dummy comparison to prevent timing-based username enumeration
        if (!user || user.role !== UserRole.SUPER_ADMIN) {
            // Simulate crypto work to match the timing of a successful lookup/check
            await bcrypt.compare('dummy_password', this.DUMMY_HASH);
            if (user) {
                logger.warn({
                    username,
                    ip,
                    role: user.role,
                    category: 'SECURITY',
                    alert_type: 'CROSS_TENANT_ENUMERATION_ATTEMPT'
                }, 'Potential cross-tenant username enumeration detected.');
            }
            return null;
        }
        if (ip) {
            logger.info({ username, ip, role: user.role, category: 'SECURITY' }, 'Internal super-admin lookup success.');
        }
        return user;
    }
    static async getByUsernameAndTenant(username, tenantId) {
        // This is used for standard Tenant Login - SECURE ISOLATION
        // IMPORTANT: We use findFirst instead of findUnique because findUnique strips non-unique fields (tenantId)
        // from the where clause during extension chaining, causing a SECURITY_VIOLATION deep in the isolationGuard.
        return await db.forTenant(tenantId, { readOnly: true }).staff.findFirst({
            where: { username }
        });
    }
    /**
     * SMART RECOGNITION: Checks reputation across all tenants based on idNumber.
     * Returns counts of negative events without leaking tenant names.
     */
    static async checkReputation(idNumber) {
        if (!idNumber)
            return { violations: 0, severeViolations: 0, incidents: 0 };
        // Cross-tenant lookup using SYSTEM scope bypass
        const sys = db.systemBypass();
        const [violations, severeViolations, incidents] = await Promise.all([
            sys.disciplinaryAction.count({ where: { staff: { idNumber } } }),
            sys.disciplinaryAction.count({ where: { staff: { idNumber }, severity: 'HIGH' } }),
            sys.incident.count({ where: { assignee: { idNumber } } })
        ]);
        return { violations, severeViolations, incidents };
    }
    /**
     * Internal method for securely exporting Staff data to PDF across tenants.
     * Requires system-level bypass because internal requests don't have user context.
     * Strictly limited use.
     */
    static async getInternalExportData(id) {
        const sys = db.systemBypass({ readOnly: true });
        const staff = await sys.staff.findUnique({ where: { id } });
        if (!staff)
            return null;
        const tenant = await sys.tenant.findUnique({ where: { id: staff.tenantId } });
        return { staff, tenant };
    }
}
