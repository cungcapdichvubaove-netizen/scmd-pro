import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

interface ProtectedRouteProps {
  children: React.ReactNode;
  allowedRoles?: string[];
}

export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children, allowedRoles }) => {
  const { role, token, isLoading } = useAuth();
  const location = useLocation();

  console.log('[ProtectedRoute Debug]', { 
    path: location.pathname, 
    isLoading, 
    hasToken: !!token, 
    role, 
    allowedRoles 
  });

  if (isLoading) {
    return (
      <div className="h-screen w-full flex flex-col justify-center items-center bg-slate-950">
        <div className="w-12 h-12 border-4 border-scmd-cyber border-t-transparent rounded-full animate-spin mb-4"></div>
        <div className="text-scmd-cyber font-mono animate-pulse">Verifying Session Security...</div>
      </div>
    );
  }

  if (!token) {
    // Redirect to login but save the current location
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  if (allowedRoles && !allowedRoles.includes(role || '')) {
    // Role not authorized - redirect based on actual role
    if (role === 'super-admin') return <Navigate to="/super-admin/dashboard" replace />;
    if (role === 'tenant-admin') return <Navigate to="/admin/dashboard" replace />;
    if (role === 'guard') return <Navigate to="/guard/app" replace />;
    
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
};
