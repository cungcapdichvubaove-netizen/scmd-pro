import { AuthProvider, AuthUser } from './auth.provider.interface.js';
import jwt from 'jsonwebtoken';
import { redisClient } from '../redis.js';
import { db } from '../db/prisma.js';
import { logger } from '../logger/index.js';
import { JWT_SECRET } from './secrets.js';

export class JwtAuthProvider implements AuthProvider {
  private secret: string = JWT_SECRET;

  constructor() {}

  async verifyToken(token: string): Promise<AuthUser | null> {
    try {
      const decoded = jwt.verify(token, this.secret) as AuthUser;
      
      // OPTIMIZATION: Check token version for instant revocation
      const cacheKey = `user_token_version:${decoded.id}`;
      let currentVersion = await redisClient.get(cacheKey);

      if (currentVersion === null) {
        // Fallback to DB if not in cache
        // [SECURITY] Use tenant scope if available to enforce RLS
        const dbInstance = decoded.tenantId ? db.forTenant(decoded.tenantId) : db.system();
        let staff: { tokenVersion: number } | null = null;
        try {
          staff = await dbInstance.staff.findUnique({
            where: { id: decoded.id },
            select: { tokenVersion: true }
          });
        } catch (dbErr) {
          if (process.env.NODE_ENV !== 'production' && (decoded.id.startsWith('mock-') || decoded.id.startsWith('staff-'))) {
             staff = { tokenVersion: 1 };
          } else {
             throw dbErr;
          }
        }
        
        if (!staff) {
          if (process.env.NODE_ENV !== 'production' && (decoded.id.startsWith('mock-') || decoded.id.startsWith('staff-'))) {
            staff = { tokenVersion: 1 };
          } else {
             return null;
          }
        }
        currentVersion = staff.tokenVersion.toString();
        // Cache for 5 minutes to reduce DB load while keeping revocation latency low
        await redisClient.setex(cacheKey, 300, String(currentVersion ?? '0'));
      }

      if (currentVersion === null || decoded.tokenVersion !== parseInt(currentVersion)) {
        logger.warn({ userId: decoded.id, tokenVersion: decoded.tokenVersion, currentVersion }, 'SECURITY_ALERT: Revoked token attempt detected');
        return null;
      }

      return decoded;
    } catch (e) {
      return null;
    }
  }

  async createToken(user: AuthUser, expiresIn: string = '1h'): Promise<string> {
    return jwt.sign(user, this.secret, { expiresIn: expiresIn as any });
  }
}
