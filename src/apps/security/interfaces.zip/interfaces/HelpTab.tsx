import React from "react";
import { AlertTriangle, LifeBuoy, Wrench, X, Zap } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { cn } from "../../../lib/utils";
import { SCMDButton } from "../../common/interfaces/components/SCMDButton";
import { SCMDInput } from "../../common/interfaces/components/SCMDInput";
import { HelpCenter } from "../components/HelpCenter";
import {
  DashboardMetricCard,
  DashboardMetricGrid,
  DashboardPageHeader,
  dashboardInputClass,
  dashboardPanelClass,
  dashboardTextareaClass,
} from "../../common/interfaces/components/DashboardUI";

interface HelpTabProps {
  embedded?: boolean;
  showBugModal: boolean;
  bugReport: { title: string; description: string; severity: string };
  isReportingBug: boolean;
  setShowBugModal: (v: boolean) => void;
  setBugReport: React.Dispatch<
    React.SetStateAction<{
      title: string;
      description: string;
      severity: string;
    }>
  >;
  handleSubmitBug: (e: React.FormEvent) => void;
}

export const HelpTab: React.FC<HelpTabProps> = ({
  embedded = false,
  showBugModal,
  bugReport,
  isReportingBug,
  setShowBugModal,
  setBugReport,
  handleSubmitBug,
}) => {
  return (
    <>
      <div className="space-y-5 animate-in fade-in duration-500">
        {embedded ? (
          <DashboardMetricGrid className="md:grid-cols-3 xl:grid-cols-3">
            <DashboardMetricCard
              label="Mục đích"
              value="Hỗ trợ vận hành"
              tone="primary"
              icon={<LifeBuoy size={18} />}
              description="Tài liệu, FAQ và quy trình xử lý phải phục vụ trực tiếp command surface"
            />
            <DashboardMetricCard
              label="Bug report"
              value="Có workflow"
              tone="warning"
              icon={<Wrench size={18} />}
              description="Lỗi vận hành phải báo được ngay từ admin shell với mức độ ưu tiên rõ"
            />
            <DashboardMetricCard
              label="Kết quả cần đạt"
              value="Giảm hỏi nội bộ"
              tone="success"
              icon={<AlertTriangle size={18} />}
              description="Trang hỗ trợ tốt phải giảm các câu hỏi lặp lại về ca trực, sự cố và đối soát"
            />
          </DashboardMetricGrid>
        ) : (
          <DashboardPageHeader
            title="Trung tâm trợ giúp"
            description="Tra cứu hướng dẫn vận hành, quy trình xử lý sự cố và gửi phản hồi kỹ thuật cho SCMD PRO."
            eyebrow="Help & support"
          />
        )}
        <div className={embedded ? "" : "min-h-[calc(100vh-260px)]"}>
          <HelpCenter />
        </div>
      </div>

      <AnimatePresence>
        {showBugModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowBugModal(false)}
              className="absolute inset-0 bg-scmd-navy/85 backdrop-blur-md"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className={`relative w-full max-w-lg overflow-hidden ${dashboardPanelClass}`}
              role="dialog"
              aria-modal="true"
              aria-label="Báo cáo lỗi hệ thống"
            >
              <div className="flex items-center justify-between border-b border-white/5 bg-scmd-navy/50 p-5 sm:p-6">
                <div className="flex items-center gap-3 text-white">
                  <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-scmd-alert/10 text-scmd-alert">
                    <AlertTriangle size={20} />
                  </div>
                  <div>
                    <h3 className="text-lg font-black tracking-tight text-white">
                      Báo cáo lỗi hệ thống
                    </h3>
                    <p className="mt-0.5 text-[10px] font-bold uppercase tracking-widest text-scmd-silver/45">
                      Phản hồi kỹ thuật 24/7
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setShowBugModal(false)}
                  className="flex h-10 w-10 items-center justify-center rounded-xl bg-scmd-navy text-scmd-silver/45 transition-colors hover:text-white"
                >
                  <X size={20} />
                </button>
              </div>

              <form onSubmit={handleSubmitBug} className="space-y-5 p-5 sm:p-6">
                <div className="space-y-2">
                  <label className="ml-1 text-[10px] font-black uppercase tracking-widest text-scmd-silver/50">
                    Tiêu đề lỗi
                  </label>
                  <SCMDInput
                    placeholder="VD: Không thể xuất báo cáo ca trực..."
                    value={bugReport.title}
                    onChange={(e) =>
                      setBugReport({ ...bugReport, title: e.target.value })
                    }
                    className={dashboardInputClass}
                  />
                </div>

                <div className="space-y-2">
                  <label className="ml-1 text-[10px] font-black uppercase tracking-widest text-scmd-silver/50">
                    Mức độ nghiêm trọng
                  </label>
                  <div className="grid grid-cols-3 gap-3">
                    {["LOW", "MEDIUM", "CRITICAL"].map((sev) => (
                      <button
                        key={sev}
                        type="button"
                        onClick={() =>
                          setBugReport({ ...bugReport, severity: sev })
                        }
                        className={cn(
                          "min-h-[48px] rounded-2xl border px-3 py-3 text-[10px] font-black uppercase tracking-widest transition-all",
                          bugReport.severity === sev
                            ? "border-scmd-primary bg-scmd-primary text-white shadow-lg shadow-scmd-primary/20"
                            : "border-white/8 bg-white/[0.035] text-scmd-silver/55 hover:border-white/15 hover:text-white",
                        )}
                      >
                        {sev === "LOW"
                          ? "Thường"
                          : sev === "MEDIUM"
                            ? "Cao"
                            : "Khẩn cấp"}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="ml-1 text-[10px] font-black uppercase tracking-widest text-scmd-silver/50">
                    Chi tiết lỗi
                  </label>
                  <textarea
                    rows={4}
                    placeholder="Mô tả chi tiết các bước gây ra lỗi..."
                    className={dashboardTextareaClass}
                    value={bugReport.description}
                    onChange={(e) =>
                      setBugReport({
                        ...bugReport,
                        description: e.target.value,
                      })
                    }
                  />
                </div>

                <SCMDButton
                  type="submit"
                  disabled={isReportingBug}
                  className="h-14 w-full rounded-2xl bg-scmd-primary text-white shadow-xl shadow-scmd-primary/20 hover:brightness-110"
                >
                  <div className="flex items-center justify-center gap-3">
                    {isReportingBug ? (
                      <div className="h-5 w-5 animate-spin rounded-full border-2 border-white/30 border-t-white" />
                    ) : (
                      <Zap size={18} />
                    )}
                    <span className="font-black text-sm uppercase tracking-widest">
                      Gửi báo cáo lỗi
                    </span>
                  </div>
                </SCMDButton>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};
