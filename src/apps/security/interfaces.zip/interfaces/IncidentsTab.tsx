import React, { useEffect, useState, useMemo } from "react";
import { AnimatePresence, motion } from "motion/react";
import { AlertCircle, Clock3, RefreshCcw, ShieldAlert, X, MessageSquare, Activity, CheckCircle2, History, Send, Plus, Search, Filter } from "lucide-react";
import { IncidentReport } from "./IncidentReport";
import { IncidentsMainTable } from "./components/OperationsTables";
import { SCMDButton } from "../../common/interfaces/components/SCMDButton";
import {
  DashboardFilterBar,
  DashboardFilterGroup,
} from "../../common/interfaces/components/DashboardUI";
import { cn } from "../../../lib/utils";

export const IncidentsTab: React.FC = () => {
  const [isReportDrawerOpen, setIsReportDrawerOpen] = useState(false);
  const [selectedIncident, setSelectedIncident] = useState<any>(null);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);
  const [lastRefresh, setLastRefresh] = useState(() => new Date());

  const handleCloseDrawers = () => {
    setIsDrawerOpen(false);
    setIsReportDrawerOpen(false);
  };

  const handleReportSuccess = () => {
    setIsReportDrawerOpen(false);
    setRefreshKey((prev) => prev + 1);
    setLastRefresh(new Date());
  };
  const handleRefresh = () => {
    setRefreshKey((prev) => prev + 1);
    setLastRefresh(new Date());
  };

  // Mock KPIs cho cấu trúc (Trong thực tế sẽ lấy từ store/API)
  const incidentMetrics = useMemo(() => [
    { label: "MTTR", value: "42m", tone: "primary", icon: Clock3 },
    { label: "Đang xử lý", value: "08", tone: "warning", icon: Activity },
    { label: "Khẩn cấp", value: "03", tone: "danger", icon: ShieldAlert },
    { label: "Hoàn thành", value: "12", tone: "success", icon: CheckCircle2 },
  ], []);

  useEffect(() => {
    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") handleCloseDrawers();
    };
    window.addEventListener("keydown", handleEscape);
    return () => window.removeEventListener("keydown", handleEscape);
  }, []);

  return (
    <div className="flex flex-col h-[calc(100vh-160px)] gap-4 animate-in fade-in duration-500">
      
      {/* KHU VỰC 1: TOP BAR - Hợp nhất Điều hướng & Lọc */}
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-4 flex-1">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" size={14} />
            <input 
              placeholder="Tìm sự cố, site, nhân sự..." 
              className="w-full h-9 bg-white/5 border border-white/10 rounded-lg pl-9 pr-4 text-xs text-white focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-all"
            />
          </div>
          <DashboardFilterGroup>
            <button className="h-9 px-3 flex items-center gap-2 bg-white/5 border border-white/10 rounded-lg text-[11px] font-bold text-slate-400 hover:text-white transition-colors">
              <Filter size={14} /> 24h qua
            </button>
          </DashboardFilterGroup>
        </div>

        <div className="flex items-center gap-2">
          <button 
            onClick={handleRefresh}
            className="h-9 w-9 flex items-center justify-center bg-white/5 border border-white/10 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-all"
            title="Làm mới"
          >
            <RefreshCcw size={16} />
          </button>
          <SCMDButton
            onClick={() => setIsReportDrawerOpen(true)}
            className="h-9 bg-blue-600 px-4 text-[11px] font-black uppercase tracking-widest text-white hover:bg-blue-500 shadow-lg shadow-blue-600/20"
          >
            <Plus size={16} /> Tạo sự cố
          </SCMDButton>
        </div>
      </div>

      {/* KHU VỰC 2: MICRO-KPIS - Tổng quan tinh gọn */}
      <div className="flex items-center gap-8 px-1 py-1 border-y border-white/5 bg-white/[0.01]">
        {incidentMetrics.map(m => (
          <div key={m.label} className="flex items-center gap-3 py-2">
            <div className={cn(
              "w-8 h-8 rounded-lg flex items-center justify-center",
              m.tone === 'danger' ? "bg-red-500/10 text-red-500" : 
              m.tone === 'warning' ? "bg-amber-500/10 text-amber-500" : 
              m.tone === 'success' ? "bg-emerald-500/10 text-emerald-500" : "bg-blue-500/10 text-blue-500"
            )}>
              <m.icon size={14} />
            </div>
            <div>
              <p className="text-[10px] font-black uppercase text-slate-500 tracking-wider leading-none">{m.label}</p>
              <p className="text-sm font-black text-white mt-1 leading-none">{m.value}</p>
            </div>
          </div>
        ))}
        <div className="ml-auto text-[10px] font-bold text-slate-600">
          Cập nhật: {lastRefresh.toLocaleTimeString()}
        </div>
      </div>

      {/* KHU VỰC 3: MAIN WORKSPACE - Bảng dữ liệu Full-height */}
      <div className="flex-1 overflow-hidden rounded-xl border border-white/5 bg-slate-900/20">
        <IncidentsMainTable 
          key={refreshKey} 
          onRowClick={(incident) => {
            setSelectedIncident(incident);
            setIsDrawerOpen(true);
          }}
        />
      </div>

      {/* KHU VỰC 4: RIGHT DRAWERS - Xử lý Details & Form */}
      <AnimatePresence>
        {(isDrawerOpen || isReportDrawerOpen) && (
          <div className="fixed inset-0 z-[110] flex justify-end">
            {/* Overlay */}
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={handleCloseDrawers}
              className="absolute inset-0 bg-slate-950/60 backdrop-blur-sm"
            />
            
            {/* Drawer Content */}
            <motion.div
              initial={{ x: '100%' }} animate={{ x: 0 }} exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="relative flex h-full w-full max-w-xl flex-col bg-scmd-navy border-l border-white/10 shadow-2xl"
            >
              <div className="flex items-center justify-between border-b border-white/10 bg-slate-900/50 p-6">
                {isReportDrawerOpen ? (
                  <div>
                    <h2 className="text-xl font-black uppercase tracking-tight text-white">Tạo sự cố mới</h2>
                    <p className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Ghi nhận thông tin thực địa cấp tốc</p>
                  </div>
                ) : (
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-red-500/20 text-red-500 rounded-2xl flex items-center justify-center">
                      <ShieldAlert size={24} />
                    </div>
                    <div>
                      <h2 className="text-xl font-black uppercase tracking-tight text-white">Phòng tác chiến</h2>
                      <p className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Mã: #{selectedIncident?.id?.slice(0,8) || 'INC-8291'}</p>
                    </div>
                  </div>
                )}
                <button onClick={() => setIsDrawerOpen(false)} className="rounded-xl p-2 text-slate-400 hover:bg-white/5 hover:text-white">
                  <X size={24} />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-6 space-y-8 custom-scrollbar">
                {isReportDrawerOpen ? (
                  <IncidentReport isModal onSuccess={handleReportSuccess} />
                ) : (
                  <>
                {/* Content mockup: Thông tin chi tiết + SLA */}
                <section className="rounded-2xl border border-white/5 bg-slate-950/40 p-5 space-y-4">
                  <div className="flex justify-between items-end">
                    <span className="text-[10px] font-black uppercase text-slate-500 tracking-widest">Thời gian phản hồi (SLA)</span>
                    <span className="text-2xl font-mono font-black text-red-400 animate-pulse">04:22</span>
                  </div>
                  <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                    <div className="h-full bg-red-500 w-3/4 shadow-[0_0_10px_rgba(239,68,68,0.5)]" />
                  </div>
                </section>

                {/* Chat/Coordination Box */}
                <section className="space-y-4">
                  <h3 className="text-[11px] font-black uppercase tracking-widest text-slate-400 flex items-center gap-2">
                    <MessageSquare size={14} /> Nhật ký phối hợp & Chat
                  </h3>
                  <div className="min-h-[200px] rounded-2xl border border-white/5 bg-slate-950/20 p-4 text-xs text-slate-600 italic">
                    Chưa có tin nhắn trao đổi...
                  </div>
                </section>
                  </>
                )}
              </div>

              {!isReportDrawerOpen && (
              <div className="border-t border-white/10 bg-slate-900/50 p-6 flex gap-3">
                  <input className="flex-1 h-12 bg-slate-950 border border-white/10 rounded-xl px-4 text-sm text-white focus:border-blue-500 outline-none" placeholder="Nhập chỉ thị tác chiến..." />
                <button className="w-12 h-12 rounded-xl bg-blue-600 text-white flex items-center justify-center hover:bg-blue-500 transition-all">
                  <Send size={18} />
                </button>
              </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
